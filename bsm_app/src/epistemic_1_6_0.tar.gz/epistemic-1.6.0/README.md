
# EpiSTEMIC - Epidemiological Spatio-Temporal Estimation Models with INLA for Contextualization

# Installation Instructions
```r
remotes::install_gitlab(
  "nationalhealth/essence/essence-ai-toolkit/epistemic",
  host = "gitlab.jhuapl.edu",
  auth_token = "<your PAT token here>"
)
```