# © 2025 The Johns Hopkins University Applied Physics Laboratory LLC
# Development of this software was sponsored by the U.S. Government under
# contract no. 75D30124C19958
# As of September 30, 2025 this code is pending review by OTT and should be
# considered JHU Propriety and only for internal JHU/APL use.

#' Default Data Configuration
#'
#' A list of default column mappings used by `prepare_raw_data()` for
#' identifying the region, date, numerator, and denominator columns in a
#' dataset.
#'
#' @format A named list with elements:
#' \describe{
#'   \item{region}{Column name for spatial region (string).}
#'   \item{date}{Column name for date (string).}
#'   \item{numerator}{Column name for the numerator count (string).}
#'   \item{denominator}{Column name for the denominator count (string).}
#' }
DEFAULT_DATA_CONFIG <- list(
  region      = "region",
  date        = "date",
  numerator   = "numerator",
  denominator = "denominator"
)


#' Prepare Raw Data with Standardized Columns
#'
#' Validates a configuration list and then transforms the input data frame into
#' the internal `data_class` representation, using the specified column
#' mappings.
#'
#' @param data A `data.frame` or tibble containing at least the columns
#'   specified in `config`.
#' @param config A named list mapping the following required elements to column
#'   names in `data`: \code{region}, \code{date}, \code{numerator},
#'   \code{denominator}. May also include optional elements \code{expected} and
#'   \code{feature_columns}. Defaults to \code{DEFAULT_DATA_CONFIG}.
#' @param existing_other_ids Optional character vector of identifier column
#'   names to carry forward into the returned object metadata.
#'
#' @return An object of class returned by \code{data_class()}, typically a
#'   specialized data container with standardized column names.
#'
#' @details First calls \code{validate_data_config()} to ensure that
#'   \code{config} is a properly structured list. If validation fails, an error
#'   is raised via \code{cli::cli_abort()}. Otherwise, calls \code{data_class()}
#'   with the mapped column names.
#'
#' @importFrom cli cli_abort
#' @seealso \code{\link{validate_data_config}}
#' @export
#' @examples
#' \dontrun{
#' df <- data.frame(
#'   region = c("A", "B"),
#'   date = Sys.Date(),
#'   numerator = 5,
#'   denominator = 10
#' )
#' prepare_raw_data(df)
#'
#' custom_cfg <- list(
#'   region = "state",
#'   date = "event_date",
#'   numerator = "cases",
#'   denominator = "population",
#'   expected = "expected_count",
#'   feature_columns = c("age_group", "sex")
#' )
#' prepare_raw_data(df, config = custom_cfg)
#' }
prepare_raw_data <- function(data,
                             config = DEFAULT_DATA_CONFIG,
                             existing_other_ids = NULL) {
  # validate the config
  config_valid <- validate_data_config(config = config)
  if (identical(config_valid, FALSE)) {
    cli::cli_abort(paste0("Invalid config: ", attr(config_valid, "m")))
  }
  if (!is.null(existing_other_ids) && !is.character(existing_other_ids)) {
    cli::cli_abort("`existing_other_ids` must be NULL or a character vector")
  }

  obj <- data_class(
    data                = data,
    region_column       = config[["region"]],
    date_column         = config[["date"]],
    numerator_column    = config[["numerator"]],
    denominator_column  = config[["denominator"]],
    expected_column     = config[["expected"]],
    feature_columns     = config[["feature_columns"]]
  )

  if (!is.null(existing_other_ids)) {
    obj$other_ids <- unique(c(
      obj$other_ids %||% character(0),
      existing_other_ids
    ))
  }

  obj
}


#' Validate Data Configuration List
#'
#' Checks that the provided \code{config} is a list containing the required
#' elements \code{region}, \code{date}, \code{numerator}, and
#' \code{denominator}, and that each of these is a character string.
#'
#' @param config A list to be validated.
#'
#' @return
#' - \code{TRUE} (with attribute \code{m = "valid config"}) if validation
#' succeeds.
#' - \code{FALSE} (with attribute \code{m}) if validation fails, where the
#' attribute \code{m} gives a short diagnostic message.
#'
#' @export
#' @examples
#' \dontrun{
#' validate_data_config(DEFAULT_DATA_CONFIG)
#' validate_data_config(list(region = "r", date = "d")) # missing keys
#' }
validate_data_config <- function(config) {
  vm <- \(v, m) structure(v, m = m)
  valid <- vm(TRUE, "valid config")

  if (!is.list(config)) {
    return(vm(FALSE, "not a list"))
  }

  req_elements <- c("region", "date", "numerator", "denominator")

  valid <- tryCatch(
    {
      if (check_names(obj = config, names = req_elements)) valid
    },
    error = function(e) vm(FALSE, "missing required element")
  )
  if (!identical(valid, TRUE)) {
    return(valid)
  }

  types <- vapply(config[req_elements], typeof, character(1))
  if (!all(types == "character")) {
    return(vm(FALSE, "required elements not strings"))
  }

  valid
}

#' Validate an Adjacency Matrix with Optional Binary Constraint
#'
#' Checks that an object is a matrix, is square (same number of rows and
#' columns), has non-NULL row and column names that are identical, and—
#' optionally—that all entries are either 0 or 1, i.e. a proper adjacency
#' matrix.
#'
#' @param x An R object to validate.
#' @param require_binary \code{logical(1)}. If \code{TRUE} (the default), all
#'   matrix elements must be exactly 0 or 1. If \code{FALSE}, this binary check
#'   is skipped.
#'
#' @return Invisibly returns \code{TRUE} if all checks pass. If any test fails,
#'   an error is thrown with a descriptive message.
#'
#' @examples
#' # valid binary adjacency matrix
#' m1 <- matrix(c(0, 1, 1, 0), 2, 2,
#'   dimnames = list(c("a", "b"), c("a", "b"))
#' )
#' validate_adjacency_matrix(m1)
#'
#' # non‐binary values allowed if require_binary = FALSE
#' m2 <- matrix(1:4, 2, 2,
#'   dimnames = list(c("x", "y"), c("x", "y"))
#' )
#' validate_adjacency_matrix(m2, require_binary = FALSE)
#'
#' # errors:
#' # validate_adjacency_matrix(list(), TRUE)            # not a matrix
#' # validate_adjacency_matrix(matrix(1:6, 2, 3))      # not square
#' # validate_adjacency_matrix(matrix(0,2,2))          # missing dimnames
#' # validate_adjacency_matrix(matrix(c(0,2,1,0),2,2,   # non-binary
#' #      dimnames = list(c("u","v"), c("u","v"))))
#'
#' @export
validate_adjacency_matrix <- function(x, require_binary = TRUE) {
  # 1. Must be a matrix
  if (!is.matrix(x)) {
    cli::cli_abort(
      paste0("`x` must be a matrix, not a ", class(x)[1], "."),
      class = "adjacency_matrix_invalid"
    )
  }

  # 2. Must be square
  nr <- nrow(x)
  nc <- ncol(x)
  if (nr != nc) {
    cli::cli_abort(
      sprintf("Adjacency matrix must be square: nrow = %d, ncol = %d", nr, nc),
      class = "adjacency_matrix_invalid"
    )
  }

  # 3. Must have rownames and colnames
  rns <- rownames(x)
  cns <- colnames(x)
  if (is.null(rns)) {
    cli::cli_abort(
      "Adjacency matrix must have non-NULL row names.",
      class = "adjacency_matrix_invalid"
    )
  }
  if (is.null(cns)) {
    cli::cli_abort(
      "Adjacency matrix must have non-NULL column names.",
      class = "adjacency_matrix_invalid"
    )
  }

  # 4. Row names and column names must match exactly
  if (!identical(rns, cns)) {
    cli::cli_abort(
      paste0(
        "Row names and column names of the adjacency matrix must ",
        "be identical:\n",
        "  rownames: ", paste(rns, collapse = ", "), "\n",
        "  colnames: ", paste(cns, collapse = ", ")
      ),
      class = "adjacency_matrix_invalid"
    )
  }

  # 5. Optionally, check binary entries
  if (require_binary) {
    vals <- unique(as.vector(x))
    bad <- setdiff(vals, c(0, 1))
    if (length(bad) > 0) {
      cli::cli_abort(
        paste(
          "All adjacency matrix entries must be 0 or 1 when",
          "`require_binary = TRUE`. Found other values: "
        ),
        class = "adjacency_matrix_invalid"
      )
    }
  }

  # All checks passed
  invisible(TRUE)
}

#' Add covariates to a data_class Object
#'
#' Merges additional covariate columns into an existing `data_class` object by
#' matching on region and date. Validates inputs, prevents duplicate column
#' names, and updates the object’s `feature_columns`.
#'
#' @param covariates A `data.frame`, `tibble`, or `data.table` containing
#'   covariate data.
#' @param dc A `data_class` object to which covariates will be added. Must pass
#'   \code{validate_data_class()}.
#' @param region Optional `character(1)`. Name of the region column in
#'   `covariates`. If `NULL` (the default), uses `dc$region_column`.
#' @param date Optional `character(1)`. Name of the date column in `covariates`.
#'   If `NULL` (the default), uses `dc$date_column`.
#' @param features Optional `character` vector. Names of the covariate columns
#'   to add. If `NULL` (the default), all columns in `covariates` except the
#'   region and date columns will be used.
#'
#' @return The original `data_class` object, with:
#'   - `covariates` merged into `dc$data` by `(region, date)`.
#'   - New covariate column names appended to `dc$feature_columns`.
#'   The updated object is returned invisibly.
#'
#' @details 1. Validates that `dc` inherits from `"data_class"`. 2. Determines
#' the region and date column names to use in `covariates`. 3. Checks that those
#' columns exist in `covariates`. 4. Selects the feature columns: either the
#' supplied `features`, or all remaining columns in `covariates`. 5. Errors if
#' any of the region, date, or feature columns already exist in `dc$data`. 6.
#' Performs a left join of `dc$data` with `covariates` on `(region, date)`. 7.
#' Updates `dc$feature_columns` by appending the new feature names.
#'
#' @examples
#' \dontrun{
#' df_cov <- data.frame(
#'   region = c("A", "B", "A", "B"),
#'   date = as.Date(
#'     c("2020-01-01", "2020-01-01", "2020-01-02", "2020-01-02")
#'   ),
#'   pop = c(100, 200, 100, 200),
#'   temp = c(30, 25, 28, 27)
#' )
#' dc <- data_class(
#'   data = df_cov[, 1:2],
#'   region_column = "region",
#'   date_column = "date",
#'   numerator_column = "pop",
#'   denominator_column = "pop"
#' )
#' dc2 <- add_covariates(df_cov, dc, features = c("temp"))
#' }
#'
#' @export
add_covariates <- function(covariates,
                           dc,
                           region = NULL,
                           date = NULL,
                           features = NULL) {
  # validate data_class object
  validate_data_class(dc)

  # ensure covariates is a data.frame
  if (!is.data.frame(covariates)) {
    cli::cli_abort("`covariates` must be a data.frame, data.table, or tibble.")
  }

  # determine region and date column names
  region_col <- if (is.null(region)) NULL else region
  date_col <- if (is.null(date)) NULL else date

  # if both region_col and date_col are NULL, error
  if (is.null(region_col) && is.null(date_col)) {
    cli::cli_abort(
      "At least one of region and date must be provided to join covariates"
    )
  }

  # check that region and date columns exist in covariates
  check_names(covariates, c(region_col, date_col))

  # region_col must be date
  if (
    !is.null(region_col) && !inherits(covariates[[region_col]], "character")
  ) {
    cli::cli_abort("region column in covariates must be of class character")
  }
  # date_col must be date
  if (!is.null(date_col) && !inherits(covariates[[date_col]], "Date")) {
    cli::cli_abort("Date column in covariates must be of class Date")
  }

  # select feature columns
  if (is.null(features)) {
    features_vec <- setdiff(names(covariates), c(region_col, date_col))
  } else {
    if (!is.character(features) || length(features) < 1) {
      cli::cli_abort("`features` must be a non-empty character vector.")
    }
    # make sure all features are in covariates
    check_names(covariates, features)

    # make sure that features do not contain the id cols
    if (length(intersect(c(region_col, date_col), features) > 0)) {
      cli::cli_abort(
        "`features` can not overlap the joining region and date columns"
      )
    }
    features_vec <- features
  }

  # check for duplicate column names in existing dc$data
  existing <- names(dc$data)
  dup_cols <- intersect(features_vec, existing)
  if (length(dup_cols) > 0) {
    cli::cli_abort(
      glue::glue(
        "Cannot add columns ({paste(dup_cols, collapse = ', ')}) ",
        "that already exist in data_class"
      )
    )
  }

  # perform the merge (left join)
  cov_dt <- data.table::as.data.table(covariates)


  # check that the region and date col make a primary key
  if (nrow(cov_dt) != nrow(
    unique(
      cov_dt[, .SD, .SDcols = c(region_col, date_col)]
    )
  )) {
    cli::cli_abort(
      "Region and/or Date column do not form a primary key on covariates"
    )
  }
  byx <- character(0)
  if (!is.null(region_col)) byx <- c(byx, dc$region_col)
  if (!is.null(date_col)) byx <- c(byx, dc$date_column)

  byy <- character(0)
  if (!is.null(region_col)) byy <- c(byy, region_col)
  if (!is.null(date_col)) byy <- c(byy, date_col)

  join_dt <- cov_dt[, c(region_col, date_col, features_vec), with = FALSE]
  dc$data <- merge(
    dc$data,
    join_dt,
    by.x = byx,
    by.y = byy,
    all.x = TRUE,
    sort = FALSE
  )

  na_table <- data.table::data.table(
    feature = features_vec,
    missing = sapply(features_vec, \(f) sum(is.na(dc$data[[f]])))
  )

  if (na_table[, sum(missing)] > 0) {
    cli::cli_warn("Note there are missing values in some of the features")
    print(na_table[missing > 0])
    data.table::setattr(dc, "missing_features", na_table[missing > 0])
  }

  # update feature_columns
  old_feats <- dc$feature_columns %||% character(0)
  dc$feature_columns <- c(old_feats, features_vec)

  dc
}
