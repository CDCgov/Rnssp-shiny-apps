# © 2025 The Johns Hopkins University Applied Physics Laboratory LLC
# Development of this software was sponsored by the U.S. Government under
# contract no. 75D30124C19958
# As of September 30, 2025 this code is pending review by OTT and should be
# considered JHU Propriety and only for internal JHU/APL use.

#' Check for required named elements in an object
#'
#' Verifies that a given objects contains given names
#'
#' @param obj A object in which to check for the presence of names.
#' @param names A character vector of names that must be present in \code{obj}
#'
#' @return Returns \code{TRUE} if all required names are present.
#' @details The function loops over each element of \code{names}. For each
#' name \code{v}, it checks whether \code{v} is a name of an element in
#' \code{obj}. If \code{v} is not found, the function stops execution and raises
#' an error via \code{cli::abort()}, indicating which required name is
#' missing.
#'
#' @examples
#' df <- data.frame(a = 1:3, b = letters[1:3])
#'
#' # This will return TRUE (all elements present)
#' check_names(df, c("a", "b"))
#'
#' # This will error: 'object does not contain required named element 'c''
#' try(check_names(df, c("a", "c")))
#'
#' @export
check_names <- function(obj, names) {
  for (v in names) {
    if (!v %in% names(obj)) {
      error <- paste0("object does not contain named element '", v, "'")
      cli::cli_abort(error, class = "name_not_found")
    }
  }
  TRUE
}


#' Get Rescaling Factors for INLA Model Predictions
#'
#' This function prepares rescaling factors for predictions from a fitted INLA
#' model, based on the family used in the model and associated training data.
#' It supports transforming results to either count scale or proportion scale.
#'
#' @param inla_model A fitted model object. The model
#'   must use one of the supported families: `"binomial"`, `"poisson"`,
#'   `"nbinomial"`, or `"betabinomial"`.
#' @param data_cls A custom data class object containing the training data used
#'  to fit the model.
#'
#' @return A named list with two elements:
#' \describe{
#'   \item{`count_scale`}{A numeric vector for scaling predictions to the count
#'     scale (e.g., number of events).}
#'   \item{`prop_scale`}{A numeric vector for scaling predictions to the
#'     proportion scale (e.g., probability of success).}
#' }
#'
#' @details
#' The function determines the appropriate rescaling method based on the family
#' used in the model:
#' \itemize{
#'   \item For `"binomial"` and `"betabinomial"`, predictions are scaled using
#'     the `denominator` column in `data_cls`.
#'   \item For `"poisson"` and `"nbinomial"`, predictions are assumed to be on
#'     the count scale, and the `count_scale` is set to 1 while `prop_scale`
#'     is computed as `1 / denominator`.
#' }
#'
#' This is useful when applying transformations to summary statistics such as
#' posterior means or quantiles that are returned on the linear predictor scale.
#'
#' @examples
#' \dontrun{
#' data("demo_model_result")
#' data("demo_data")
#' scales <- get_scale_factors(demo_model_result, demo_data)
#' head(scales$count_scale)
#' head(scales$prop_scale)
#' }
#'
#' @export
get_scale_factors <- function(data_cls, inla_model) {
  data <- data_cls$data
  denominator_column <- data_cls$denominator_column
  family <- inla_model$.args$family
  model_scale <- get_model_scale(inla_model)
  if (model_scale == "count") {
    count_scale <- rep(1, nrow(data))
    prop_scale <- 1 / data[[denominator_column]]
  } else if (model_scale == "prop") {
    # For binomial and betabinomial the outputs are proportions.
    count_scale <- data[[denominator_column]]
    prop_scale <- rep(1, nrow(data))
  } else {
    cli::cli_abort(
      paste0(
        "Rescaling is not yet available for family: ",
        family,
        "."
      ),
      class = "invalid_argument"
    )
  }
  list(count_scale = count_scale, prop_scale = prop_scale)
}


#' Get Model Scale for INLA Model Predictions
#'
#' This function extracts the model family and determines if the outputs are
#' counts or proportions.
#'
#' @param inla_model A fitted model object. The model
#'   must use one of the supported families: `"binomial"`, `"poisson"`,
#'   `"nbinomial"`, or `"betabinomial"`.
#'
#' @return A character vector that is either "count" or "prop".
#'
#' @details
#' The function determines the appropriate model scale based on the family
#' used in the model:
#' \itemize{
#'   \item For `"binomial"` and `"betabinomial"`, predictions are proportions.
#'   \item For `"poisson"` and `"nbinomial"`, predictions are counts.
#' }
#'
#' This is useful when applying transformations to summary statistics such as
#' posterior means or quantiles that are returned on the linear predictor scale.
#'
#' @examples
#' \dontrun{
#' data("demo_model_result")
#' data("demo_data")
#' model_scale <- get_model_scale(demo_model_result)
#' head(model_scale)
#' }
#'
#' @export
get_model_scale <- function(inla_model) {
  family <- inla_model$.args$family
  if (family %in% c("poisson", "nbinomial")) {
    # For poisson and nbinomial the outputs are counts.
    "count"
  } else if (family %in% c("binomial", "betabinomial")) {
    # For binomial and betabinomial the outputs are proportions.
    "prop"
  } else {
    cli::cli_abort(
      paste0(
        "Model scale is unknown for family: ",
        family,
        "."
      ),
      class = "invalid_argument"
    )
  }
}

#' Copy a data_class Object with Deep-Copied Data
#'
#' Creates a copy of a \code{data_class} object in which the \code{data}
#' component is deep-copied (via \code{data.table::copy()}). Other components
#' of the object remain as in the original.
#'
#' @param dc A \code{data_class} object to copy.
#'
#' @return A new \code{data_class} object identical to \code{dc}, except that
#'   the \code{data} slot is a deep copy of the original. Modifying the
#'   returned object’s \code{data} will not affect \code{dc$data}.
#'
#' @export
copy_data_class <- function(dc) {
  d <- dc
  d$data <- data.table::copy(dc$data)
  d
}

#' Infer Frequency from a Date Vector
#'
#' Examines a vector of dates, computes the unique differences between sorted
#' values, and returns the single inferred increment. If multiple distinct
#' gaps are detected, the function aborts with an error.
#'
#' @param x A vector of \code{Date} values
#'
#' @return A \code{difftime} object representing the consistent date increment.
#'   If the sorted unique dates do not share a single gap, the function aborts.
#'
#' @export
infer_freq <- function(x) {
  if (!inherits(x, "Date")) {
    cli::cli_abort("x must be vector class 'Date'")
  }

  # convert x to IDate
  x <- data.table::as.IDate(x)

  date_increment <- unique(x) |>
    sort() |>
    diff() |>
    unique()
  if (length(date_increment) != 1) {
    cli::cli_abort(
      "Cannot infer frequency, multiple date gaps detected"
    )
  }
  date_increment
}


#' Remove Invalid Estimates Based on Scale Inconsistency
#'
#' This function removes (sets to \code{NA}) values in selected columns of a
#' results \code{data.table} when the denominators are not available
#' (denominator_source>0) and the requested scale does not align with that of
#' the fitted INLA model.
#'
#' @param data A \code{data.table} containing model output. This is typically
#'   derived from a post-processing function applied to an INLA model.
#' @param value_columns A character vector of column names in \code{data} whose
#'   values should be set to \code{NA} if the scale is inconsistent.
#' @param inla_model A fitted INLA model object, as returned by
#'   \code{INLA::inla()}.
#' @param use_count_scale Logical. If \code{TRUE}, the function expects the
#'   model family to be appropriate for counts (e.g., Poisson); if \code{FALSE},
#'   the model is expected to be on a proportion scale (e.g., Binomial).
#' @param data_class A custom \code{data_class} object that includes a
#'   \code{data} slot (also a \code{data.table}). This should contain a column
#'   named \code{denominator_source}, which indicates whether values were
#'   aggregated over a denominator.
#'
#' @return The modified \code{data} \code{data.table}, invisibly, with selected
#'   values in \code{value_columns} set to \code{NA} if the scale and model
#'   family are incompatible.
#'
#' @details
#' The function performs the following steps:
#' \enumerate{
#'   \item Verifies that \code{data} is a \code{data.table}.
#'   \item Extracts the model family from the INLA model.
#'   \item Checks whether the family is consistent with the desired output
#'         scale.
#'   \item If the model family is invalid and \code{denominator_source} exists
#'         in \code{data_class$data}, all rows where
#'         \code{denominator_source > 0} have the specified
#'         \code{value_columns} set to \code{NA}.
#' }
#'
#' @examples
#' \dontrun{
#' clean_data <- copy(model_output)
#' remove_invalid_estimates(
#'   data = clean_data,
#'   value_columns = c("mean", "sd"),
#'   inla_model = my_model,
#'   use_count_scale = TRUE,
#'   data_class = my_data_class
#' )
#' }
#'
#' @export
remove_invalid_estimates <- function(data,
                                     value_columns,
                                     inla_model,
                                     use_count_scale,
                                     data_class) {
  # Ensure data is a data.table
  if (!data.table::is.data.table(data)) {
    cli::cli_abort("`data` must be a data.table.")
  }
  model_family <- tolower(inla_model$.args$family)
  prop_families <- c("binomial", "betabinomial")
  count_families <- c("poisson", "nbinomial")

  # Check denominator_source column exists in data_class$data
  has_den_source <- "denominator_source" %in% names(data_class$data)
  if (use_count_scale) {
    valid_family <- model_family %in% count_families
  } else {
    valid_family <- model_family %in% prop_families
  }
  # Only proceed if both conditions are met
  if (has_den_source && !valid_family) {
    if (nrow(data_class$data) == nrow(data)) {
      rows_to_na <- which(data_class$data$denominator_source > 0)
    } else {
      rows_to_na <- data_class$data[data,
        on = c(
          data_class$date_column,
          data_class$region_column
        ),
        nomatch = 0L
      ]
      # This returns a dataframe, but what we want is the index of rows
      # where denominator_source is positive, so switch to which
      rows_to_na <- which(rows_to_na$denominator_source > 0)
    }

    if (length(rows_to_na) > 0) {
      for (col in value_columns) {
        if (col %in% names(data)) {
          data[rows_to_na, (col) := NA]
        } else {
          warning(sprintf("Column '%s' not found in data; skipping.", col))
        }
      }
    }
  }

  # Return modified data invisibly
  invisible(data)
}


#' Compute MMWR (Epidemiologic) Week and Year
#'
#' Calculates the CDC Morbidity and Mortality Weekly Report (MMWR) week
#' and year corresponding to each input date using only base R functions.
#'
#' @description
#' The MMWR (also called "epidemiologic" or "epi") week system divides
#' the year into weeks that always start on **Sunday** and end on **Saturday**.
#' Week 1 of a given year is defined as the **first week that has four or more
#' days in January** (i.e., the week containing January 4). This ensures each
#' MMWR year has either 52 or 53 complete weeks, and that every week belongs
#' entirely to a single MMWR year.
#'
#' @param dates A vector of `Date` objects or values convertible to `Date`.
#'   Each element is converted to a `Date` if not already one.
#'
#' @return A data frame with two integer columns:
#'   \describe{
#'     \item{mmwr_year}{The MMWR year corresponding to the input date.}
#'     \item{mmwr_week}{The MMWR week number (1–52, occasionally 53).}
#'   }
#'
#' @details
#' This function replicates the behavior of \code{lubridate::epiweek()}
#' and \code{lubridate::epiyear()} using base R only. It determines:
#' \enumerate{
#'   \item The Sunday at the start of each week (`as.POSIXlt(date)$wday` gives
#'         weekday index where Sunday = 0).
#'   \item The MMWR year as the year containing the Thursday of that week.
#'   \item The MMWR week as the number of Sundays since the first MMWR week
#'         of that year (the Sunday on or before January 4).
#' }
#'
#' @examples
#' # Basic usage
#' get_mmwr_week_year(as.Date("2025-01-01"))
#'
#' # Vectorized input
#' dates <- seq(as.Date("2024-12-28"), as.Date("2025-01-10"), by = "day")
#' get_mmwr_week_year(dates)
#'
#' # Example output
#' #     mmwr_year mmwr_week
#' # 1        2024        52
#' # 2        2024        52
#' # 3        2024        52
#' # 4        2025         1
#' # 5        2025         1
#' # ...
#'
#' @seealso
#' \code{\link{add_mmwr_week}} for adding MMWR week IDs to a `data_class`.
#'
#' @export
get_mmwr_week_year <- function(dates) {
  # Coerce to Date if needed
  dates <- as.Date(dates)
  # Weekday as number (Sunday = 0, Monday = 1, ..., Saturday = 6)
  wday <- as.POSIXlt(dates)$wday

  # Sunday of this week
  sunday <- dates - wday

  # MMWR year = year containing the Thursday of this week (Sunday + 4)
  thursday <- sunday + 4
  mmwr_year <- as.integer(format(thursday, "%Y"))

  # First Sunday of MMWR week 1 for that year = Sunday on or before Jan 4
  jan4 <- as.Date(paste0(mmwr_year, "-01-04"))
  first_sunday <- jan4 - as.POSIXlt(jan4)$wday

  # Week number = (sunday - first_sunday)/7 + 1
  mmwr_week <- as.integer((sunday - first_sunday) / 7) + 1L

  data.frame(mmwr_year = mmwr_year, mmwr_week = mmwr_week)
}
