# © 2025 The Johns Hopkins University Applied Physics Laboratory LLC
# Development of this software was sponsored by the U.S. Government under
# contract no. 75D30124C19958
# As of September 30, 2025 this code is pending review by OTT and should be
# considered JHU Propriety and only for internal JHU/APL use.

#' Compute Exceedance Probabilities from an INLA Model
#'
#' This function computes exceedance probabilities from a fitted INLA model and
#' a `data_cls` object containing the model's training data. The exceedance
#' probability is defined as the posterior probability that a specified outcome
#' exceeds a given threshold.
#'
#' @param inla_model An object returned by a call to [`INLA::inla()`],
#'     representing a fitted INLA model.
#' @param data_cls A data class object containing the training data used to
#'     fit `inla_model`.
#' @param threshold A numeric value representing the exceedance threshold.
#'     The function computes the probability that the outcome proportion exceeds
#'     this value.  Model outputs are converted to proportions using the
#'     denominator column where necessary.
#' @param use_suffix Logical. If `FALSE` (default), the column name
#'   will be "exceedance_probs". If `TRUE`, the output column name will
#'   include either "_count" or "_prop" as a suffix based on used_count_scale.
#' @param use_count_scale Logical.  If `FALSE`, results will interpreted as
#'   proportions. If `TRUE`, thresholds will be interpreted as a count.
#' @param regions Array. Array of regions where results should be calculated.
#'   If `NULL`, all regions are used. Default is `NULL`.
#' @param dates Array. Array of dates where results should be calculated.
#'   If `NULL`, all dates are used. Default is `NULL`.
#'
#' @return A `data.table` with exceedance probabilities for each observation in
#' `data_cls`. This is indexed by the region column and date column.
#'
#' @details
#' The function assumes that the fitted model provides posterior marginal
#' distributions which are used to compute the exceedance probabilities which
#' represent the probability that the estimated proportion exceeds the
#' specified threshold.
#'
#' @examples
#' \dontrun{
#' # Fit INLA model first (not shown)
#' probs <- get_exceedance_probs(inla_model, training_data, threshold = 0.05)
#' head(probs)
#' }
#'
#' @export
get_exceedance_probs <- function(inla_model,
                                 data_cls,
                                 threshold,
                                 use_suffix = TRUE,
                                 use_count_scale = FALSE,
                                 regions = NULL,
                                 dates = NULL) {
  keep_inds <- get_subset_indices.data_class(data_cls,
    regions = regions,
    dates = dates
  )
  data <- data_cls$data[keep_inds, ]
  region_column <- data_cls$region_column
  date_column <- data_cls$date_column
  denominator_column <- data_cls$denominator_column
  marg <- inla_model$marginals.fitted.values[keep_inds]

  # Extract posterior values and scaling factors
  model_scale <- get_model_scale(inla_model)

  suffix <- if (use_count_scale) "_counts" else "_props"
  col_name <- "exceedance_prob"
  col_name <- if (use_suffix) paste0(col_name, suffix) else col_name


  if ((model_scale == "count") && (use_count_scale)) {
    # scales match: Use thresholds as is
    threshold <- threshold * (1 + 0 * data[[denominator_column]])
  } else if ((model_scale == "count") && (!use_count_scale)) {
    # scales do not match: interpret input thresholds as proportions and rescale
    threshold <- threshold * data[[denominator_column]]
  } else if ((model_scale == "prop") && (!use_count_scale)) {
    # scales match: Use thresholds as is
    threshold <- threshold * (1 + 0 * data[[denominator_column]])
  } else if ((model_scale == "prop") && (use_count_scale)) {
    # scales do not match: interpret input thresholds as counts and rescale
    threshold <- threshold / data[[denominator_column]]
  }

  get_exceedance <- function(thr, marg) {
    as.numeric(
      1 - INLA::inla.pmarginal(q = thr, marginal = marg)
    )[[1]]
  }
  exceedance_prob <- unname(mapply(get_exceedance, threshold, marg))

  # Return final result

  id_cols <- c(region_column, date_column)
  result <- data_cls$data[keep_inds, .SD, .SDcols = id_cols]
  result[, (col_name) := exceedance_prob]

  result <- remove_invalid_estimates(
    data = result,
    value_columns = c(col_name),
    inla_model = inla_model,
    use_count_scale = use_count_scale,
    data_class = data_cls
  )

  (result[])
}


#' Compute Grouped Exceedance Probabilities from an INLA Model
#'
#' Computes exceedance probabilities for aggregates defined by `group_cols`.
#' Uses joint posterior samples (via `get_posterior_samples()`) so correlation
#' among regions is preserved.
#'
#' If `use_count_scale = TRUE`, the exceedance event is on the aggregated count.
#' If `use_count_scale = FALSE`, the exceedance event is on the aggregated
#' proportion computed as `sum(counts) / sum(denominator)` within each group.
#'
#' @param inla_model A fitted INLA model object.
#' @param data_cls A data class object.
#' @param threshold Numeric exceedance threshold (count or proportion).
#' @param use_suffix Logical; if `TRUE`, suffix output column name.
#' @param use_count_scale Logical; if `TRUE`, interpret threshold as count.
#'   If `FALSE`, interpret threshold as proportion.
#' @param regions Optional region filter; `NULL` means no filtering.
#' @param dates Optional date filter; `NULL` means no filtering.
#' @param group_cols Character vector of grouping columns in `data_cls$data`.
#' @param n_samples Integer number of posterior samples.
#' @param na.rm Logical controlling NA handling when summing posterior draws.
#'
#' @return A `data.table` with one row per group and an exceedance column.
get_exceedance_probs_group <- function(
  inla_model,
  data_cls,
  threshold,
  use_suffix = TRUE,
  use_count_scale = FALSE,
  regions = NULL,
  dates = NULL,
  group_cols,
  n_samples = 1000L,
  na.rm = FALSE
) {
  if (missing(group_cols) || length(group_cols) < 1L) {
    cli::cli_abort("`group_cols` must be a non-empty character vector.")
  }
  if (!is.character(group_cols)) {
    cli::cli_abort("`group_cols` must be a character vector of column names.")
  }
  if (!is.numeric(threshold) || length(threshold) != 1L) {
    cli::cli_abort("`threshold` must be a single numeric value.")
  }
  if (!is.numeric(n_samples) || length(n_samples) != 1L || n_samples < 1L) {
    cli::cli_abort("`n_samples` must be a positive integer.")
  }
  n_samples <- as.integer(n_samples)

  region_col <- data_cls$region_column
  date_col <- data_cls$date_column

  if (is.null(region_col) || is.null(date_col)) {
    cli::cli_abort(
      "`data_cls$region_column` and `data_cls$date_column` needed."
    )
  }

  missing_cols <- setdiff(group_cols, names(data_cls$data))
  if (length(missing_cols) > 0L) {
    cli::cli_abort(c(
      "The following `group_cols` are not in `data_cls$data`:",
      paste0(" - ", missing_cols)
    ))
  }

  keep_inds <- get_subset_indices.data_class(
    data_cls,
    regions = regions,
    dates = dates
  )
  if (length(keep_inds) == 0L) {
    cli::cli_abort("No observations match the requested regions/dates.")
  }

  # Always draw on count scale so aggregation is coherent.
  samps_dt <- get_posterior_samples(
    inla_model = inla_model,
    data_cls = data_cls,
    n_samples = n_samples,
    use_count_scale = TRUE,
    regions = regions,
    dates = dates
  )
  samps_dt <- data.table::as.data.table(samps_dt)

  if (!(region_col %in% names(samps_dt))) {
    cli::cli_abort("Region column not found in posterior samples output.")
  }
  if (!(date_col %in% names(samps_dt))) {
    cli::cli_abort("Date column not found in posterior samples output.")
  }

  sample_cols <- grep(
    "^sample_[0-9]+$",
    names(samps_dt),
    value = TRUE
  )
  if (length(sample_cols) != n_samples) {
    cli::cli_abort("Unexpected number of sample columns returned.")
  }

  # Ensure stable sample column order: sample_1, sample_2, ...
  sample_nums <- suppressWarnings(
    as.integer(sub("^sample_", "", sample_cols))
  )
  sample_cols <- sample_cols[order(sample_nums)]

  x <- as.matrix(samps_dt[, sample_cols, with = FALSE]) # K x S
  draws_counts <- t(x) # S x K

  # Build keys_dt (region/date) aligned to rows in samps_dt.
  # keys_dt aligned to sampled rows
  keys_dt <- data.table::data.table(
    region_key = samps_dt[[region_col]],
    date_key   = samps_dt[[date_col]]
  )

  # map_dt from data_cls$data: keep group cols as-is, add join key columns
  cols_map <- unique(c(region_col, date_col, group_cols))
  map_dt <- data_cls$data[, cols_map, with = FALSE]

  map_dt[, region_key := map_dt[[region_col]]]
  map_dt[, date_key := map_dt[[date_col]]]

  data.table::setkeyv(map_dt, c("region_key", "date_key"))
  data.table::setkeyv(keys_dt, c("region_key", "date_key"))

  groups_dt <- map_dt[keys_dt]

  # Now this works because groups_dt still has the original group_cols
  if (anyNA(groups_dt[, group_cols, with = FALSE])) {
    cli::cli_abort("Some sampled rows have missing group mappings.")
  }

  groups_dt[, gid := .GRP, by = group_cols]

  # Aggregate counts within each draw -> (S x G)
  idx_by_gid <- split(seq_len(ncol(draws_counts)), groups_dt$gid)
  g <- length(idx_by_gid)

  agg_counts <- matrix(NA_real_, nrow = nrow(draws_counts), ncol = g)

  if (na.rm) {
    tmp <- draws_counts
    tmp[is.na(tmp)] <- 0
    j <- 1L
    for (cols in idx_by_gid) {
      agg_counts[, j] <- rowSums(tmp[, cols, drop = FALSE])
      j <- j + 1L
    }
  } else {
    j <- 1L
    for (cols in idx_by_gid) {
      agg_counts[, j] <- rowSums(draws_counts[, cols, drop = FALSE])
      j <- j + 1L
    }
  }

  # Convert to proportions if requested.
  if (!use_count_scale) {
    denom_col <- data_cls$denominator_column
    if (is.null(denom_col) || !nzchar(denom_col)) {
      cli::cli_abort(paste0(
        "`data_cls$denominator_column` must be set when ",
        "`use_count_scale = FALSE`."
      ))
    }
    if (!(denom_col %in% names(data_cls$data))) {
      cli::cli_abort("Denominator column not found in `data_cls$data`.")
    }

    cols_den <- unique(c(region_col, date_col, denom_col))
    den_map <- data_cls$data[, cols_den, with = FALSE]

    data.table::setnames(
      den_map,
      old = c(region_col, date_col, denom_col),
      new = c("region_key", "date_key", "denom"),
      skip_absent = TRUE
    )
    data.table::setkeyv(den_map, c("region_key", "date_key"))

    den_dt <- den_map[keys_dt]
    if (nrow(den_dt) != nrow(keys_dt)) {
      cli::cli_abort("Failed to map denominators onto all sampled rows.")
    }
    if (anyNA(den_dt$denom)) {
      cli::cli_abort("Denominator contains NA for selected rows.")
    }

    denom_by_gid <- tapply(den_dt$denom, groups_dt$gid, sum)
    denom_by_gid <- as.numeric(denom_by_gid)

    if (any(denom_by_gid == 0)) {
      cli::cli_abort("One or more groups has denominator 0.")
    }

    agg_vals <- sweep(agg_counts, 2, denom_by_gid, "/")
  } else {
    agg_vals <- agg_counts
  }

  # Exceedance probability per group: P(agg_vals > threshold).
  ex_prob <- colMeans(agg_vals > threshold, na.rm = FALSE)

  # Output keys: one row per group.
  keys_out <- unique(groups_dt[, c(group_cols, "gid"), with = FALSE])
  data.table::setorder(keys_out, gid)

  out <- keys_out[, group_cols, with = FALSE]
  col_name <- "exceedance_prob"
  if (use_suffix) {
    suf <- if (use_count_scale) "_counts" else "_props"
    col_name <- paste0(col_name, suf)
  }
  out[, (col_name) := unname(ex_prob)]

  out
}
