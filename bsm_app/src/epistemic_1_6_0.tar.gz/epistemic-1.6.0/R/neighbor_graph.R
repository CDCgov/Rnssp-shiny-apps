# © 2025 The Johns Hopkins University Applied Physics Laboratory LLC
# Development of this software was sponsored by the U.S. Government under
# contract no. 75D30124C19958
# As of September 30, 2025 this code is pending review by OTT and should be
# considered JHU Propriety and only for internal JHU/APL use.

#' Generate an filtered adjacency matrix from data_class and an adjacency matrix
#'
#' Validates and reorders a square adjacency matrix so that its rows and columns
#' align with the regions defined in a `data_class` object, and returns this
#' subset of the adjacency matrix.
#'
#' @param dcl_obj A `data_class` object. Must pass `validate_data_class()`.
#' @param adj_matrix A square adjacency matrix (e.g., a `matrix` or `dgCMatrix`)
#'   whose row and column names correspond to region identifiers.
#'
#' @return An object of class \code{inla.graph} which is constructed from a
#'   subset of the originally passed adjacency matrix which has been reordered
#'   and contains only those regions present in
#'   `dcl_obj$data[[dcl_obj$region_column]]`, with rows and columns ordered by
#'   the integer `region_id` assigned in `dcl_obj`. If any region in `dcl_obj`
#'   is not found in `adj_matrix`, the function aborts with an error via
#'   `cli::cli_abort()`.
#'
#' @details 1. Calls `validate_adjacency_matrix(adj_matrix)` to ensure
#'   `adj_matrix` is a proper square matrix with matching row and column names.
#'   2. Calls `validate_data_class(dcl_obj)` to ensure `dcl_obj` has the
#'   required structure and checks that (at least one) region identifier has
#'   been added via \code{add_date_and_region_ids()}; in this documentation, we
#'   assume that this column is `region_id_1`, but this is not required 3.
#'   Checks that every unique region in `dcl_obj$data[[region_column]]` appears
#'   in `colnames(adj_matrix)`; aborts if not. 4. Extracts a unique mapping of
#'   `region_id_1` to region names and orders them by `region_id_1`. 5. Subsets
#'   and reorders `adj_matrix` to match that ordering.
#'
#' @examples
#' \dontrun{
#' # Suppose dc is a data_class with regions "A","B","C"
#' # and am is a 3x3 adjacency matrix with dimnames matching those regions
#' ing <- align_data_and_adjacency(dc, am)
#' }
#'
#' @export
neighbor_graph <- function(dcl_obj, adj_matrix) {
  x <- y <- NULL


  # assert that am is valid
  validate_adjacency_matrix(adj_matrix)

  # assert that dc is valid
  validate_data_class(dcl_obj)

  # assert that the data class object has had region_id(s) added via
  # the package function
  if (
    is.null(attr(dcl_obj, "has_region_ids")) || attr(
      dcl_obj, "has_region_ids"
    ) == FALSE
  ) {
    cli::cli_abort(
      "Use epistemic::add_date_and_region_ids() to add (at least one) region_id"
    )
  }

  # check that all elements of dc$data[[dc$region_column]] are in colnames of am
  missing_regions <- setdiff(
    unique(dcl_obj$data[[dcl_obj$region_column]]),
    colnames(adj_matrix)
  )
  # abort if any missing regions
  if (length(missing_regions) > 0) {
    cli::cli_abort(
      paste0(
        "There are regions in the data_class object that do not appear
      in the adjacency matrix", missing_regions
      )
    )
  }

  # create a subset of am, with the columns and rows in the order of the
  ordered_regions <- dcl_obj$data[
    , .SD,
    .SDcols = c(dcl_obj$region_column, dcl_obj$region_identifiers[1])
  ] |>
    unique() |>
    _[order(x), y, env = list(
      "x" = dcl_obj$region_identifiers[1],
      "y" = dcl_obj$region_column
    )]

  (
    adj_matrix[ordered_regions, ordered_regions]
  )
}
