# © 2025 The Johns Hopkins University Applied Physics Laboratory LLC
# Development of this software was sponsored by the U.S. Government under
# contract no. 75D30124C19958
# As of September 30, 2025 this code is pending review by OTT and should be
# considered JHU Propriety and only for internal JHU/APL use.

#' Draw posterior samples from an INLA model
#'
#' @description
#' `get_posterior_samples()` generates posterior draws from a fitted
#' **INLA** model and returns them in a tidy format for downstream analysis
#' and plotting. Optionally, draws can be returned on the original
#' **count** scale rather than the model’s link/proportion scale.
#'
#' @param inla_model A fitted INLA model from epistemic that was fitted using
#'   allow_sampling = TRUE.
#' @param data_cls Data class object containing training data
#' @param n_samples Integer number of posterior draws to generate. Must be
#'   greater than or equal to 1.
#' @param use_count_scale Logical. If `TRUE` (default), results are provided on
#'   the count scale. If `FALSE` they are provided as proportions.
#' @param regions Array. Array of regions where results should be calculated.
#'   If `NULL`, all regions are used. Default is `NULL`.
#' @param dates Array. Array of dates where results should be calculated.
#'   If `NULL`, all dates are used. Default is `NULL`.
#'
#' @returns
#' A data table of posterior draws with date and region columns from
#' the data class and sample columns "sample_1", "sample_2", etc.
#'
#' @details
#' Internally, this function calls [INLA::inla.posterior.sample()]
#' routine, then reshape/transmute to a tidy format.
#'
#' @examples
#' \dontrun{
#' library(INLA)
#' set.seed(123)
#' # Fit a simple INLA model (placeholder)
#' fit <- inla(y ~ x, data = df, family = "poisson")
#'
#' # Draw 1,000 posterior samples on the count scale
#' draws <- get_posterior_samples(
#'   inla_model = fit,
#'   data_cls = df, # or grouping vector, as your function expects
#'   n_samples = 1000,
#'   use_count_scale = TRUE
#' )
#'
#' # Inspect
#' head(draws)
#' }
#'
#' @export
get_posterior_samples <- function(
  inla_model,
  data_cls,
  n_samples,
  use_count_scale = TRUE,
  regions = NULL,
  dates = NULL
) {
  keep_inds <- get_subset_indices.data_class(data_cls,
    regions = regions,
    dates = dates
  )

  # get the posterior samples, passing the keep_inds to the
  # selection parameter (i.e. Predictors only for the indices of interest)
  samples <- INLA::inla.posterior.sample(n_samples,
    inla_model,
    use.improved.mean = TRUE,
    selection = list("Predictor" = keep_inds)
  )
  # for each sample (which is a list), get the latent param from the list
  linear_predictor_samples <- sapply(samples, function(s) s$latent)
  family <- inla_model$.args$family
  linkinv <- switch(family,
    "binomial" = stats::plogis,
    "betabinomial" = stats::plogis,
    "poisson" = exp,
    "nbinomial" = exp,
    cli::cli_abort("Unsupported family")
  )
  mu_samples <- linkinv(linear_predictor_samples)
  scales <- epistemic::get_scale_factors(data_cls, inla_model)
  scale <- if (use_count_scale) scales$count_scale else scales$prop_scale
  # reduce scale to the correct indices (use keep_inds for this)
  scale <- scale[keep_inds]

  scale <- replicate(n_samples, scale)
  mu_samples <- mu_samples * scale

  region_col <- data_cls$region_column
  date_col <- data_cls$date_column

  # Add sample columns: transpose mu_samples so each column is a sample
  sample_dt <- data.table::as.data.table(mu_samples) # [n_obs x n_samples]
  data.table::setnames(sample_dt, paste0("sample_", seq_len(n_samples)))

  # Combine (be sure to filter on the indices of interest)
  sample_dt[, (region_col) := data_cls$data[[region_col]][keep_inds]]
  sample_dt[, (date_col) := data_cls$data[[date_col]][keep_inds]]

  # Get all other columns (in original order, minus last two)
  samp_cols <- names(sample_dt)[seq_len(ncol(sample_dt) - 2)]

  # Reorder: last two columns first, then the rest
  sample_dt <- data.table::setcolorder(
    sample_dt,
    c(region_col, date_col, samp_cols)
  )

  sample_dt <- epistemic::remove_invalid_estimates(
    sample_dt,
    value_columns = samp_cols,
    inla_model = inla_model,
    use_count_scale = use_count_scale,
    data_class = data_cls
  )

  sample_dt
}


#' Predictive PMF under a Poisson likelihood via INLA marginals
#'
#' @description Computes the posterior predictive **probability mass** \eqn{P(Y
#'   = y)} for each \eqn{y_i} in \code{ys} or, if NULL, from \eqn{0} to an upper
#'   bound \eqn{y_{max}} (estimated by calling [estimate_ymax_from_marginal()]
#'   to decide the support’s upper bound) for a Poisson outcome by integrating
#'   the Poisson PMF over the INLA marginal posterior of the mean/rate parameter
#'   \eqn{\lambda}.
#'
#' @param mu_marg An INLA marginal posterior object for \eqn{\lambda}
#'   (mean/rate), such as those found in `result$marginals.fitted.values[[i]]`
#'   or a custom  marginal returned by **INLA**. It must be compatible with
#'   [INLA::inla.emarginal()].
#'
#' @param ys Integer count at which to evaluate the predictive PMF.
#'
#' @return A numeric vector of length ys giving \eqn{P(Y = y_i)} for each
#'   \eqn{y_i} in ys under the posterior predictive distribution.
#'
#' @details This function evaluates \eqn{E_{\lambda}\{ \mathrm{dpois}(y \mid
#'   \lambda) \}} using [INLA::inla.emarginal()], which performs numerical
#'   integration over the supplied marginal. Inputs should correspond to the
#'   same observation or context for which the marginal was produced.
#'
#' @seealso [INLA::inla.emarginal()], [stats::dpois()]
#' @family predictive PMF helpers
#' @examples
#' \dontrun{
#' # Suppose `fit` is a fitted INLA model and `idx` picks an observation:
#' p_y <- predictive_pmf_poisson(
#'   mu_marg = fit$marginals.fitted.values[[idx]]
#' )
#' }
#'
#' @keywords internal
predictive_pmf_poisson <- function(mu_marg, ys = NULL) {
  if (is.null(ys)) ys <- 0:estimate_ymax_from_marginal(mu_marg)
  INLA::inla.emarginal(
    function(lambda) sapply(ys, \(y) stats::dpois(y, lambda = lambda)),
    mu_marg
  )
}

#' Predictive PMF under a Binomial likelihood via INLA marginals
#'
#' @description Computes the posterior predictive **probability mass** \eqn{P(Y
#'   = y_i)} for each \eqn{y_i} in \code{ys} (or, if NULL, from \eqn{0} to
#'   \eqn{n}) for a Binomial outcome by integrating the Binomial PMF over the
#'   INLA marginal posterior of the success probability \eqn{p}.
#'
#' @param n Integer number of trials used in the Binomial likelihood.
#' @param p_marg An INLA marginal posterior object for \eqn{p} (success
#'   probability), compatible with [INLA::inla.emarginal()].
#' @param ys vector of integer number of successes at which to evaluate the
#'   predictive PMF. Defaults to all values from 0 to n
#'
#' @return A numeric vector of length ys, giving \eqn{P(Y = y_i)} for each
#'   \eqn{y_i} in ys under the posterior predictive distribution.
#'
#' @details Evaluates \eqn{E_{p}\{ \mathrm{dbinom}(y_i \mid n, p) \}} for each
#'   \eqn{y_i} using [INLA::inla.emarginal()]. Ensure `n` matches the
#'   observation/context used to derive `p_marg` (e.g., same exposure or group).
#'
#' @seealso [INLA::inla.emarginal()], [stats::dbinom()]
#' @family predictive PMF helpers
#' @examples
#' \dontrun{
#' p_y <- predictive_pmf_binomial(
#'   n = 20, p_marg = fit$marginals.fitted.values[[idx]]
#' )
#' }
#'
#' @keywords internal
predictive_pmf_binomial <- function(n, p_marg, ys = NULL) {
  if (is.null(ys)) ys <- 0:estimate_ymax_from_marginal(n * p_marg)
  INLA::inla.emarginal(
    function(p) sapply(ys, \(y) stats::dbinom(y, size = n, prob = p)),
    p_marg
  )
}

#' Predictive PMF under a Negative Binomial likelihood via INLA marginals
#'
#' @description Computes the posterior predictive **probability mass** \eqn{P(Y
#'   = y_i)} for each \eqn{y_i} in \code{ys} (or, if NULL, from \eqn{0} to an
#'   upper bound \eqn{y_{max}} (estimated by calling
#'   [estimate_ymax_from_marginal()] to decide the support’s upper bound)) of a
#'   Negative Binomial outcome by integrating the NB PMF over the INLA marginal
#'   posterior of the mean \eqn{\mu}. The dispersion `size` is treated as fixed.
#'
#' @param mu_marg An INLA marginal posterior object for \eqn{\mu} (mean),
#'   compatible with [INLA::inla.emarginal()].
#' @param size Positive dispersion parameter used by [stats::dnbinom()] (often
#'   denoted \eqn{r} or \eqn{\kappa}); larger values imply lower overdispersion.
#'
#' @return A numeric vector of length ys, giving \eqn{P(Y = y_i)} for each
#'   \eqn{y_i} under the posterior predictive distribution.
#'
#' @details Evaluates \eqn{E_{\mu}\{ \mathrm{dnbinom}(y \mid \mu, \texttt{size})
#'   \}} using [INLA::inla.emarginal()].
#'
#' @seealso [INLA::inla.emarginal()], [stats::dnbinom()]
#' @family predictive PMF helpers
#' @examples
#' \dontrun{
#' p_y <- predictive_pmf_nbinomial(
#'   mu_marg = fit$marginals.fitted.values[[idx]], size = 2
#' )
#' }
#'
#' @keywords internal
predictive_pmf_nbinomial <- function(mu_marg, size, ys = NULL) {
  if (is.null(ys)) ys <- 0:estimate_ymax_from_marginal(mu_marg)
  INLA::inla.emarginal(
    function(mu) sapply(ys, \(y) stats::dnbinom(y, mu = mu, size = size)),
    mu_marg
  )
}

#' Predictive pmf for a Beta–Binomial observation model (with Binomial fallback)
#'
#' Computes the predictive pmf for counts \eqn{Y \in \{0,\dots,n\}} under a
#' Beta–Binomial likelihood with mean \eqn{\mu = p} and intra-class correlation
#' (overdispersion) \eqn{\rho \in [0,1)}. The function integrates over the
#' marginal distribution of \eqn{p} (\code{p_marg}). When \code{overdisp_mean}
#' is near zero, it gracefully falls back to the Binomial predictive by calling
#' [predictive_pmf_binomial()].
#'
#' @param n Integer. Number of trials.
#' @param p_marg An INLA marginal for the mean success probability \eqn{p}.
#' @param overdisp_mean Numeric in \eqn{[0,1)}. The Beta–Binomial intra-class
#'   correlation (ICC), denoted \eqn{\rho}. Set \eqn{\rho=0} to recover the
#'   Binomial model (no extra-binomial variation).
#' @param ys Optional integer vector of y values at which to evaluate the pmf.
#'   If omitted, a reasonable support is constructed using
#'   \code{estimate_ymax_from_marginal(n * p_marg)} and clamped to \code{0:n}.
#'
#' @return A numeric vector of predictive probabilities corresponding to
#'   \code{ys}.
#'
#' @details
#' Parameterization: given mean \eqn{\mu} and ICC \eqn{\rho}, the Beta
#' concentration is \eqn{\kappa = 1/\rho - 1} (for \eqn{\rho > 0}), with
#' shape parameters \eqn{\alpha = \mu\kappa} and
#' \eqn{\beta = (1 - \mu)\kappa}.
#'
#' The Beta-Binomial pmf is
#' \deqn{
#'   \Pr(Y = y \mid n, \alpha, \beta)
#'   = \binom{n}{y}
#'     \frac{B(y + \alpha,\, n - y + \beta)}{B(\alpha, \beta)}\;.
#' }
#'
#' For \eqn{\rho \to 0}, the function calls [predictive_pmf_binomial()] to avoid
#' numerical issues and unnecessary computation.
#'
#' @note
#' If you instead work with the Beta concentration \eqn{\kappa}, set
#' \code{overdisp_mean <- 1/(kappa+1)}.
#'
#' @examples
#' \dontrun{
#' ys <- 0:20
#' # Mild overdispersion (rho = 0.05)
#' pmf_bb <- predictive_pmf_betabinomial(
#'   n = 20, p_marg = p_marg,
#'   overdisp_mean = 0.05, ys = ys
#' )
#' sum(pmf_bb) # ~1
#'
#' # Binomial fallback (rho = 0)
#' pmf_b <- predictive_pmf_betabinomial(
#'   n = 20, p_marg = p_marg,
#'   overdisp_mean = 0, ys = ys
#' )
#' all.equal(pmf_b, predictive_pmf_binomial(20, p_marg, ys))
#' }
#'
#' @seealso [predictive_pmf_binomial]
#' @export
predictive_pmf_betabinomial <- function(n, p_marg, overdisp_mean, ys = NULL) {
  if (isTRUE(overdisp_mean <= .Machine$double.eps)) {
    # If no overdispersion, just call your existing binomial version
    return(predictive_pmf_binomial(n, p_marg, ys))
  }

  if (is.null(ys)) ys <- 0:estimate_ymax_from_marginal(n * p_marg)
  ys <- as.integer(pmax(0, pmin(n, ys))) # valid support

  rho <- overdisp_mean

  # Wrap your existing integration logic
  INLA::inla.emarginal(
    function(mu) {
      kappa <- (1 / rho) - 1
      alpha <- pmax(mu * kappa, .Machine$double.eps)
      beta <- pmax((1 - mu) * kappa, .Machine$double.eps)

      sapply(ys, function(y) {
        exp(lchoose(n, y) + lbeta(y + alpha, n - y + beta) - lbeta(alpha, beta))
      })
    },
    p_marg
  )
}

#' Apply predictive PMF evaluation for a list of Poisson marginals
#'
#' @description For each INLA marginal posterior of a Poisson mean/rate
#' parameter \eqn{\lambda}, this function computes the posterior predictive
#' distribution \eqn{P(Y = y)} over a finite support of counts.
#'
#' @param marginals A list of INLA marginal posterior objects, each
#'   corresponding to one observation’s Poisson mean/rate \eqn{\lambda}.
#'   Typically taken from `result$marginals.fitted.values` of a fitted
#'   **INLA** model.
#'
#' @return A list of numeric vectors, one for each element of `marginals`. Each
#'   vector contains posterior predictive probabilities \eqn{P(Y = y)} for
#'   \eqn{y = 0, 1, \dots, y_\text{max}}, where \eqn{y_\text{max}} is chosen via
#'   [estimate_ymax_from_marginal()].
#'
#' @details
#' - Internally, this function:
#' Uses [predictive_pmf_poisson()] to compute each \eqn{P(Y = y)} for \eqn{y =
#' 0, 1, \dots, y_\text{max}}.
#'
#' - The result is a list aligned with the input `marginals`. Each
#' element can be treated as a discrete probability vector (which should
#' approximately sum to 1).
#'
#' - Useful for constructing predictive histograms, checking tail
#' probabilities, or exporting full predictive distributions for further
#' analysis.
#'
#' @seealso [predictive_pmf_poisson()], [estimate_ymax_from_marginal()],
#' [INLA::inla.emarginal()]
#'
#' @examples
#' \dontrun{
#' # Given a fitted INLA model:
#' marginals <- fit$marginals.fitted.values[1:3]
#'
#' preds <- apply_poisson_predictive_pmf(marginals)
#' }
#'
#' @export
apply_poisson_predictive_pmf <- function(marginals) {
  lapply(marginals, \(mu_marg) predictive_pmf_poisson(mu_marg))
}

#' Apply predictive PMF evaluation for a list of Binomial marginals
#'
#' @description For each INLA marginal posterior of a Binomial probability
#' parameter \eqn{p}, this function computes the posterior predictive
#' distribution \eqn{P(Y = y)} over a truncated support \eqn{y = 0, \dots,
#' y_{\max}}, where \eqn{y_{\max}} is chosen using a heuristic designed to
#' capture essentially all of the predictive mass (leaving out only a negligible
#' tail).
#'
#' @param marginals A list of INLA marginal posterior objects, each
#'   corresponding to one observation’s Binomial probability \eqn{p}. Typically
#'   taken from `result$marginals.fitted.values` of a fitted **INLA** model.
#' @param n_vec A numeric scalar or vector of Binomial sizes (number of trials).
#'   If scalar, it is recycled to match the length of `marginals`. Must have the
#'   same length as `marginals` after recycling.
#'
#' @return A list of numeric vectors, one for each element of `marginals`. Each
#'   vector contains posterior predictive probabilities \eqn{P(Y = y)} for
#'   \eqn{y = 0, \dots, y_{\max}}
#'
#' @details
#' - Validates that `n_vec` is numeric and properly aligned with
#' `marginals`. Scalars are recycled automatically.
#' - Each predictive PMF is computed by calling
#' [predictive_pmf_binomial()] once for each marginal.
#' - The result can be used to construct predictive histograms,
#' posterior predictive checks, or summaries such as tail probabilities.
#'
#' @seealso [predictive_pmf_binomial()], [INLA::inla.emarginal()]
#'
#' @examples
#' \dontrun{
#' # Suppose `fit` is a fitted INLA model:
#' marginals <- fit$marginals.fitted.values[1:2]
#'
#' # Single n recycled across both marginals
#' preds <- apply_binomial_predictive_pmf(marginals, n_vec = 20)
#' }
#'
#' @export
apply_binomial_predictive_pmf <- function(marginals, n_vec) {
  if (is.function(n_vec)) {
    cli::cli_abort("`n_vec` is a function (a closure). Pass a numeric scalar or
         vector of binomial sizes.")
  }
  if (length(n_vec) == 1L) {
    n_vec <- rep(n_vec, length(marginals))
  }
  if (!is.numeric(n_vec)) {
    cli::cli_abort(
      "`n_vec` must be numeric (scalar or same length as `marginals`)."
    )
  }
  if (length(marginals) != length(n_vec)) {
    cli::cli_abort("`length(marginals)` must equal `length(n_vec)`
         after recycling a scalar.")
  }

  Map(
    function(n, p_marg) predictive_pmf_binomial(n, p_marg),
    n_vec, marginals
  )
}

#' Apply predictive pmf (Beta–Binomial) across many marginals
#'
#' Applies [predictive_pmf_betabinomial()] elementwise across a list of INLA
#' marginals and corresponding binomial sizes \eqn{n}.
#'
#' @param marginals A list of INLA marginals for p.
#' @param n_vec Numeric scalar or vector of trial counts (same length as
#'   marginals, or scalar recycled).
#' @param overdisp_mean Numeric scalar or vector in [0,1). The Beta–Binomial ICC
#'   (rho). Scalar is recycled to match the length of \code{marginals}.
#'
#' @return A list of numeric vectors containing predictive pmfs, one per
#'   marginal.
#' @export
apply_betabinomial_predictive_pmf <- function(
  marginals, n_vec, overdisp_mean
) {
  # ---- Validate and recycle n_vec ----
  if (is.function(n_vec)) {
    cli::cli_abort(
      "`n_vec` is a function (a closure). Pass a numeric scalar
      or vector of sizes."
    )
  }
  if (length(n_vec) == 1L) n_vec <- rep(n_vec, length(marginals))
  if (!is.numeric(n_vec)) {
    cli::cli_abort(
      "`n_vec` must be numeric (scalar or same length as `marginals`)."
    )
  }
  if (length(marginals) != length(n_vec)) {
    cli::cli_abort(
      "`length(marginals)` must equal `length(n_vec)` after recycling a scalar."
    )
  }

  # ---- Validate and recycle overdisp_mean ----
  if (
    !is.numeric(overdisp_mean) ||
      any(overdisp_mean < 0 | overdisp_mean >= 1, na.rm = TRUE)
  ) {
    cli::cli_abort("`overdisp_mean` must be numeric in [0, 1).")
  }
  if (length(overdisp_mean) == 1L) {
    overdisp_mean <- rep(overdisp_mean, length(marginals))
  } else if (length(overdisp_mean) != length(marginals)) {
    cli::cli_abort(
      "`overdisp_mean` must be scalar or same length as `marginals`."
    )
  }

  # ---- Apply predictive_pmf_betabinomial to each marginal ----
  Map(
    function(n, p_marg, rho) {
      predictive_pmf_betabinomial(n, p_marg, overdisp_mean = rho)
    },
    n_vec, marginals, overdisp_mean
  )
}

#' Apply predictive PMF evaluation for a list of Negative Binomial marginals
#'
#' @description
#' For each INLA marginal posterior of a Negative Binomial mean
#' parameter \eqn{\mu}, this function computes the posterior
#' predictive distribution \eqn{P(Y = y)} over a finite support of
#' counts. The dispersion parameter `size` is treated as fixed.
#'
#' @param marginals A list of INLA marginal posterior objects, each
#'   corresponding to one observation’s Negative Binomial mean
#'   \eqn{\mu}. Typically taken from `result$marginals.fitted.values`
#'   of a fitted **INLA** model.
#' @param size Positive dispersion parameter used by
#'   [stats::dnbinom()] (often denoted \eqn{r} or \eqn{\kappa}).
#'   Larger values imply lower overdispersion. Assumed fixed here.
#'
#' @return A list of numeric vectors, one for each element of
#'   `marginals`. Each vector contains posterior predictive
#'   probabilities \eqn{P(Y = y)} for \eqn{y = 0, 1, \dots,
#'   y_\text{max}}, where \eqn{y_\text{max}} is chosen via
#'   [estimate_ymax_from_marginal()].
#'
#' @details
#' - Internally, this function:
#'   Uses [predictive_pmf_nbinomial()] to compute each
#'   \eqn{P(Y = y)} for \eqn{y = 0, 1, \dots, y_\text{max}}.
#'   where max is estimated using [estimate_ymax_from_marginal()]
#'
#' - If `size` has posterior uncertainty, you may need to integrate
#'   over it externally (e.g., via Monte Carlo).
#'
#' @seealso
#' [predictive_pmf_nbinomial()],
#' [estimate_ymax_from_marginal()],
#' [INLA::inla.emarginal()]
#'
#' @examples
#' \dontrun{
#' # Given a fitted INLA model:
#' marginals <- fit$marginals.fitted.values[1:2]
#'
#' preds <- apply_nbinomial_predictive_pmf(marginals, size = 2)
#' }
#' @export
apply_nbinomial_predictive_pmf <- function(marginals, size) {
  lapply(marginals, \(mu_marg) predictive_pmf_nbinomial(mu_marg, size))
}


#' Estimate an upper bound for the support of a predictive PMF
#'
#' @description
#' Heuristically estimate the maximum count \eqn{y_\text{max}} needed
#' when computing a predictive distribution for count data. The bound
#' is chosen from the posterior marginal of the Poisson/Negative
#' Binomial mean parameter \eqn{\mu}.
#'
#' @param mu_marg An INLA marginal posterior object for the mean
#'   parameter \eqn{\mu}, compatible with [INLA::inla.qmarginal()].
#' @param k Positive numeric factor controlling how many standard
#'   deviations beyond the mean upper quantile are included. Default
#'   is `4`.
#' @param p Probability in \eqn{(0,1)} at which to evaluate the upper
#'   quantile of \eqn{\mu}. Default is `0.999`.
#'
#' @return An integer giving the maximum count \eqn{y_\text{max}} to
#'   use when evaluating predictive PMFs. The result is clipped to be
#'   at least 10.
#'
#' @details
#' The function:
#' - Computes the \eqn{p}-quantile of \eqn{\mu} using
#'   [INLA::inla.qmarginal()].
#' - Adds `k * sqrt(mu_q)` to inflate the bound, then rounds up.
#' - Ensures the result is at least 10 to avoid degenerate supports.
#'
#' This rule of thumb provides a practical upper cutoff so that
#' predictive PMFs cover essentially all posterior mass while keeping
#' computation tractable.
#'
#' @seealso
#' [apply_poisson_predictive_pmf()],
#' [apply_nbinomial_predictive_pmf()],
#' [apply_binomial_predictive_pmf()],
#' [apply_betabinomial_predictive_pmf()],
#' [INLA::inla.qmarginal()]
#'
#' @examples
#' \dontrun{
#' # Suppose `marg` is a marginal posterior for mu:
#' ymax <- estimate_ymax_from_marginal(marg, k = 3, p = 0.995)
#' ymax
#' }
#'
#' @export
estimate_ymax_from_marginal <- function(mu_marg, k = 4, p = 0.999) {
  # Get approximate upper quantile of mu
  mu_q <- INLA::inla.qmarginal(p, mu_marg)
  y_max <- ceiling(mu_q + k * sqrt(mu_q))

  max(10, y_max) # Clip to reasonable range
}


#' Posterior predictive distributions for observations
#'
#' @description
#' Compute posterior predictive distributions for each observation
#' in a fitted INLA model. Supports Poisson, Binomial, and Negative
#' Binomial likelihoods. For each observation, the result is the
#' posterior predictive PMF \eqn{P(Y = y)} evaluated over an
#' appropriate support.
#'
#' @param inla_model A fitted INLA model from epistemic that was fitted using
#'   allow_sampling = TRUE.
#' @param data_cls Data class object containing training data
#' @param regions Array. Array of regions where results should be calculated.
#'   If `NULL`, all regions are used. Default is `NULL`.
#' @param dates Array. Array of dates where results should be calculated.
#'   If `NULL`, all dates are used. Default is `NULL`.
#'
#' @return A list of numeric vectors. Each element corresponds to one
#'   observation and contains the predictive PMF values for that
#'   observation’s outcome distribution.
#'
#' @details
#' - For **Poisson** models, calls
#'   [apply_poisson_predictive_pmf()].
#' - For **Binomial** models, calls
#'   [apply_binomial_predictive_pmf()] with trial sizes extracted
#'   from `data_cls`.
#' - For **Negative Binomial** models, extracts the posterior mean
#'   of the dispersion parameter (`size`) from hyperparameter
#'   summaries, then calls
#'   [apply_nbinomial_predictive_pmf()]. Note: this may be inaccurate when the
#'   variance of dispersion is large.
#' - For **Beta-Binomial** models, extracts the posterior mean
#'   of the overdispersion from hyperparameter
#'   summaries, then calls
#'   [apply_betabinomial_predictive_pmf()]. Note: this may be inaccurate when
#'   the variance of dispersion is large.
#'
#' - Raises an error if the likelihood family is not supported.
#'
#' @seealso
#' [apply_poisson_predictive_pmf()],
#' [apply_binomial_predictive_pmf()],
#' [apply_nbinomial_predictive_pmf()]
#' [apply_betabinomial_predictive_pmf()]
#'
#' @examples
#' \dontrun{
#' # Given a fitted INLA model:
#' preds <- get_posterior_observation_distributions(
#'   inla_model = fit,
#'   data_cls = data_cls,
#'   use_count_scale = TRUE
#' )
#'
#' # Inspect distribution for the first observation
#' preds[[1]]
#' sum(preds[[1]]) # should be ~1
#' }
#'
#' @export
get_posterior_pmfs <- function(
  inla_model,
  data_cls,
  regions = NULL,
  dates = NULL
) {
  # get the indices of interest

  keep_inds <- get_subset_indices.data_class(
    data_cls,
    regions = regions, dates = dates
  )
  # get the model marginals
  marginals <- inla_model$marginals.fitted.values

  # reduce to the marginals of interest
  marginals <- marginals[keep_inds]

  family <- inla_model$.args$family
  if (family == "nbinomial") {
    key <- "size for the nbinomial observations (1/overdispersion)"
    size <- inla_model$summary.hyperpar[key, "mean"]
    posteriors <- apply_nbinomial_predictive_pmf(marginals, size = size)
  } else if (family == "poisson") {
    posteriors <- apply_poisson_predictive_pmf(marginals)
  } else if (family == "binomial") {
    # get the denominators, and be sure to reduces to indices of interest
    dens <- data_cls$data[[data_cls$denominator_column]][keep_inds]
    posteriors <- apply_binomial_predictive_pmf(marginals, n_vec = dens)
  } else if (family == "betabinomial") {
    key <- "overdispersion for the betabinomial observations"
    overdisp <- inla_model$summary.hyperpar[key, "mean"]
    dens <- data_cls$data[[data_cls$denominator_column]][keep_inds]
    posteriors <- apply_betabinomial_predictive_pmf(marginals,
      n_vec = dens,
      overdisp_mean = overdisp
    )
  } else {
    cli::cli_abort("Family not implemented!", class = "invalid_family")
  }
  id_cols <- c(data_cls$region_column, data_cls$date_column)

  # initiate the result data.table. This is a subset of the data_cls object
  # based on keep_inds, and keeping just the region and date columns
  res <- data_cls$data[keep_inds, .SD, .SDcols = id_cols]

  # assign the posterior_pmfs to this result data.table
  posterior_pmfs <- NULL
  res[, posterior_pmfs := posteriors]

  # # remove any invalid values
  res <- epistemic::remove_invalid_estimates(res,
    value_columns = "posterior_pmfs",
    inla_model = inla_model,
    use_count_scale = TRUE,
    data_class = data_cls
  )

  # return the result
  res
}
