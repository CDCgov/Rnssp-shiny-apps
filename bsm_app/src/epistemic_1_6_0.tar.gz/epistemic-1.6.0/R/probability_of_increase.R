# © 2025 The Johns Hopkins University Applied Physics Laboratory LLC
# Development of this software was sponsored by the U.S. Government under
# contract no. 75D30124C19958
# As of September 30, 2025 this code is pending review by OTT and should be
# considered JHU Propriety and only for internal JHU/APL use.

#' Compute Probability That Target Distribution Exceeds Reference by a Threshold
#'
#' Computes the probability that a value drawn from the target distribution
#' exceeds a value drawn from the reference distribution by at least
#' a specified threshold, using numerical integration over their respective
#' probability density functions (PDFs).
#'
#' @param target A numeric matrix representing the target distribution.
#'   Must have two columns named `"x"` (domain values) and `"y"` (PDF values).
#' @param ref A numeric matrix representing the reference distribution.
#'   Same structure as `target`.
#' @param threshold Numeric. The threshold for comparing target and reference
#'   values. Its interpretation depends on the `mode` parameter.
#' @param npts Integer (default 1000). Number of interpolation points used to
#'   densify the `x` grids for both distributions.
#' @param mode Character. One of:
#'   \itemize{
#'     \item \code{"absolute"}: Computes \eqn{P(X_{target} - X_{ref}
#'     \ge \mathrm{threshold})}
#'     \item \code{"relative"}: Computes \eqn{P(X_{target}
#'     \ge (1 + \mathrm{threshold}) \cdot X_{ref})}
#'   }
#'
#' @return A numeric value in \[0, 1\] representing the estimated probability
#'   under the chosen comparison mode.
#'
#' @details
#' The function:
#' \itemize{
#'   \item Interpolates both PDFs over a finely spaced grid of `npts` points.
#'   \item Normalizes both distributions to ensure they integrate to 1.
#'   \item Performs nested integration:
#'     \itemize{
#'       \item In \code{"absolute"} mode: integrates \eqn{P(X_{ref}
#'       \le X_{target} - \mathrm{threshold})}
#'       \item In \code{"relative"} mode: integrates \eqn{P(X_{ref}
#'       \le X_{target} / (1 + \mathrm{threshold}))}
#'     }
#' }
#'
#' This method assumes independence of the two distributions and works best
#' when both distributions are smooth and well-resolved.
#'
#' @examples
#' # Example with normal-like bell curves
#' x <- seq(-3, 3, length.out = 100)
#' target <- cbind(x = x, y = dnorm(x, mean = 0.5, sd = 1))
#' ref <- cbind(x = x, y = dnorm(x, mean = 0, sd = 1))
#'
#' # Absolute difference
#' compute_prob(target, ref, threshold = 0, mode = "absolute")
#'
#' # Relative increase of 10%
#' compute_prob(target, ref, threshold = 0.10, mode = "relative")
#'
#' @export
compute_prob <- function(target,
                         ref,
                         threshold,
                         npts = 1000,
                         mode = c("absolute", "relative")) {
  mode <- match.arg(mode)

  # Densify the x-grids
  fine_grid_target <- seq(
    min(target[, "x"]),
    max(target[, "x"]),
    length.out = npts
  )

  fine_grid_ref <- seq(
    min(ref[, "x"]),
    max(ref[, "x"]),
    length.out = npts
  )

  # Interpolate and normalize target
  f_target_raw <- stats::approxfun(target[, "x"], target[, "y"], rule = 2)
  y_target <- f_target_raw(fine_grid_target)
  area_target <- pracma::trapz(fine_grid_target, y_target)
  y_target <- y_target / area_target
  f_target <- stats::approxfun(fine_grid_target, y_target, rule = 2)

  # Interpolate and normalize reference
  f_ref_raw <- stats::approxfun(ref[, "x"], ref[, "y"], rule = 2)
  y_ref <- f_ref_raw(fine_grid_ref)
  area_ref <- pracma::trapz(fine_grid_ref, y_ref)
  y_ref <- y_ref / area_ref
  f_ref <- stats::approxfun(fine_grid_ref, y_ref, rule = 2)

  # Outer integration using fine grid
  dx1 <- mean(diff(fine_grid_target))
  prob <- 0

  for (x1 in fine_grid_target) {
    if (mode == "absolute") {
      cutoff <- x1 - threshold
    } else if (mode == "relative") {
      cutoff <- x1 / (1 + threshold)
    } else {
      cli::cli_abort("Unsupported mode")
    }

    x2_subset <- fine_grid_ref[fine_grid_ref <= cutoff]
    if (length(x2_subset) > 1) {
      inner <- pracma::trapz(x2_subset, f_ref(x2_subset))
      prob <- prob + f_target(x1) * inner
    }
  }

  prob * dx1
}


#' Compute Probability That Target Normal Exceeds Reference Normal by Threshold
#'
#' Computes the probability that a value from the target normal distribution
#' exceeds a value from the reference normal distribution by a specified
#' threshold, under the assumption that both distributions are independent
#' and normally distributed.
#'
#' @param mean_target Numeric. Mean of the target normal distribution.
#' @param std_target Numeric. Standard deviation of the target normal
#'   distribution.
#' @param mean_ref Numeric. Mean of the reference normal distribution.
#' @param std_ref Numeric. Standard deviation of the reference normal
#'   distribution.
#' @param threshold Numeric. The amount of change required to be considered
#'   significant. Its interpretation depends on the `mode` argument.
#' @param mode Character. One of `"absolute"` or `"relative"`:
#'   \itemize{
#'     \item \code{"absolute"}: Computes \eqn{P(X_{target} - X_{ref}
#'       \ge \mathrm{threshold})}
#'     \item \code{"relative"}: Computes \eqn{P\left(X_{target}
#'       \ge (1 + \mathrm{threshold}) \cdot X_{ref}\right)}
#'       or equivalently \eqn{P(X_{target} - (1 + \mathrm{threshold}) X_{ref}
#'       \ge 0)}
#'   }
#'
#' @return A numeric value in \[0, 1\] representing the analytical probability
#'   under the specified interpretation mode.
#'
#' @details
#' Let \eqn{X_{target} \sim \mathcal{N}(\mu_t, \sigma_t^2)} and
#' \eqn{X_{ref} \sim \mathcal{N}(\mu_r, \sigma_r^2)}, independently.
#'
#' When \code{mode = "absolute"}, the function computes:
#' \deqn{P(X_{target} - X_{ref} \ge \mathrm{threshold}) =
#'       1 - \Phi\left(\frac{\mathrm{threshold} - (\mu_t - \mu_r)}{
#'       \sqrt{\sigma_t^2 + \sigma_r^2}}\right)}
#'
#' When \code{mode = "relative"}, the function computes:
#' \deqn{P(X_{target} \ge (1 + \mathrm{threshold}) \cdot X_{ref}) =
#'       P\left(X_{target} - (1 + \mathrm{threshold}) X_{ref} \ge 0\right)}
#' with mean and variance adjusted accordingly.
#'
#' This provides fast and exact approximations under assumption of normality.
#'
#' @examples
#' # Absolute comparison
#' compute_prob_normal_approx(
#'   mean_target = 1, std_target = 1,
#'   mean_ref = 0, std_ref = 1,
#'   threshold = 0,
#'   mode = "absolute"
#' )
#'
#' # Relative increase of 10%
#' compute_prob_normal_approx(
#'   mean_target = 1.1, std_target = 0.1,
#'   mean_ref = 1.0, std_ref = 0.1,
#'   threshold = 0.10,
#'   mode = "relative"
#' )
#'
#' @export
compute_prob_normal_approx <- function(mean_target,
                                       std_target,
                                       mean_ref,
                                       std_ref,
                                       threshold,
                                       mode = c("absolute", "relative")) {
  mode <- match.arg(mode)

  if (mode == "absolute") {
    diff_mean <- mean_target - mean_ref
    diff_sd <- sqrt(std_target^2 + std_ref^2)
    return(1 - stats::pnorm(threshold, mean = diff_mean, sd = diff_sd))
  }

  if (mode == "relative") {
    # Compute probability that y_target exceeds 1 plus threshold time reference
    # Can approximate as: `P(Y_target - (1 + t) * Y_ref >= 0)`
    adj_mean <- mean_target - (1 + threshold) * mean_ref
    adj_sd <- sqrt(std_target^2 + ((1 + threshold)^2) * std_ref^2)
    return(1 - stats::pnorm(0, mean = adj_mean, sd = adj_sd))
  }

  cli::cli_abort("Unsupported mode in compute_prob_normal_approx")
}

#' Compute Probability of Increase Across All Valid Dates from an INLA Model
#'
#' Computes the probability that the predicted value from a fitted INLA model
#' increases by at least a specified `threshold` over a time window of `dt`
#' days, for each region and for all valid `(target_date, reference_date)` pairs
#' in the dataset.
#'
#' @param inla_model A fitted INLA model object. The model must be trained on
#'        the dataset provided in `data_cls`.
#' @param data_cls A list-like object containing:
#'   \itemize{
#'     \item \code{data}: A \code{data.table} with columns for \code{region} and
#'     \code{date}, and optionally a denominator column for scale conversion.
#'     \item \code{region_column}: Name of the column identifying regions.
#'     \item \code{date_column}: Name of the column identifying dates.
#'     \item \code{denominator_column}: (Optional) Column name used when
#'           converting between count and proportion scales.
#'   }
#'        The data must be in the same row order as used to fit
#'        \code{inla_model}.
#' @param threshold Numeric. Minimum required increase. Its interpretation
#'        depends on \code{scale_mode}.
#' @param dt Integer. Number of days between the target and reference dates
#'        (i.e., \code{reference_date = target_date - dt}).
#' @param scale_mode Character. Specifies how to interpret the \code{threshold}:
#'   \itemize{
#'     \item \code{"absolute_count"}: Threshold is an absolute change in counts.
#'     \item \code{"absolute_prop"}: Threshold is an absolute change in
#'     proportions.
#'     \item \code{"relative"}: Threshold is a relative increase
#'     (e.g., 0.1 = 10%).
#'   }
#'        The appropriate conversion will be applied depending on the model
#'        output scale (counts or proportions).
#' @param npts Integer (default \code{1000}). Number of interpolation points
#'        used for densifying the PDF grids during numerical integration.
#'        Ignored if \code{use_normal_approx = TRUE}.
#' @param use_normal_approx Logical (default \code{FALSE}). If \code{TRUE},
#'        computes probabilities using a normal approximation based on posterior
#'        means and standard deviations. If \code{FALSE}, computes probabilities
#'        using full numerical integration over posterior marginal
#'        distributions.
#' @param use_suffix Logical (default \code{TRUE}). If \code{TRUE}, appends
#'        the scale mode to the name of the output column in the result
#'        instead of using the \code{"change_prob"}.
#' @param regions Array. Array of regions where results should be calculated.
#'        If `NULL`, all regions are used. Default is `NULL`.
#' @param dates Array. Array of dates where results should be calculated.
#'        If `NULL`, all dates are used. Default is `NULL`.
#'
#' @return A \code{data.table} with one row per valid
#' \code{(region, target_date)} pair, containing:
#' \describe{
#'   \item{\code{<region_column>}}{Region identifier, where the column name
#'         matches \code{data_cls$region_column}.}
#'   \item{\code{<date_column>}}{The target date for which the probability of
#'         increase is evaluated. The column name matches
#'         \code{data_cls$date_column}.}
#'   \item{\code{change_prob}}{Estimated probability that the predicted value
#'         at the target date exceeds the value at the reference date by at
#'         least \code{threshold}, interpreted according to \code{scale_mode}.}
#' }
#'
#' @details
#' For each target date in the dataset, the function checks if a corresponding
#' reference date exists exactly \code{dt} days prior. If so, it computes the
#' probability of increase using either:
#' \itemize{
#'   \item A normal approximation (\code{compute_prob_normal_approx()}), or
#'   \item Numerical integration of posterior marginals (\code{compute_prob()}).
#' }
#'
#' The interpretation of \code{threshold} depends on \code{scale_mode}:
#' \itemize{
#'   \item If \code{"absolute_count"} or \code{"absolute_prop"} is used, and the
#'   model’s output scale does not match, the threshold will be converted using
#'   the denominator column (e.g., dividing a count threshold by population to
#'   get a proportion, or multiplying a proportion by population to get a
#'   count).
#'   \item If \code{"relative"} is used, the function computes the probability
#'   that the predicted value has increased by a relative factor (e.g., 0.1
#'   means a 10% increase).
#' }
#'
#' The function assumes that the fitted values in \code{inla_model} are aligned
#' with the rows of \code{data_cls$data}.
#'
#' @examples
#' \dontrun{
#' result <- get_probability_of_increase(
#'   inla_model = my_model,
#'   data_cls = my_data_cls,
#'   threshold = 0.01,
#'   dt = 7,
#'   scale_mode = "absolute_prop",
#'   use_normal_approx = FALSE,
#'   npts = 2000
#' )
#' }
#'
#' @export

get_probability_of_increase <- function(inla_model,
                                        data_cls,
                                        threshold,
                                        dt,
                                        scale_mode = c(
                                          "absolute_count",
                                          "absolute_prop",
                                          "relative"
                                        ),
                                        use_suffix = TRUE,
                                        npts = 1000,
                                        use_normal_approx = FALSE,
                                        regions = NULL,
                                        dates = NULL) {
  scale_mode <- match.arg(scale_mode)

  mean_vals <- mean_vals <- sd_vals <- target_date <- reference_date <- NULL
  change_prob <- mean_target <- mean_ref <- std_ref <- std_target <- NULL
  marginals_target <- marginals_ref <- region <- NULL

  keep_inds <- get_subset_indices.data_class(data_cls,
    regions = regions,
    dates = dates
  )
  # Extract data and metadata
  region_col <- data_cls$region_column
  date_col <- data_cls$date_column
  data <- data.table::copy(data_cls$data)[keep_inds, ]


  # Extract marginals and summary statistics
  marginals <- inla_model$marginals.fitted.values[keep_inds]
  summary_vals <- inla_model$summary.fitted.values[keep_inds, c("mean", "sd")]

  data[, marginals := marginals]
  data[, mean_vals := summary_vals$mean]
  data[, sd_vals := summary_vals$sd]

  # Determine target and reference dates
  all_dates <- unique(data[[date_col]])
  target_dates <- as.Date(intersect(all_dates, all_dates + dt))
  reference_dates <- as.Date(intersect(all_dates, all_dates - dt))

  data_ref <- data[x %in% reference_dates, env = list(x = date_col)]
  data_ref[, target_date := x + dt, env = list(x = date_col)]
  data.table::setnames(data_ref, date_col, "reference_date")

  data_target <- data[x %in% target_dates, env = list(x = date_col)]
  data_target[, reference_date := x - dt, env = list(x = date_col)]
  data.table::setnames(data_target, date_col, "target_date")

  # Extract relevant columns
  data_ref <- data_ref[, list(
    region = x,
    reference_date = reference_date,
    target_date = target_date,
    mean_ref = mean_vals,
    std_ref = sd_vals,
    marginals_ref = marginals
  ), env = list(x = region_col)]

  data_target <- data_target[, list(
    region = x,
    reference_date = reference_date,
    target_date = target_date,
    mean_target = mean_vals,
    std_target = sd_vals,
    marginals_target = marginals
  ), env = list(x = region_col)]

  # Merge target and reference data
  combined_data <- merge(
    data_ref,
    data_target,
    by = c("region", "reference_date", "target_date")
  )

  # Determine effective threshold based on model scale and user intent
  model_scale <- get_model_scale(inla_model) # "count" or "prop"
  if (scale_mode %in% c("absolute_count", "absolute_prop")) {
    if (is.null(data_cls$denominator_column)) {
      cli::cli_abort("The 'denominator_column' must be defined in data_cls for
                     absolute scale comparisons.")
    }
    denom_col <- data_cls$denominator_column

    denom <- data[data[[date_col]] %in% combined_data$target_date][[denom_col]]

    if (length(denom) != nrow(combined_data)) {
      cli::cli_abort("Mismatch between denominator values and target-reference
                     pairs.")
    }

    threshold_adj <- switch(scale_mode,
      absolute_count = (if (model_scale == "prop") {
        threshold / denom
      } else {
        threshold
      }),
      absolute_prop = (if (model_scale == "count") {
        threshold * denom
      } else {
        threshold
      })
    )
  } else {
    threshold_adj <- threshold
  }
  suffix <- scale_mode
  col_name <- "change_prob"
  col_name <- if (use_suffix) paste0(col_name, "_", suffix) else col_name
  # Compute probabilities
  if (use_normal_approx) {
    combined_data[, change_prob := compute_prob_normal_approx(
      mean_target, std_target, mean_ref, std_ref,
      threshold = threshold_adj,
      mode = if (scale_mode == "relative") "relative" else "absolute"
    )]
  } else {
    combined_data[, change_prob := mapply(
      compute_prob,
      marginals_target,
      marginals_ref,
      threshold = threshold_adj,
      npts = npts,
      mode = if (scale_mode == "relative") "relative" else "absolute"
    )]
  }
  # Format output
  combined_data <- combined_data[, list(region, target_date, change_prob)]
  data.table::setnames(combined_data, "region", region_col)
  data.table::setnames(combined_data, "target_date", date_col)
  data.table::setnames(combined_data, "change_prob", col_name)
  join_cols <- c(region_col, date_col)
  original_order <- data_cls$data[keep_inds, .SD, .SDcols = join_cols]
  result <- combined_data[original_order, on = join_cols]

  if (scale_mode == "absolute_count") {
    use_count_scale <- TRUE
  } else if (scale_mode == "absolute_prop") {
    use_count_scale <- FALSE
  } else if (scale_mode == "relative") {
    use_count_scale <- (model_scale == "count")
  } else {
    cli::cli_abort(paste0("Invalid scale mode! ", scale_mode),
      class = "bad_value"
    )
  }
  result <- remove_invalid_estimates(
    data = result,
    value_columns = c(col_name),
    inla_model = inla_model,
    use_count_scale = use_count_scale,
    data_class = data_cls
  )

  result
}
