# © 2025 The Johns Hopkins University Applied Physics Laboratory LLC
# Development of this software was sponsored by the U.S. Government under
# contract no. 75D30124C19958
# As of September 30, 2025 this code is pending review by OTT and should be
# considered JHU Propriety and only for internal JHU/APL use.

#' Compute Credible Intervals from an INLA Model
#'
#' This function computes credible intervals for predicted outcomes from an
#' INLA model, based on the training data used to fit the model. It supports
#' output on the scale of counts or proportions and allows for customizable
#' column naming.
#'
#' @param inla_model A fitted model object returned by [`INLA::inla()`],
#'   representing the INLA model used for prediction.
#' @param data_cls A data class object containing the data used to train
#'  `inla_model`. It should include relevant.
#' @param ci_width A numeric value between 0 and 1 specifying the width of the
#'   credible interval (e.g., `0.95` for a 95\% credible interval).
#' @param use_suffix Logical. If `TRUE` (default), the output column names will
#'   include the `ci_width` and scale as suffixes. If `FALSE`, the column names
#'   will be `"lower"` and `"upper"`.
#' @param use_count_scale Logical. If `TRUE` (default), the credible intervals
#'   will be returned on the **count** scale (e.g., predicted numerator values).
#'   If `FALSE`, results will be returned as **proportions** (i.e., numerator /
#'   denominator).
#' @param regions Array. Array of regions where results should be calculated.
#'   If `NULL`, all regions are used. Default is `NULL`.
#' @param dates Array. Array of dates where results should be calculated.
#'   If `NULL`, all dates are used. Default is `NULL`.
#'
#' @return A `data.table` with the original data plus two additional columns
#'   giving the lower and upper bounds of the credible interval. The column
#'   names depend on the values of `ci_width`, `use_suffix`, and
#'   `use_count_scale`.
#'
#' @details The function extracts the posterior distributions of the predicted
#'   values from the fitted model and computes the credible intervals by
#'   identifying the quantiles corresponding to `(1 - ci_width) / 2` and
#'   `(1 + ci_width) / 2`. These are then optionally rescaled to counts or
#'   proportions based on the `use_count_scale` flag.
#'
#'   If `use_count_scale = TRUE`, the results are scaled using the denominator
#'   (if applicable) to reflect absolute counts.
#'
#'   If `use_suffix = TRUE`, the resulting column names will take the form of
#'   `<scale>_<(1-ci_width)/2>` and `<scale>_<(1+ci_width)/2>`.
#'
#' @examples
#' \dontrun{
#' data("demo_model_result")
#' data("demo_data")
#' ci <- get_credible_intervals(
#'   inla_model = demo_model_result,
#'   data_cls = demo_data,
#'   ci_width = 0.95
#' )
#' head(ci)
#' }
#'
#' @export

get_credible_intervals <- function(inla_model,
                                   data_cls,
                                   ci_width = 0.95,
                                   use_suffix = TRUE,
                                   use_count_scale = TRUE,
                                   regions = NULL,
                                   dates = NULL) {
  # Just pass to get_posterior_quantiles()

  get_posterior_quantiles(
    inla_model = inla_model,
    data_cls = data_cls,
    probs = c(1 - ci_width, 1 + ci_width) / 2,
    use_suffix = use_suffix,
    use_count_scale = use_count_scale,
    regions = regions,
    dates = dates
  )
}


#' Credible intervals for aggregated totals (and proportions)
#'
#' Convenience wrapper around `get_posterior_quantiles_group()` that returns
#' lower and upper credible interval bounds for aggregates defined by
#' `group_cols`.
#'
#' @param inla_model A fitted INLA model object.
#' @param data_cls A data class object.
#' @param ci_width Numeric in (0, 1). For example, 0.95 gives a 95 percent
#'   credible interval.
#' @param use_suffix Logical. If TRUE, suffix columns as
#'   "counts_p" or "props_p", where p represents the tail probability.
#' @param use_count_scale Logical. If TRUE, return aggregate counts.
#'   If FALSE, return aggregate proportions using the denominator column.
#' @param regions Optional region filter. NULL means no filtering.
#' @param dates Optional date filter. NULL means no filtering.
#' @param group_cols Character vector of grouping columns in
#'   data_cls$data.
#' @param n_samples Integer number of posterior samples used for
#'   aggregation.
#' @param na.rm Logical controlling NA handling when summing posterior
#'   draws.
#'
#' @return A data.table with one row per group and two columns containing
#'   the lower and upper credible interval bounds.
#'
#' @export
get_credible_intervals_group <- function(
  inla_model,
  data_cls,
  ci_width = 0.95,
  use_suffix = TRUE,
  use_count_scale = TRUE,
  regions = NULL,
  dates = NULL,
  group_cols,
  n_samples = 1000L,
  na.rm = FALSE
) {
  if (!is.numeric(ci_width) || length(ci_width) != 1L) {
    cli::cli_abort("`ci_width` must be a single numeric value.")
  }
  if (ci_width <= 0 || ci_width >= 1) {
    cli::cli_abort("`ci_width` must be in (0, 1).")
  }

  probs <- c((1 - ci_width) / 2, (1 + ci_width) / 2)

  get_posterior_quantiles_group(
    inla_model = inla_model,
    data_cls = data_cls,
    probs = probs,
    use_suffix = use_suffix,
    use_count_scale = use_count_scale,
    regions = regions,
    dates = dates,
    group_cols = group_cols,
    n_samples = n_samples,
    na.rm = na.rm
  )
}
