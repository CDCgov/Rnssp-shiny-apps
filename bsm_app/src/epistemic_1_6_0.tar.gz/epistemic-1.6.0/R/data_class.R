# © 2025 The Johns Hopkins University Applied Physics Laboratory LLC
# Development of this software was sponsored by the U.S. Government under
# contract no. 75D30124C19958
# As of September 30, 2025 this code is pending review by OTT and should be
# considered JHU Propriety and only for internal JHU/APL use.

#' Create a data_class object
#'
#' Bundles a dataframe with metadata about relevant column names for modeling
#' and postprocessing workflows.
#'
#' @param data A \code{data.frame or data.table} containing the data used to fit
#'   an INLA model.
#' @param region_column A string specifying the name of the column in
#'   \code{data} that contains region identifiers.
#' @param date_column A string specifying the name of the column in \code{data}
#'   that contains date values. Must be of class \code{Date} or \code{POSIXt}.
#' @param numerator_column A string specifying the name of the column in
#'   \code{data} that contains modeled counts (numerators).
#' @param denominator_column A string specifying the name of the column in
#'   \code{data} that contains denominators used for offsetting (e.g.,
#'   population or exposure) for some distribution families.
#' @param expected_column A string specifying the name of the column in
#'   \code{data} that contains expected values used for offsetting (e.g.,
#'   population or exposure) for some distribution families.
#' @param feature_columns A character vector specifying names of columns in
#'   \code{data} to be used as features in modeling.
#' @param generate_expected (default \code{FALSE}); set to \code{TRUE} to have
#'   the expected values be generated from the date and region columns; if an
#'   expected column is also passed, this will be replaced with a new
#'   calculation of expected using the same column name
#'
#' @return An object of class \code{data_class}.
#' @details The function checks that all specified columns exist in the input
#'   data and validates their types. The resulting object can be used in
#'   downstream modeling and analysis workflows.
#'
#' @examples
#' df <- data.frame(
#'   id = 1:5,
#'   region = letters[1:5],
#'   date = as.Date("2025-01-01"),
#'   num = rnorm(5),
#'   den = rnorm(5)
#' )
#' obj <- data_class(
#'   df,
#'   region_column = "region",
#'   date_column = "date",
#'   numerator_column = "num",
#'   denominator_column = "den",
#'   feature_columns = c()
#' )
#' rate_values <- obj$data[[obj$numerator_column]] /
#'   obj$data[[obj$denominator_column]]
#' obj <- add_column(obj, "rate", rate_values, add_to_features = TRUE)
#' print(obj)
#'
#' @export
data_class <- function(data,
                       region_column,
                       date_column,
                       numerator_column,
                       denominator_column,
                       expected_column = NULL,
                       feature_columns = NULL,
                       generate_expected = FALSE) {
  # avoid no visible binding error
  d <- n <- NULL

  # Validate input types
  if (!is.data.frame(data)) {
    cli::cli_abort("`data` must be a data.frame")
  }

  # Validate presence of specified columns
  check_names(data, c(
    region_column,
    date_column,
    numerator_column,
    denominator_column,
    expected_column,
    feature_columns
  ))

  if (!inherits(data[[date_column]], c("Date", "POSIXt"))) {
    cli::cli_abort("`date_column` must be of class Date or POSIXt")
  }

  for (col in c(numerator_column, denominator_column, expected_column)) {
    if (!is.numeric(data[[col]])) {
      cli::cli_abort(sprintf("Column '%s' must be numeric", col))
    }
  }

  data <- data.table::as.data.table(data)
  data[
    ,
    let(
      d = as.double(d),
      n = as.double(n)
    ),
    env = list(d = denominator_column, n = numerator_column)
  ]

  # Return structured object
  obj <- structure(
    list(
      data = data,
      region_column = region_column,
      date_column = date_column,
      numerator_column = numerator_column,
      denominator_column = denominator_column,
      expected_column = expected_column,
      feature_columns = feature_columns,
      other_ids = character(0)
    ),
    class = "data_class"
  )

  if (generate_expected) {
    if (is.null(obj$expected_column)) {
      obj <- add_expected(obj)
    } else {
      obj <- add_expected(obj, varname = obj$expected_column, replace = TRUE)
    }
  }

  obj
}

#' @export
print.data_class <- function(x, ...) {
  sh <- dim(x$data)
  cat("An object of class 'data_class'\n")
  cat("Region column:", x$region_column, "\n")
  cat("Date column:", x$date_column, "\n")
  cat("Numerator column:", x$numerator_column, "\n")
  cat("Denominator column:", x$denominator_column, "\n")
  cat("Expected column:", x$expected_column, "\n")
  cat("Feature columns:", paste(x$feature_columns, collapse = ", "), "\n")
  if (
    !is.null(attr(x, "has_region_ids")) &&
      attr(x, "has_region_ids") == TRUE
  ) {
    cat(
      "Region Identifiers:",
      paste(x$region_identifiers, collapse = ", "),
      "\n"
    )
  }
  if (
    !is.null(attr(x, "has_date_ids")) &&
      attr(x, "has_date_ids") == TRUE
  ) {
    cat(
      "Date Identifiers:",
      paste(x$date_identifiers, collapse = ", "),
      "\n"
    )
  }
  attrs <- c(
    "has_dow_id", "has_dow_ids",
    "has_doy_id", "has_doy_ids",
    "has_week_ids", "has_year_ids"
  )
  if (
    any(vapply(attrs, \(a) isTRUE(attr(x, a)), logical(1))) &&
      length(x$other_ids %||% character(0)) > 0
  ) {
    cat("Other Identifiers:", paste(x$other_ids, collapse = ", "), "\n")
  }

  cat(paste0("Data (first ", min(6, sh[1]), " of ", sh[1], " rows):\n"))
  print(utils::head(x$data |> _[]))
}

#' Add a new column to a data_class object
#' @param obj A \code{data_class} object.
#' @param column_name A string specifying the name of the new column to be
#'   added.
#' @param values A vector of values for the new column. Must be the same length
#'   as the number of rows in \code{obj$data}.
#' @param add_to_features Logical; if \code{TRUE}, the new column will be added
#'   to the list of feature columns.
#' @param in_place Logical (default \code{TRUE}). If \code{TRUE} and
#'   \code{obj} is passed as a symbol, update that object in the caller
#'   environment. If \code{FALSE}, return an updated copy without mutating the
#'   caller's object.
#' @param replace logical (default \code{FALSE}), set to \code{TRUE} to
#'   replace an existing column
#' @param ... not used
#'
#' @method add_column data_class
#' @rdname add_column
#' @export

add_column.data_class <- function(
  obj,
  column_name,
  values,
  add_to_features = TRUE,
  in_place = TRUE,
  replace = FALSE,
  ...
) {
  # Input validation
  if (!inherits(obj, "data_class")) {
    cli::cli_abort("Object must be of class 'data_class'")
  }
  if (!is.character(column_name) || length(column_name) != 1) {
    cli::cli_abort("`column_name` must be a single string")
  }
  if (length(values) != nrow(obj$data)) {
    cli::cli_abort("Length of `values` must match number of rows in `data`")
  }
  if (column_name %in% names(obj) && replace == FALSE) {
    cli::cli_abort(paste0(column_name, " already exists in `data`"))
  }

  if (!isTRUE(in_place)) {
    obj$data <- data.table::copy(data.table::as.data.table(obj$data))
  }
  obj$data[, let(x = values), env = list(x = column_name)]

  # Optionally include it in the feature columns
  if (add_to_features) {
    obj$feature_columns <- unique(c(obj$feature_columns, column_name))
  }

  obj
}

#' Add column to data_class object

#' @param obj A \code{data_class} object.
#' @param ... passed on to methods
#'
#' @return An updated \code{data_class} object with the new column added.

#' @export
add_column <- function(obj, ...) {
  UseMethod("add_column")
}

#' @export
add_column.default <- function(obj, ...) {
  cli::cli_abort("Object must be of class 'data_class'")
}

.maybe_assign_in_place <- function(obj_expr, obj, in_place, env) {
  if (isTRUE(in_place) && is.symbol(obj_expr)) {
    assign(as.character(obj_expr), obj, envir = env)
  }
  obj
}

.append_other_ids <- function(obj, ids) {
  if (is.null(ids) || length(ids) == 0) {
    return(obj)
  }
  cur_ids <- obj$other_ids %||% character(0)
  obj$other_ids <- unique(c(cur_ids, as.character(ids)))
  obj
}

#' Generate Expected Counts for a data_class Object
#'
#' Calculates expected cell counts based on the marginal sums of the numerator
#' and denominator variables defined within a `data_class` object, merges them
#' into the object’s data, and records the name of the new column.
#' @param obj A `data_class` object. Must inherit from class `"data_class"`.
#' @param varname A string. Name of the new column to hold expected counts.
#'   Defaults to `"expected"`.
#' @param replace Logical. If `FALSE` (the default), the function will abort if
#'   `varname` already exists in `obj$data`. If `TRUE`, the existing column will
#'   be overwritten.
#' @return The original `data_class` object, with `obj$data` augmented by a new
#'   column of expected counts, and `obj$expected_column` set to `varname`.
#' @details 1. Checks that `obj` has class `"data_class"`, aborting otherwise.
#' 2. Computes the marginal total of the numerator by time (`tc`) and the
#' marginal total of the denominator by region (`rc`). 3. Computes the overall
#' denominator total `N`. 4. Joins these margins to form expected counts `e =
#' (n_i * m_j) / N`. 5. Merges the expected counts back into `obj$data` on `(rc,
#' tc)`.
#'
#' @examples
#' df <- data.frame(
#'   region = c("A", "A", "B", "B"),
#'   date   = as.Date(c("2024-01-01", "2024-01-08")),
#'   num    = c(10, 20, 30, 40),
#'   den    = c(100, 200, 300, 400)
#' )
#' obj <- data_class(
#'   data = df,
#'   region_column = "region",
#'   date_column = "date",
#'   numerator_column = "num",
#'   denominator_column = "den"
#' )
#' dc <- add_expected(obj, varname = "exp_count")
#'
#' @method add_expected data_class
#' @rdname add_expected
#' @export
add_expected.data_class <- function(
  obj,
  varname = "expected",
  replace = FALSE,
  ...
) {
  v <- x <- y <- NULL

  if (inherits(obj, "data_class") == FALSE) {
    cli::cli_abort("must pass object of class `data_class`")
  }

  if (varname %in% names(obj$data)) {
    if (replace == FALSE) {
      cli::cli_abort(paste0("there is already a column named `", varname, "`"))
    }
    obj$data[, v := NULL, env = list(v = varname)]
  }

  rc <- obj$region_column
  tc <- obj$date_column
  den <- obj$denominator_column
  num <- obj$numerator_column

  # get marginal by time
  m <- obj$data[
    , list(i = 1, n = as.double(sum(x, na.rm = TRUE))),
    by = tc, env = list("x" = num)
  ]
  # get marginal by region
  n <- obj$data[
    , list(i = 1, m = as.double(sum(x, na.rm = TRUE))),
    by = rc, env = list("x" = den)
  ]
  # get overall total
  total <- obj$data[, as.double(sum(x, na.rm = TRUE)), env = list("x" = den)]

  # get expected cells
  e <- m[
    n,
    on = "i",
    list(x, y, e = n * m / total),
    allow.cartesian = TRUE,
    env = list(x = rc, y = tc, e = varname)
  ]
  # merge expected onto original
  expected_vals <- merge(obj$data, e, by = c(rc, tc), all.x = TRUE)[[varname]]

  obj <- add_column(
    obj,
    column_name = varname,
    values = expected_vals,
    replace = replace,
    add_to_features = FALSE
  )

  obj$expected_column <- varname

  obj
}


#' Add expected to data_class object

#' @param obj A \code{data_class} object.
#' @param ... passed on to methods
#'
#' @return An updated \code{data_class} object with the expected column added

#' @export

add_expected <- function(obj, ...) {
  UseMethod("add_expected")
}

#' @export
add_expected.default <- function(obj, ...) {
  cli::cli_abort("Object must be of class 'data_class'")
}


#' Add Date and Region Identifier Columns
#'
#' Adds one or more pairs of date and region identifier columns to a
#' `data_class`-style object based on the sorted unique values of the
#' original date and region columns. Also records the names of the new
#' identifier columns in the object.
#'
#' @param obj A `data_class` object containing at least these fields:
#'   - `data`: a data.table
#'   - `date_column`: name of the date column in `data`
#'   - `region_column`: name of the region column in `data`
#' @param num_duplicates Integer scalar. Number of duplicate identifier
#'   column pairs to add. Default is 1.
#' @param suffix Character string. Suffix inserted between the original
#'   column name and the duplicate index. Default is "_id_".
#' @param in_place Logical (default \code{TRUE}). If \code{TRUE} and
#'   \code{obj} is passed as a symbol, update that object in the caller
#'   environment. If \code{FALSE}, return an updated copy without mutating the
#'   caller's object.
#'
#' @return The original object, with the following modifications:
#'   - One or more new date identifier columns named
#'     `<date_column><suffix><k>` for k in 1:`num_duplicates`.
#'   - One or more new region identifier columns named
#'     `<region_column><suffix><k>` for k in 1:`num_duplicates`.
#'   - A `region_identifiers` field listing the names of the new region
#'     identifier columns.
#'   - A `date_identifiers` field listing the names of the new date
#'     identifier columns.
#'   Returns the modified object. With \code{in_place = TRUE}, the input object
#'   is also updated in the caller environment (when passed by symbol).
#'
#' @details
#' 1. Computes integer IDs for each unique date value and each unique region
#'    value in `obj$data`.
#' 2. Adds `num_duplicates` copies of these IDs as new columns via
#'    `add_column()`.
#' 3. Records the names of the new identifier columns in the
#'    `region_identifiers` and `date_identifiers` fields of the object.
#'
#' @examples
#' \dontrun{
#' # Assume dc is a valid data_class object
#' dc2 <- add_date_and_region_ids(dc, num_duplicates = 2, suffix = "_idx_")
#' }
#'
#' @export
add_date_and_region_ids <- function(
  obj,
  num_duplicates = 1,
  suffix = "_id_",
  in_place = TRUE
) {
  obj_expr <- substitute(obj)
  date_ids <- match(
    obj$data[[obj$date_column]],
    sort(unique(obj$data[[obj$date_column]]))
  )
  region_ids <- match(
    obj$data[[obj$region_column]],
    sort(unique(obj$data[[obj$region_column]]))
  )

  for (k in 1:num_duplicates) {
    obj <- add_column(
      obj = obj,
      column_name = paste0(obj$date_column, suffix, k),
      values = date_ids,
      in_place = in_place,
      add_to_features = FALSE
    )
    obj <- add_column(
      obj = obj,
      column_name = paste0(obj$region_column, suffix, k),
      values = region_ids,
      in_place = in_place,
      add_to_features = FALSE
    )
  }

  obj[["region_identifiers"]] <- paste0(
    obj$region_column,
    suffix,
    seq(1, num_duplicates)
  )
  obj[["date_identifiers"]] <- paste0(
    obj$date_column,
    suffix,
    seq(1, num_duplicates)
  )
  data.table::setattr(obj, "has_region_ids", TRUE)
  data.table::setattr(obj, "has_date_ids", TRUE)

  .maybe_assign_in_place(obj_expr, obj, in_place, parent.frame())
}


#' Validate a data_class Object
#'
#' Ensures that an object conforms to the minimal structure of a `data_class`:
#' 1. Inherits from class `"data_class"`. 2. Is a named list containing at least
#' `"data"`, `"region_column"`, and `"date_column"`. 3. Has `data` as a
#' `data.table`. 4. Has `region_column` and `date_column` as length-1 character
#' strings. 5. The specified region and date columns exist in `data` and are of
#' the correct class (character and date, respectively).
#'
#' @param dc An object to validate as a `data_class`.
#'
#' @return Invisibly returns `TRUE` if all checks pass.
#'
#' @details If any of the requirements are not met, the function aborts with an
#' informative error message via `cli::cli_abort()`.
#'
#' @export
validate_data_class <- function(dc) {
  # check class
  if (!inherits(dc, "data_class")) {
    cli::cli_abort(
      "Object must inherit from class 'data_class'",
      class = "data_class_invalid"
    )
  }
  # check it's a named list
  if (!is.list(dc) || is.null(names(dc))) {
    cli::cli_abort(
      "Object must be a named list",
      class = "data_class_invalid"
    )
  }
  # required elements
  required <- c("data", "region_column", "date_column")
  missing <- setdiff(required, names(dc))
  if (length(missing) > 0) {
    cli::cli_abort(
      "Object is missing required elements: {paste(missing, collapse = ', ')}",
      class = "data_class_invalid"
    )
  }
  # check data element
  if (!data.table::is.data.table(dc$data)) {
    cli::cli_abort(
      "Element 'data' must be a data.table",
      class = "data_class_invalid"
    )
  }

  # check region_column and date_column types
  if (!is.character(dc$region_column) || length(dc$region_column) != 1) {
    cli::cli_abort(
      "Element 'region_column' must be a length-1 character string",
      class = "data_class_invalid"
    )
  }
  if (!is.character(dc$date_column) || length(dc$date_column) != 1) {
    cli::cli_abort(
      "Element 'date_column' must be a length-1 character string",
      class = "data_class_invalid"
    )
  }
  # check that those columns exist in the data
  if (!(dc$region_column %in% colnames(dc$data))) {
    cli::cli_abort(
      "Column '{dc$region_column}' not found in data",
      class = "data_class_invalid"
    )
  }
  if (!(dc$date_column %in% colnames(dc$data))) {
    cli::cli_abort(
      "Column '{dc$date_column}' not found in data",
      class = "data_class_invalid"
    )
  }
  # check that region column is character
  if (!is.character(dc$data[[dc$region_column]])) {
    cli::cli_abort(
      "Column '{dc$region_column}' must be of type character",
      class = "data_class_invalid"
    )
  }
  # check that date column is Date
  if (!inherits(dc$data[[dc$date_column]], "Date")) {
    cli::cli_abort(
      "Column '{dc$date_column}' must be of class Date",
      class = "data_class_invalid"
    )
  }


  invisible(TRUE)
}


#' Add Missing and Future Dates to a data_class Object
#'
#' Extends a \code{data_class} object's data by generating additional future
#' rows for each region, based on a specified frequency or by inferring the
#' existing frequency. Optionally populates the new rows with constant
#' numerator and/or denominator values, and forward-fills other columns.
#'
#' @param num_future_steps Integer scalar. Number of future time steps to add
#'   beyond the maximum date present in \code{dc$data}.
#' @param dc A \code{data_class} object. Must pass
#'   \code{validate_data_class()}.
#' @param freq Character. One of \code{"infer"}, \code{"daily"}, or
#'   \code{"weekly"}. If \code{"infer"}, the function calls \code{infer_freq()}
#'   on the existing dates to determine the time increment. If \code{"daily"},
#'   a one-day increment is used; if \code{"weekly"}, a seven-day increment is
#'   used.
#' @param num_fill_val Optional numeric scalar. If non-\code{NULL}, sets the
#'   \code{numerator_column} value to \code{num_fill_val} for all rows with
#'   NA values in the numerator column.  Using this is generally not recommended
#'   since the model can provide estimates even when the numerator is missing.
#' @param den_fill_val Optional numeric scalar. If non-\code{NULL}, sets the
#'   \code{denominator_column} value to \code{den_fill_val} for all rows with
#'   NA values in the numerator column. Setting this to 1 is recommended when
#'   using certain model types to ensure that an estimate is generated.
#' @param forward_fill Logical (default = \code{TRUE}). Whether to forward-fill
#'   all columns other than the date, region, numerator, and denominator
#'   columns. Useful for static features, additional identifiers, or calculated
#'   columns like expected value.
#' @param update_date_region_ids Logical (default = \code{TRUE}). If
#'   \code{TRUE}, updates any date and region identifiers so that new rows for
#'   future dates are not missing these fields.
#'
#' @return A \code{data_class} object, identical to \code{dc} except that
#'   \code{num_future_steps} additional time steps have been appended for each
#'   region. Newly added rows have \code{NA} in all original columns except for
#'   any of \code{numerator_column} or \code{denominator_column} that were
#'   populated via \code{num_fill_val} or \code{den_fill_val}. The returned
#'   object’s \code{data} slot has its \code{date_column} extended with all
#'   combinations of region and date.
#'
#' @details
#' The function performs the following steps:
#' \enumerate{
#'   \item Validates that \code{dc} inherits from class \code{"data_class"}.
#'   \item Copies \code{dc} using \code{copy_data_class()} to avoid modifying
#'         the original object.
#'   \item Extracts existing region and date combinations.
#'   \item Determines time frequency from \code{freq}, calling
#'         \code{infer_freq()} if needed.
#'   \item Builds a complete date sequence extended by
#'         \code{num_future_steps}.
#'   \item Constructs a Cartesian join of all regions with the full date range.
#'   \item Merges the original data into this full (region, date) grid via
#'         left join.
#'   \item For any newly created rows:
#'         \itemize{
#'           \item Sets numerator values if \code{num_fill_val} is provided.
#'           \item Sets denominator values if \code{den_fill_val} is provided.
#'           \item Forward-fills additional columns if
#'              \code{forward_fill = TRUE}.
#'           \item Updates region/date identifiers if
#'                 \code{update_date_region_ids = TRUE}.
#'         }
#' }
#'
#' @examples
#' \dontrun{
#' data("demo_data")
#' dc <- demo_data
#'
#' # Add 4 daily steps (if existing data are daily); do not fill num/den
#' dc_future1 <- add_missing_and_future_dates(
#'   num_future_steps = 4,
#'   dc = dc,
#'   freq = "infer"
#' )
#'
#' # Add 2 weekly steps and fill new numerators with 0, denominators with 1
#' dc_future2 <- add_missing_and_future_dates(
#'   num_future_steps = 2,
#'   dc = dc,
#'   freq = "weekly",
#'   num_fill_val = NA,
#'   den_fill_val = 1
#' )
#' }
#'
#' @export

add_missing_and_future_dates <- function(
  num_future_steps,
  dc,
  freq = c("infer", "daily", "weekly"),
  num_fill_val = NULL,
  den_fill_val = NULL,
  forward_fill = TRUE,
  update_date_region_ids = TRUE
) {
  # declare global variables for linting
  x <- NULL

  # validated the passed data_class_object
  validate_data_class(dc)

  # make a copy of it
  obj <- copy_data_class(dc)

  # get the unique dates
  dates <- obj$data[[obj[["date_column"]]]] |> unique()

  # match the passed frequency
  freq <- match.arg(freq)

  # get the increment, inferring if necessary
  if (freq == "infer") {
    increment <- infer_freq(obj$data[[obj[["date_column"]]]])
  } else if (freq == "weekly") {
    increment <- 7
  } else if (freq == "daily") {
    increment <- 1
  } else {
    cli::cli_abort("invalid frequency")
  }

  # Create full sequence of dates
  min_date <- min(dates)
  max_date <- max(dates)
  all_dates <- seq.Date(
    min_date,
    max_date + num_future_steps * as.integer(increment),
    by = increment
  )

  # Create all combinations of region and date
  regions <- obj$data[, unique(x), env = list(x = obj$region_column)]

  full_grid <- data.table::CJ(date = all_dates, region = regions)
  obj$data <- merge(
    obj$data,
    full_grid,
    by.x = c(obj$region_column, obj$date_column),
    by.y = c("region", "date"),
    all.y = TRUE,
  )
  numerator_source <- denominator_source <- NULL
  # replace numerator NA in new dates only, if requested
  date_col <- obj$date_column
  if (!is.null(num_fill_val)) {
    num_col <- obj$numerator_column

    impute_mask <- (
      is.na(obj$data[[num_col]]) & (obj$data[[date_col]] <= max_date)
    )

    forecast_mask <- (
      is.na(obj$data[[num_col]]) & obj$data[[date_col]] > max_date
    )

    obj$data[impute_mask | forecast_mask, (num_col) := num_fill_val]
    obj$data[, numerator_source := 0] # original
    obj$data[impute_mask, numerator_source := 1] # imputed
    obj$data[forecast_mask, numerator_source := 2] # forecast
  }

  # replace denominator NA in new dates only, if requested
  if (!is.null(den_fill_val)) {
    den_col <- obj$denominator_column
    impute_mask <- (
      is.na(obj$data[[den_col]]) & (obj$data[[date_col]] <= max_date)
    )
    forecast_mask <- (
      is.na(obj$data[[den_col]]) & obj$data[[date_col]] > max_date
    )
    obj$data[impute_mask | forecast_mask, (den_col) := den_fill_val]
    obj$data[, denominator_source := 0] # original
    obj$data[impute_mask, denominator_source := 1] # imputed
    obj$data[forecast_mask, denominator_source := 2] # forecast
  }

  if (update_date_region_ids == TRUE) {
    obj <- update_date_region_ids(obj)
  }
  if (forward_fill) {
    dt <- obj$data
    data.table::setorderv(dt, cols = c(obj$region_column, obj$date_column))

    fill_columns <- setdiff(
      names(dt),
      c(
        obj$region_column,
        obj$date_column,
        obj$numerator_column,
        obj$denominator_column
      )
    )

    dt[, (fill_columns) := lapply(.SD, function(col) {
      # Replace NA with last non-NA (forward fill)
      if (all(is.na(col))) {
        col # leave as is if all values are NA
      } else {
        Reduce(function(x, y) ifelse(is.na(y), x, y), col, accumulate = TRUE)
      }
    }),
    by = c(obj[["region_column"]]), .SDcols = fill_columns
    ]

    data.table::setattr(obj, "data", dt)
  }
  obj
}

#' Update Date and Region ID Columns Based on Existing Identifiers
#'
#' For a \code{data_class} object with an attribute \code{has_region_ids =
#' TRUE}, this function re-generates all requested date/region ID columns by
#' calling \code{add_date_and_region_ids()} with the same number of duplicates
#' and the same suffix as inferred from the first entry of
#' \code{obj$region_identifiers}. If \code{has_region_ids} is \code{NULL} or
#' \code{FALSE}, the object is returned unchanged. If \code{has_region_ids =
#' TRUE} but \code{obj$region_identifiers} is empty, an error is thrown.
#'
#' @param obj A \code{data_class} object. Must have been created via
#'   \code{data_class()} (so that \code{obj$region_column} and
#'   \code{obj$region_identifiers} exist).
#'
#' @return A \code{data_class} object. If \code{attr(obj, "has_region_ids")} is
#'   \code{NULL} or \code{FALSE}, returns \code{obj} unchanged. If it is
#'   \code{TRUE}, returns a new \code{data_class} with ID columns re-generated
#'   via \code{add_date_and_region_ids()} for the same number of duplicates.
#'
#' @details 1. Reads \code{has_region_ids <- attr(obj, "has_region_ids")}. 2. If
#' \code{has_region_ids} is \code{NULL} or \code{FALSE}, immediately returns
#' \code{obj} without modification. 3. Otherwise, sets \code{num_ids <-
#' length(obj$region_identifiers)}. 4. If \code{num_ids == 0}, throws an error
#' with message \code{"data_class object hasregion_ids attribute is TRUE, but no
#' region_ids"}. 5. Constructs \code{suffix} by stripping
#' \code{obj$region_column} and the digit \code{"1"} from the first element of
#' \code{obj$region_identifiers}.
#' 6. Calls \code{add_date_and_region_ids(obj, num_duplicates = num_ids,
#'    suffix = suffix)} and returns the result.
#'
#' @examples
#' \dontrun{
#' # Suppose dc is a data_class and we manually set has_region_ids:
#' dc <- data("demo_data")
#' attr(dc, "has_region_ids") <- TRUE
#' # If region_identifiers already has length 1, update_date_region_ids()
#' # will regenerate date_id_1 and region_id_1 (with same suffix).
#' updated <- update_date_region_ids(dc)
#'
#' # If has_region_ids is FALSE or missing, returns unchanged:
#' dc2 <- demo_data
#' out <- update_date_region_ids(dc2) # same object back
#' }
#'
#' @export
update_date_region_ids <- function(obj) {
  has_region_ids <- attr(obj, "has_region_ids")

  # just return the object if there are no region ids
  if (is.null(has_region_ids) || has_region_ids == FALSE) {
    return(obj)
  }

  num_ids <- length(obj$region_identifiers)
  if (num_ids == 0) {
    cli::cli_abort(
      "data_class object has_region_ids attribute is TRUE, but no region_ids"
    )
  }
  suffix <- sub(obj$region_column, "", obj$region_identifiers[1])
  suffix <- sub("1", "", suffix)
  obj <- add_date_and_region_ids(
    obj = obj, num_duplicates = num_ids, suffix = suffix
  )
  obj
}

#' Get subset indices of data_class$data
#'
#' This function returns the row indices of data_class$data where the
#' region_column matches any of the values in regions and date_column matches
#' any of the values in dates.
#'
#' @param obj A \code{data_class} object.
#' @param regions A character vector of region names to filter by. If NULL, no
#'   filtering is done.
#' @param dates A Date vector of dates to filter by. If NULL, no filtering is
#'   done.
#' @param ... Unused; present for S3 method consistency.
#'
#' @return A numeric vector of row indices of the filtered data.
#'
#' @examples
#' # Minimal reproducible example
#' obj <- structure(
#'   list(
#'     data = data.table::data.table(
#'       region = c("A", "B", "B", "C"),
#'       date = as.Date(c(
#'         "2024-01-01", "2024-01-01", "2024-01-15", "2024-01-15"
#'       )),
#'       value = 1:4
#'     ),
#'     region_column = "region",
#'     date_column = "date"
#'   ),
#'   class = "data_class"
#' )
#'
#' # Works: returns indices of rows with region A or B on the two dates
#' get_subset_indices(obj,
#'   regions = c("A", "B"),
#'   dates   = as.Date(c("2024-01-01", "2024-01-15"))
#' )
#'
#' # Only filter by dates
#' get_subset_indices(obj,
#'   regions = NULL,
#'   dates   = as.Date(c("2024-01-01", "2024-01-15"))
#' )
#'
#' # Only filter by regions
#' get_subset_indices(obj,
#'   regions = c("A", "B"),
#'   dates   = NULL
#' )
#' @rdname get_subset_indices
#' @export
#' @method get_subset_indices data_class
get_subset_indices.data_class <- function(obj,
                                          regions = NULL,
                                          dates = NULL,
                                          ...) {
  # Initialize filtered_data to be the original data
  filtered_data <- obj$data
  region_column <- obj$region_column
  date_column <- obj$date_column
  # If dates are provided, filter by dates
  if (!is.null(dates) && length(dates) > 0) {
    valid_dates <- dates %in% obj$data[[date_column]]
    if (any(!valid_dates)) {
      warning(paste(
        "The following dates were not found in the data: ",
        paste(dates[!valid_dates], collapse = ", ")
      ))
    }
    filtered_data <- filtered_data[x %in% dates, env = list(x = date_column)]
  }

  # If regions are provided, filter by regions
  if (!is.null(regions) && length(regions) > 0) {
    valid_regions <- regions %in% obj$data[[region_column]]
    if (any(!valid_regions)) {
      warning(paste(
        "The following regions were not found in the data: ",
        paste(regions[!valid_regions], collapse = ", ")
      ))
    }
    filtered_data <- filtered_data[x %in% regions, env = list(x = region_column)]
  }

  # In R, use the `which` function to get the row indices of a dataframe
  # Return the row indices of the filtered data
  condition1 <- obj$data[[region_column]] %in% filtered_data[[region_column]]
  condition2 <- obj$data[[date_column]] %in% filtered_data[[date_column]]

  which(condition1 & condition2)
}

#' Get subset indices from data_class object

#' @param obj A \code{data_class} object.
#' @param ... passed on to methods
#'
#' @return A numeric vector of row indices of the filtered data.

#' @export
get_subset_indices <- function(obj, ...) {
  UseMethod("get_subset_indices")
}

#' @export
get_subset_indices.default <- function(obj, ...) {
  cli::cli_abort("Object must be of class 'data_class'")
}

#' Add MMWR (Epidemiologic) Week Identifier
#'
#' Adds a numeric week identifier column to a `data_class`-style object based on
#' CDC MMWR (Morbidity and Mortality Weekly Report) week numbering. Optionally
#' adds a corresponding MMWR year column. The function updates the object using
#' `add_column()` and records the names of newly created columns.
#'
#' @description
#' The MMWR (or "epidemiologic") week system divides each year into
#' Sunday–Saturday weeks. **Week 1** is defined as the first week that has
#' **at least four days in January**—that is, the week containing January 4.
#' This rule ensures that all weeks are full seven-day periods and that
#' each belongs entirely to one MMWR year.
#'
#' The resulting `week_id` values range from **1 to 52**, with **53** appearing
#' only in rare cases (e.g., leap years that span 53 Sundays). If desired,
#' week 53 can be merged into week 52 for models requiring a fixed 52-week
#' cycle.
#'
#' @param obj A `data_class` object containing at least:
#'   \describe{
#'     \item{data}{A `data.table` containing the primary data.}
#'     \item{date_column}{The name of the date column within `data`.}
#'   }
#' @param column_name Character string giving the name of the new week-ID
#'   column.
#'   Default is `"week_id"`.
#' @param add_year Logical; if `TRUE`, also adds a column giving the MMWR year
#'   (the year containing the Thursday of that week). Default is `FALSE`.
#' @param year_col Character string naming the MMWR year column if
#'   `add_year = TRUE`.
#'   Default is `"mmwr_year"`.
#' @param coalesce_53_to_52 Logical; if `TRUE`, converts week 53 to 52. Useful
#'   for fixed 52-week seasonal models. Default is `FALSE`.
#' @param in_place Logical (default \code{TRUE}). If \code{TRUE} and
#'   \code{obj} is passed as a symbol, update that object in the caller
#'   environment. If \code{FALSE}, return an updated copy without mutating the
#'   caller's object.
#'
#' @return The modified `data_class` object, with one or two new columns added
#'   and metadata fields updated:
#'   \itemize{
#'     \item Attributes `has_week_ids` and `has_year_ids` set to `TRUE`.
#'   }
#'
#' @details
#' This function computes MMWR weeks and years using base R only (no external
#' dependencies). It relies on the following logic:
#' \enumerate{
#'   \item Determine the Sunday at the start of each week
#'         (`as.POSIXlt(date)$wday`).
#'   \item Define the MMWR year as the year containing the Thursday of that
#'         week.
#'   \item Define MMWR week 1 as the week whose Sunday falls on or before
#'         January 4 of the MMWR year.
#' }
#'
#' @examples
#' \dontrun{
#' # Example dates crossing the 2024→2025 boundary
#' dates <- as.Date(c("2024-12-28", "2024-12-29", "2025-01-01", "2025-01-05"))
#' data <- data.table::data.table(date = dates)
#' dc <- list(data = data, date_column = "date")
#'
#' # Add week identifiers
#' dc <- add_mmwr_week(dc, add_year = TRUE)
#'
#' dc$data
#' #          date week_id mmwr_year
#' # 1: 2024-12-28      52      2024
#' # 2: 2024-12-29       1      2025
#' # 3: 2025-01-01       1      2025
#' # 4: 2025-01-05       2      2025
#' }
#'
#' @seealso
#' \code{\link{add_day_of_week}} and \code{\link{add_day_of_year}}
#'   for related temporal identifiers.
#'
#' @export
add_mmwr_week <- function(
  obj,
  column_name = "week_id",
  add_year = FALSE,
  year_col = "mmwr_year",
  coalesce_53_to_52 = FALSE,
  in_place = TRUE
) {
  obj_expr <- substitute(obj)
  dc <- obj$date_column

  check_names(obj$data, dc)

  if (column_name %in% names(obj$data)) {
    cli::cli_abort(
      paste0("There is already a column ", column_name, " in `obj$data`")
    )
  }


  mmwr <- get_mmwr_week_year(obj$data[[dc]])
  week_id <- mmwr$mmwr_week
  if (coalesce_53_to_52) week_id[week_id == 53] <- 52L

  obj <- add_column(
    obj = obj,
    column_name = column_name,
    values = week_id,
    in_place = in_place,
    replace = TRUE,
    add_to_features = FALSE
  )
  obj <- .append_other_ids(obj, column_name)


  if (add_year) {
    obj <- add_column(
      obj = obj,
      column_name = year_col,
      values = mmwr$mmwr_year,
      in_place = in_place,
      add_to_features = FALSE
    )
    obj <- .append_other_ids(obj, year_col)

    data.table::setattr(obj, "has_year_ids", TRUE)
  }

  data.table::setattr(obj, "has_week_ids", TRUE)

  .maybe_assign_in_place(obj_expr, obj, in_place, parent.frame())
}

#' Add Day-of-Week Identifier
#'
#' Adds a day-of-week integer column to a `data_class`-style object.
#' By default, numbering follows the **epidemiological convention**
#' where Sunday = 1 and Saturday = 7. Optionally, ISO-style numbering
#' (Monday = 1, Sunday = 7) can be used instead.
#'
#' @description
#' The function extracts the day of the week from the date column
#' specified in the `data_class` object and appends it as a new integer
#' identifier column. This can be useful for fitting models with
#' day-of-week effects or seasonality.
#'
#' @param obj A `data_class` object containing at least:
#'   \describe{
#'     \item{data}{A `data.table` containing the primary data.}
#'     \item{date_column}{The name of the date column within `data`.}
#'   }
#' @param column_name Character string giving the name of the new
#'   day-of-week column. Default is `"dow_id"`.
#' @param sunday_start Logical; if `TRUE` (default), assigns
#'   Sunday = 1, Monday = 2, ..., Saturday = 7 (CDC/epidemiological
#'   convention). If `FALSE`, assigns Monday = 1, ..., Sunday = 7
#'   (ISO convention).
#' @param in_place Logical (default \code{TRUE}). If \code{TRUE} and
#'   \code{obj} is passed as a symbol, update that object in the caller
#'   environment. If \code{FALSE}, return an updated copy without mutating the
#'   caller's object.
#'
#' @return The modified `data_class` object, with one new column added and
#'   metadata fields updated:
#'   \itemize{
#'     \item Attribute `has_dow_ids` set to `TRUE`.
#'   }
#'
#' @details
#' This function uses only base R date operations (`as.POSIXlt`) to
#' determine the weekday number:
#' \itemize{
#'   \item In base R, `as.POSIXlt(date)$wday` returns Sunday = 0, ...,
#'     Saturday = 6.
#'   \item When `sunday_start = TRUE`, the returned value is shifted to 1–7.
#'   \item When `sunday_start = FALSE`, the numbering is rotated so Monday = 1
#'     and Sunday = 7.
#' }
#'
#' This matches conventions used by the CDC (for epidemiological time series)
#' and ISO 8601 (for international standards).
#'
#' @examples
#' \dontrun{
#'
#' # Epidemiological (Sunday-start) convention
#' dc1 <- add_day_of_week(dc)
#'
#' # ISO (Monday-start) convention
#' dc2 <- add_day_of_week(dc, sunday_start = FALSE)
#'
#' dc1$data
#' #          date dow_id
#' # 1: 2025-01-05      1
#' # 2: 2025-01-06      2
#' # 3: 2025-01-07      3
#'
#' dc2$data
#' #          date dow_id
#' # 1: 2025-01-05      7
#' # 2: 2025-01-06      1
#' # 3: 2025-01-07      2
#' }
#' @seealso
#' \code{\link{add_mmwr_week}} for week-based seasonality and
#' \code{\link{add_day_of_year}} for daily seasonal identifiers.
#'
#' @export
add_day_of_week <- function(
  obj,
  column_name = "dow_id",
  sunday_start = TRUE,
  in_place = TRUE
) {
  obj_expr <- substitute(obj)
  dc <- obj$date_column
  check_names(obj$data, dc)

  if (column_name %in% names(obj$data)) {
    cli::cli_abort(
      paste0("There is already a column ", column_name, " in `obj$data`")
    )
  }

  wday <- as.POSIXlt(obj$data[[dc]])$wday # Sunday=0, ..., Saturday=6

  if (sunday_start) {
    dow_id <- wday + 1L # 1–7 (Sun=1..Sat=7)
  } else {
    dow_id <- ((wday + 6L) %% 7L) + 1L # 1–7 (Mon=1..Sun=7)
  }

  obj <- add_column(
    obj = obj,
    column_name = column_name,
    values = dow_id,
    in_place = in_place,
    add_to_features = FALSE
  )
  obj <- .append_other_ids(obj, column_name)

  data.table::setattr(obj, "has_dow_ids", TRUE)

  .maybe_assign_in_place(obj_expr, obj, in_place, parent.frame())
}

#' Add Day-of-Year Identifier
#'
#' Adds a numeric day-of-year column to a `data_class`-style object, where
#' January 1 corresponds to 1 and December 31 corresponds to 365 (or 366 in
#' leap years). The resulting column can be used for modeling annual
#' seasonality at a daily resolution.
#'
#' @param obj A `data_class` object containing at least:
#'   - `data`: a data.table
#'   - `date_column`: name of the date column in `data`
#' @param column_name Character; name for the new column. Default `"doy_id"`.
#' @param in_place Logical (default \code{TRUE}). If \code{TRUE} and
#'   \code{obj} is passed as a symbol, update that object in the caller
#'   environment. If \code{FALSE}, return an updated copy without mutating the
#'   caller's object.
#'
#' @return The modified `data_class` object with one new column added and
#'   corresponding metadata fields updated.
#'
#' @details
#' The function computes the day-of-year index directly using base R
#' date arithmetic. Leap years are handled automatically — the maximum
#' day value is 366 when appropriate.
#'
#' @examples
#' \dontrun{
#' dc <- add_day_of_year(dc)
#' }
#'
#' @export
add_day_of_year <- function(
  obj,
  column_name = "doy_id",
  in_place = TRUE
) {
  obj_expr <- substitute(obj)
  dc <- obj$date_column
  check_names(obj$data, dc)

  if (column_name %in% names(obj$data)) {
    cli::cli_abort(
      paste0("There is already a column ", column_name, " in `obj$data`")
    )
  }

  # Compute day of year (Jan 1 = 1)
  doy_id <- as.integer(strftime(obj$data[[dc]], format = "%j"))

  # Add to object
  obj <- add_column(
    obj = obj,
    column_name = column_name,
    values = doy_id,
    in_place = in_place,
    add_to_features = FALSE
  )
  obj <- .append_other_ids(obj, column_name)

  # Track in metadata
  data.table::setattr(obj, "has_doy_ids", TRUE)

  .maybe_assign_in_place(obj_expr, obj, in_place, parent.frame())
}
