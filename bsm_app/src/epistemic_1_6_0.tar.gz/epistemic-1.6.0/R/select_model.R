# © 2025 The Johns Hopkins University Applied Physics Laboratory LLC
# Development of this software was sponsored by the U.S. Government under
# contract no. 75D30124C19958
# As of September 30, 2025 this code is pending review by OTT and should be
# considered JHU Propriety and only for internal JHU/APL use.

#' Normalize a terms specification for model selection
#'
#' @description
#' Standardize a user-supplied \code{terms_spec} into a list of groups,
#' each a character vector of options.
#'
#' * A length-1 element like \code{"x1"} is expanded to \code{c("", "x1")}
#'   (include/exclude).
#' * A length > 1 element like \code{c("", "z1", "z2")} is treated as mutually
#'   exclusive options (with \code{""} meaning exclusion).
#'
#' If no names are provided, auto-generated names like \code{"term1"},
#' \code{"term2"}, ... are used.
#'
#' @param spec A list or character vector:
#'   * If a character vector, it is treated as a list of length-1 elements.
#'   * If a list, each element must be a character vector.
#'
#' @return A named list of character vectors, each representing the options
#'   for one group.
#'
#' @keywords internal
#'
#' @examples
#' normalize_spec(c("x1", "x2"))
#' # returns list(term1 = c("", "x1"), term2 = c("", "x2"))
#'
#' normalize_spec(list(
#'   x1 = "temperature", # include/exclude
#'   x2 = c("", "humidity", "humidity2") # mutually exclusive
#' ))
#'
#' @export
normalize_spec <- function(spec) {
  if (is.null(spec)) {
    cli::cli_abort("{.arg spec} cannot be NULL.")
  }

  # Allow user to provide a simple character vector
  if (is.character(spec)) {
    spec <- as.list(spec)
    names(spec) <- paste0("term", seq_along(spec))
  }

  if (!is.list(spec) || length(spec) == 0L) {
    cli::cli_abort("{.arg spec} must be a non-empty list or character vector.")
  }

  # Ensure names
  if (is.null(names(spec))) {
    names(spec) <- paste0("term", seq_along(spec))
  } else if (any(!nzchar(names(spec)))) {
    idx <- which(!nzchar(names(spec)))
    names(spec)[idx] <- paste0("term", idx)
  }

  out <- spec
  for (nm in names(out)) {
    x <- out[[nm]]
    if (!is.character(x) || length(x) < 1L) {
      cli::cli_abort("Element {.val {nm}} must be a character vector of
                     length >= 1.")
    }

    # trim whitespace and deduplicate
    x <- unique(trimws(x))

    if (length(x) == 1L) {
      out[[nm]] <- c("", x)
    } else if ("" %in% x) {
      out[[nm]] <- c(x[x == ""], x[x != ""])
    } else {
      out[[nm]] <- x
    }
  }
  out
}

#' Build a formula string from option list and indices
#'
#' @description
#' Construct a formula string by selecting options from a list of candidate
#' term groups.
#'
#' @param spec A list of character vectors. Each element is a set of term
#'   options (right-hand side fragments of a formula).
#' @param idx An integer vector of the same length as \code{spec}. Each element
#'   selects which option to take from the corresponding element of \code{spec}.
#' @param response Optional string giving the response variable. If \code{NULL},
#'   return a one-sided formula (e.g. \code{"~ 1 + x1"}). Otherwise produce a
#'   two-sided formula.
#' @param include_intercept Logical; if \code{TRUE} (the default) include
#'   \code{1} as the intercept, otherwise use \code{0}.
#'
#' @return A character string representing a formula, for example
#'   \code{"y ~ 1 + x1 + f(r_id, model = \"iid\")"}.
#'
#' @examples
#' spec <- list(
#'   c("", "x1"),
#'   c("", "f(r_id, model = \"iid\")"),
#'   c("f(d_id, model = \"iid\")")
#' )
#' idx <- c(2, 2, 1) # pick "x1", "f(r_id,...)", "f(d_id,...)"
#' get_formula(spec, idx, response = "num")
#'
#' @export
get_formula <- function(spec, idx,
                        response = NULL,
                        include_intercept = TRUE) {
  if (!is.list(spec) || !all(vapply(spec, is.character, logical(1)))) {
    cli::cli_abort("{.arg spec} must be a list of character vectors.")
  }
  if (!is.integer(idx)) idx <- as.integer(idx)
  if (length(idx) != length(spec)) {
    cli::cli_abort("Length of {.arg idx} ({length(idx)}) must equal length of
                   {.arg spec} ({length(spec)}).")
  }

  # pick terms
  terms <- mapply(function(opts, i) {
    if (i < 1L || i > length(opts)) {
      cli::cli_abort("Index {i} out of bounds for option set of length
                     {length(opts)}.")
    }
    opts[[i]]
  }, spec, idx, SIMPLIFY = TRUE, USE.NAMES = FALSE)

  # drop empty string options
  terms <- terms[nzchar(terms)]

  intercept <- if (include_intercept) "1" else "0"
  rhs <- paste(c(intercept, terms), collapse = " + ")

  if (is.null(response)) {
    fm <- paste("~", rhs)
  } else {
    fm <- paste(response, "~", rhs)
  }
  fm
}

#' Generate candidate indices for a term's options
#'
#' @description
#' For a given term (one element of `opts`), return the indices of its options
#' in the order appropriate for forward or backward selection.
#'
#' - `"forward"`: indices from 1 up to the number of options
#' - `"backward"`: indices from the number of options down to 1
#'
#' This helper is useful when traversing candidate models sequentially, deciding
#' whether to try "adding" terms (forward) or "removing" terms (backward).
#'
#' @param term_num Integer scalar. Index of term group in `opts` to consider.
#' @param opts A list of character vectors, where each element contains the
#'   available options for a term (e.g., as produced by `normalize_spec()`).
#' @param direction Character scalar, either `"forward"` or `"backward"`.
#'   Determines the order in which candidate indices are returned.
#'
#' @return An integer vector of indices into `opts[[term_num]]`, ordered
#'   according to the specified direction.
#'
#' @examples
#' opts <- list(
#'   c("", "x1"),
#'   c("", "f(r_id, model=\"iid\")")
#' )
#'
#' # Forward order: 1 then 2
#' get_candidates(1, opts, "forward")
#' # [1] 1 2
#'
#' # Backward order: 2 then 1
#' get_candidates(1, opts, "backward")
#' # [1] 2 1
#'
#' @export
get_candidates <- function(term_num,
                           opts,
                           direction = c("forward", "backward")) {
  direction <- match.arg(direction)
  n_opts <- length(opts[[term_num]])
  if (direction == "forward") {
    seq_len(n_opts)
  } else {
    n_opts:1
  }
}
#' Greedy sequential model selection over option groups using criterion
#'
#' @description
#' Walks through groups (in the order provided by `terms_spec`) and, for each
#' group, tries every option in a direction-dependent order. After evaluating a
#' candidate, it updates the current indices if the chosen `criterion`
#' (WAIC/DIC) improves. All fits are cached by formula string.
#'
#' @param data_cls A data-class object consumed by \code{fit_model()} (must
#'   expose \code{$numerator_column} for the response name).
#' @param family Family passed to \code{fit_model()}.
#' @param terms_spec A list or character vector of option groups (see
#'   \code{normalize_spec()}). Each element is a character vector of RHS
#'   fragments; include \code{""} to allow exclusion.
#' @param adjacency_matrix Optional, forwarded to \code{fit_model()}.
#' @param reformulate Logical, forwarded to \code{fit_model()} (not used here).
#' @param direction \code{"forward"} (options in 1..k order) or
#'   \code{"backward"} (k..1 order).
#' @param criterion One of \code{"waic"} or \code{"dic"}; lower is better.
#' @param passes Integer number of full passes over all groups (default 1).
#' @param verbose Logical; print progress with \pkg{cli}.
#' @param ... Additional arguments forwarded to \code{fit_model()}.
#'
#' @return A list with:
#' \itemize{
#'   \item \code{results_table}: data.frame of \code{formula}, \code{waic},
#'     \code{dic}, \code{score}, \code{error}
#'   \item \code{best_model}: the fitted object for the best score
#'   \item \code{best_formula}: the best formula string
#'   \item \code{best_indices}: integer vector of chosen option indices
#' }
#'
#' @examples
#' # terms_spec <- list('f(r_id,model="iid")','f(d_id,model="iid")')
#' # sm <- select_model_criterion(data_cls,
#' #                              family="gaussian",
#' #                              terms_spec=terms_spec)
#'
#' @export
select_model_criterion <- function(data_cls,
                                   family,
                                   terms_spec,
                                   adjacency_matrix = NULL,
                                   reformulate = FALSE,
                                   direction = c("forward", "backward"),
                                   criterion = c("waic", "dic"),
                                   passes = 1,
                                   verbose = TRUE,
                                   ...) {
  direction <- match.arg(direction)
  criterion <- match.arg(criterion)

  # Normalize options
  opts <- normalize_spec(terms_spec)
  n_groups <- length(opts)

  # Initial indices by direction
  if (direction == "forward") {
    initial_indices <- rep.int(1L, n_groups)
  } else {
    initial_indices <- lengths(opts)
  }

  current_indices <- initial_indices
  best_indices <- initial_indices

  best_score <- Inf
  best_formula <- ""
  best_model <- NULL

  # Cache and results accumulator
  cache <- new.env(parent = emptyenv())
  results <- list()

  # helper: evaluate a given indices vector
  eval_indices <- function(indices) {
    fm <- get_formula(
      spec = opts,
      idx = indices,
      response = data_cls$numerator_column, # build two-sided formula string
      include_intercept = TRUE
    )

    if (exists(fm, envir = cache, inherits = FALSE)) {
      return(get(fm, envir = cache, inherits = FALSE))
    }

    if (isTRUE(verbose)) cli::cli_inform("Fitting {.val {fm}}")
    model_res <- tryCatch(
      fit_model(
        data_cls,
        formula = fm,
        family = family,
        adjacency_matrix = adjacency_matrix,
        reformulate = reformulate
      ),
      error = function(e) e
    )


    if (inherits(model_res, "error")) {
      summary <- list(
        indices = indices,
        waic    = NA_real_,
        dic     = NA_real_,
        score   = NA_real_,
        formula = fm,
        error   = conditionMessage(model_res)
      )
    } else {
      waic <- suppressWarnings(as.numeric(model_res$inla_model$waic$waic))
      dic <- suppressWarnings(as.numeric(model_res$inla_model$dic$dic))
      sc <- if (identical(criterion, "waic")) waic else dic

      summary <- list(
        indices = indices,
        waic    = waic,
        dic     = dic,
        score   = sc,
        formula = fm,
        error   = NA_character_
      )
    }

    assign(fm, summary, envir = cache)
    results[[length(results) + 1L]] <<- summary
    summary
  }

  # Evaluate the starting point
  cur <- eval_indices(current_indices)
  if (isTRUE(verbose)) {
    cli::cli_inform("Start: {cur$formula} | WAIC={cur$waic} DIC={cur$dic}")
  }

  # Track global best
  if (is.finite(cur$score) && cur$score < best_score) {
    best_indices <- cur$indices
    best_score <- cur$score
    best_formula <- cur$formula
    best_model <- get(cur$formula, envir = cache, inherits = FALSE)
  }

  # Main passes over groups
  for (pass in seq_len(passes)) {
    if (isTRUE(verbose)) cli::cli_inform("Pass {pass} over groups")

    for (term_num in seq_len(n_groups)) {
      # Candidate option indices for this group in the requested direction
      cand_idx <- get_candidates(term_num, opts, direction)

      for (option_num in cand_idx) {
        # Propose: set this group's index and evaluate
        prop_indices <- current_indices
        prop_indices[term_num] <- option_num

        rec <- eval_indices(prop_indices)
        # If improves, adopt as current and possibly update global best
        if (is.finite(rec$score) && rec$score < best_score) {
          current_indices <- rec$indices
          best_indices <- rec$indices
          best_score <- rec$score
          best_formula <- rec$formula
          best_model <- get(rec$formula, envir = cache, inherits = FALSE)
          if (isTRUE(verbose)) {
            cli::cli_inform("  Improved -> {criterion}={round(best_score, 3)}
                            with {best_formula}")
          }
        }
      }

      # After finishing options for this group, set current to best so far
      current_indices <- best_indices
    }
  }

  # Build a user-friendly results table
  if (length(results)) {
    results_table <- data.frame(
      formula = vapply(results, `[[`, character(1), "formula"),
      waic = vapply(results, `[[`, numeric(1), "waic"),
      dic = vapply(results, `[[`, numeric(1), "dic"),
      score = vapply(results, `[[`, numeric(1), "score"),
      error = vapply(
        results,
        function(x) if (is.na(x$error)) "" else x$error,
        character(1)
      ),
      stringsAsFactors = FALSE
    )
  } else {
    results_table <- data.frame(
      formula = character(0),
      waic = numeric(0),
      dic = numeric(0),
      score = numeric(0),
      error = character(0)
    )
  }

  list(
    results_table = results_table,
    best_model    = if (!is.null(best_model)) best_model else NULL,
    best_formula  = best_formula,
    best_indices  = best_indices
  )
}

#' Model selection with masked evaluation across multiple test splits
#'
#' @description
#' Performs greedy sequential model selection over user–specified term groups,
#' training with masked observations and evaluating predictions on held-out
#' rows. For each candidate formula, the function:
#' \enumerate{
#'   \item applies each mask column (one at a time): keeps rows with codes
#'         \code{0} (train) and \code{1} (test), drops \code{-1} (exclude), and
#'         sets the numerator column to \code{NA} on test rows (\code{1});
#'   \item fits the model on the masked training data (via \code{fit_model()});
#'   \item predicts on the corresponding held-out rows and computes metrics
#'         (MAE / RMSE) on either the count scale or the proportion scale;
#'   \item averages the metric across all mask columns to obtain the score used
#'         for selection.
#' }
#' All evaluated models are cached by formula string to avoid refitting the same
#' specification during the search.
#'
#' @details
#' \itemize{
#'   \item \strong{Term groups:} \code{terms_spec} is normalized (see
#'         \code{normalize_spec()}) so each group is a character vector of
#'         mutually exclusive options; include \code{""} to allow exclusion.
#'   \item \strong{Direction:} with \code{"forward"} the options of each group
#'         are tried in index order \code{1, 2, ...}; with \code{"backward"}
#'         in reverse order. After each group is scanned, the best‐so‐far
#'         specification is carried forward to the next group. Set \code{passes}
#'         \eqn{> 1} to revisit groups in the same order multiple times.
#'   \item \strong{Masks:} each \code{mask_columns} entry must exist in
#'         \code{data_cls$data} and contain only \code{-1, 0, 1} where
#'         \code{-1} = exclude, \code{0} = train, \code{1} = test.
#'   \item \strong{Scale:} if \code{use_count_scale = TRUE}, metrics compare
#'         predicted counts to the numerator; otherwise metrics compare
#'         predicted proportions to \code{numerator/denominator}.
#' }
#'
#' @param data_cls A data‐class list consumed by \code{fit_model()}, expected to
#'   include fields \code{$data} (a \code{data.table}), and column names
#'   \code{$numerator_column}, \code{$denominator_column},
#'   \code{$region_column}, \code{$date_column}.
#' @param family Model family passed to \code{fit_model()}.
#' @param terms_spec A list or character vector of RHS term groups. Each element
#'   is a character vector of options; include \code{""} to allow exclusion.
#'   See \code{normalize_spec()}.
#' @param adjacency_matrix Optional adjacency (e.g., for spatial effects),
#'   forwarded to \code{fit_model()}.
#' @param reformulate Logical flag forwarded to \code{fit_model()}.
#' @param mask_columns Character vector of column names in \code{data_cls$data}
#'   providing mask codes \code{-1, 0, 1}; see Details.
#' @param direction Either \code{"forward"} or \code{"backward"}; controls the
#'   order in which options within each group are tried.
#' @param metric Selection metric. One of \code{"mae"} or \code{"rmse"}.
#'   The score used for selection is the \emph{average} of the chosen metric
#'   across all mask columns.
#' @param passes Integer number of full passes over all groups
#'   (default \code{1}).
#' @param verbose Logical; print progress messages.
#' @param use_count_scale Logical; if \code{TRUE}, compute metrics on the count
#'   scale using the numerator; otherwise on the proportion scale
#'   \code{numerator/denominator}.
#'
#' @return A list with:
#' \itemize{
#'   \item \code{results_table}: \code{data.frame} with one row per evaluated
#'         formula and columns \code{formula}, \code{mae}, \code{rmse},
#'         \code{score} (the selection metric), and \code{error} (message or
#'         empty string).
#'   \item \code{results_per_mask}: a long \code{data.table} with per‐mask
#'         breakdown (\code{formula}, \code{mask_col}, \code{mae}, \code{rmse},
#'         \code{error}) for diagnostics and reporting.
#'   \item \code{best_model}: the fitted object for the best formula.
#'   \item \code{best_formula}: the best formula string.
#'   \item \code{best_indices}: the vector of chosen option indices (one per
#'         term group).
#' }
#'
#' @section Caching:
#' Each distinct formula string is evaluated at most once per call. Fitted
#' results and metrics (including the per‐mask table) are cached and reused
#' whenever the same formula reappears during the search.
#'
#' @examples
#' \dontrun{
#' # Assume: data_cls prepared, fit_model(), normalize_spec(), get_formula(),
#' # and get_posterior_medians() are available in the environment.
#' terms_spec <- list('f(r_id, model="iid")', 'f(d_id, model="iid")')
#' res <- select_model_estimation(
#'   data_cls,
#'   family = "binomial",
#'   terms_spec = terms_spec,
#'   mask_columns = c("mask1", "mask2"),
#'   direction = "forward",
#'   metric = "mae",
#'   passes = 1,
#'   verbose = TRUE
#' )
#' res$results_table
#' res$results_per_mask
#' res$best_formula
#' }
#'
#' @export

select_model_estimation <- function(data_cls,
                                    family,
                                    terms_spec,
                                    adjacency_matrix = NULL,
                                    reformulate = FALSE,
                                    mask_columns,
                                    direction = c("forward", "backward"),
                                    metric = c("mae", "rmse"),
                                    passes = 1,
                                    verbose = TRUE,
                                    use_count_scale = FALSE) {
  mae <- NULL
  rmse <- NULL
  abs_error <- NULL
  sq_error <- NULL
  direction <- match.arg(direction)
  metric <- match.arg(metric)

  num_col <- data_cls$numerator_column
  den_col <- data_cls$denominator_column
  date_col <- data_cls$date_column
  region_col <- data_cls$region_column

  data_cols <- c(
    region_col,
    date_col,
    num_col,
    den_col
  )

  # Normalize options
  opts <- normalize_spec(terms_spec)
  n_groups <- length(opts)

  # Initial indices by direction
  if (direction == "forward") {
    initial_indices <- rep.int(1L, n_groups)
  } else {
    initial_indices <- lengths(opts)
  }

  current_indices <- initial_indices
  best_indices <- initial_indices

  best_score <- Inf
  best_formula <- ""
  best_model <- NULL

  # Cache and results accumulator
  cache <- new.env(parent = emptyenv())
  results <- list()

  # helper: evaluate a given indices vector
  # indices: integer vector of option choices (one per group in opts)
  # mask_columns: character vector of column names, each with {-1,0,1} codes
  eval_indices <- function(indices, mask_columns) {
    # Build formula string once (fit_model will parse to formula)
    fm <- get_formula(
      spec = opts,
      idx = indices,
      response = data_cls$numerator_column,
      include_intercept = TRUE
    )

    # If we've already evaluated this formula (all masks), reuse
    if (exists(fm, envir = cache, inherits = FALSE)) {
      return(get(fm, envir = cache, inherits = FALSE))
    }

    if (isTRUE(verbose)) cli::cli_inform("Fitting/Scoring {.val {fm}} across
                                         {length(mask_columns)} mask(s)")

    # Aliases for columns we’ll reference a lot

    # collect per-mask metrics rows
    per_mask_rows <- vector("list", length(mask_columns))

    for (k in seq_along(mask_columns)) {
      mask_col <- mask_columns[[k]]

      # ---------------------------
      # 1) Prepare masked training data
      # ---------------------------
      cur_data_cls <- copy_data_class(data_cls)
      # keep only rows with 0/1, drop -1
      cur_data_cls$data <- cur_data_cls$data[m %in% c(0L, 1L), env = list(m = mask_col)]
      # mask numerator for test rows
      cur_data_cls$data[m == 1L, (num_col) := NA, env = list(m = mask_col)]

      # ---------------------------
      # 2) Fit model on masked data
      # ---------------------------
      model_res <- tryCatch(
        fit_model(
          cur_data_cls,
          formula = fm,
          family = family,
          adjacency_matrix = adjacency_matrix,
          reformulate = reformulate
        ),
        error = function(e) e
      )

      if (inherits(model_res, "error")) {
        per_mask_rows[[k]] <- data.table::data.table(
          mask_col = mask_col,
          mae = NA_real_,
          rmse = NA_real_,
          error = conditionMessage(model_res)
        )
        next
      }

      # ---------------------------
      # 3) Build truth on held-out (mask == 1) from the ORIGINAL data (unmasked)
      # ---------------------------
      true <- data.table::as.data.table(
        data_cls$data[m == 1L, .SD, .SDcols = data_cols, env = list(m = mask_col)]
      )
      data.table::setnames(true, data_cols)
      true_val <- NULL
      pred_val <- NULL
      # choose scale for truth
      if (isTRUE(use_count_scale)) {
        true[, true_val := x, env = list(x = num_col)]
      } else {
        true[, true_val := data.table::fifelse(
          d > 0, n / d, NA_real_
        ), env = list(d = den_col, n = num_col)]
      }
      true <- true[!is.na(true_val)]
      # ---------------------------
      # 4) Predictions (posterior medians) for the same rows
      # ---------------------------
      pred <- get_posterior_medians(
        model_res$inla_model,
        data_cls,
        use_suffix = FALSE,
        use_count_scale = isTRUE(use_count_scale)
      )
      # Expect pred to have date_col, region_col, and "0.5quant"
      data.table::setnames(pred, old = "0.5quant", new = "pred_val")

      # ---------------------------
      # 5) Join and compute metrics
      # ---------------------------
      joined <- true[pred, on = c(date_col, region_col), nomatch = 0L]
      joined[, `:=`(
        error     = pred_val - true_val,
        abs_error = abs(pred_val - true_val),
        sq_error  = (pred_val - true_val)^2
      )]
      metrics <- joined[, list(
        mae  = mean(abs_error, na.rm = TRUE),
        rmse = sqrt(mean(sq_error, na.rm = TRUE))
      )]

      per_mask_rows[[k]] <- data.table::data.table(
        mask_col = mask_col,
        mae = metrics$mae,
        rmse = metrics$rmse,
        error = NA_character_
      )
    } # end for each mask

    # ---------------------------
    # 6) Aggregate across masks (overall score used for selection)
    # ---------------------------
    per_mask_dt <- data.table::rbindlist(per_mask_rows, fill = TRUE)
    overall <- per_mask_dt[, list(
      mae = mean(mae, na.rm = TRUE),
      rmse = mean(rmse, na.rm = TRUE)
    )]

    # Choose selection criterion (expecting criterion %in% c("mae","rmse"))
    sc <- if (identical(metric, "mae")) overall$mae else overall$rmse
    formula <- NULL
    # Build the record to cache and to append to results
    per_mask_dt[, formula := fm]
    summary <- list(
      indices      = indices,
      formula      = fm,
      mae          = overall$mae,
      rmse         = overall$rmse,
      score        = sc,
      per_mask     = per_mask_dt, # detailed breakdown
      error        = NA_character_
    )

    assign(fm, summary, envir = cache)
    results[[length(results) + 1L]] <<- summary

    per_mask_dt[, formula := fm]
    summary
  }

  # Evaluate the starting point
  cur <- eval_indices(current_indices, mask_columns)
  if (isTRUE(verbose)) {
    cli::cli_inform("Start: {cur$formula} | MAE={round(cur$mae,3)}
                    RMSE={round(cur$rmse,3)}")
  }

  # Track global best
  if (is.finite(cur$score) && cur$score < best_score) {
    best_indices <- cur$indices
    best_score <- cur$score
    best_formula <- cur$formula
    best_model <- get(cur$formula, envir = cache, inherits = FALSE)
  }

  # Main passes over groups
  for (pass in seq_len(passes)) {
    if (isTRUE(verbose)) cli::cli_inform("Pass {pass} over groups")

    for (term_num in seq_len(n_groups)) {
      # Candidate option indices for this group in the requested direction
      cand_idx <- get_candidates(term_num, opts, direction)

      for (option_num in cand_idx) {
        # Propose: set this group's index and evaluate
        prop_indices <- current_indices
        prop_indices[term_num] <- option_num

        rec <- eval_indices(prop_indices, mask_columns)
        # If improves, adopt as current and possibly update global best
        if (is.finite(rec$score) && rec$score < best_score) {
          current_indices <- rec$indices
          best_indices <- rec$indices
          best_score <- rec$score
          best_formula <- rec$formula
          best_model <- get(rec$formula, envir = cache, inherits = FALSE)
          if (isTRUE(verbose)) {
            cli::cli_inform("  Improved -> {metric}={round(best_score, 3)}
                            with {best_formula}")
          }
        }
      }

      # After finishing options for this group, set current to best so far
      current_indices <- best_indices
    }
  }

  # Build a user-friendly results table
  if (length(results)) {
    results_table <- data.frame(
      formula = vapply(results, `[[`, character(1), "formula"),
      mae = vapply(results, `[[`, numeric(1), "mae"),
      rmse = vapply(results, `[[`, numeric(1), "rmse"),
      score = vapply(results, `[[`, numeric(1), "score"),
      error = vapply(
        results,
        function(x) if (is.na(x$error)) "" else x$error,
        character(1)
      ),
      stringsAsFactors = FALSE
    )
    # also build a long per-mask table across all formulas
    results_per_mask <- data.table::rbindlist(
      lapply(results, function(x) x$per_mask),
      fill = TRUE
    )
  } else {
    results_table <- data.frame(
      formula = character(0), mae = numeric(0), rmse = numeric(0),
      score = numeric(0), error = character(0)
    )
    results_per_mask <- data.table::data.table()
  }

  list(
    results_table     = results_table, # overall metrics per formula
    results_per_mask  = results_per_mask, # details per mask
    best_model        = if (!is.null(best_model)) best_model else NULL,
    best_formula      = best_formula,
    best_indices      = best_indices
  )
}
