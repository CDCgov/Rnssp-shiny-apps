# © 2025 The Johns Hopkins University Applied Physics Laboratory LLC
# Development of this software was sponsored by the U.S. Government under
# contract no. 75D30124C19958
# As of September 30, 2025 this code is pending review by OTT and should be
# considered JHU Propriety and only for internal JHU/APL use.

#' Extract Posterior Median Estimates from an INLA Model
#'
#' This function extracts posterior median estimates from an INLA model, scaled
#' appropriately based on the model family.
#'
#' @param inla_model A fitted INLA model object returned by [`INLA::inla()`].
#' @param data_cls A `data_class` object containing the original data used to
#'   train the model. It must include an `expected_column` (for scaling).
#' @param use_suffix Logical. If `TRUE` (default), the output column name will
#'   include the `posterior` as a suffix. If `FALSE`, the column name will be
#'   "0.5quant".
#' @param use_count_scale Logical. If `TRUE`, results will be scaled as counts;
#'   if `FALSE`, results will be scaled as proportions.
#' @param regions Array. Array of regions where results should be calculated.
#'   If `NULL`, all regions are used. Default is `NULL`.
#' @param dates Array. Array of dates where results should be calculated.
#'   If `NULL`, all dates are used. Default is `NULL`.
#'
#' @return A `data.table` with the region and date column from `data_cls$data`
#'   and the posterior median.
#'
#' @export
get_posterior_medians <- function(
  inla_model,
  data_cls,
  use_suffix = TRUE,
  use_count_scale = TRUE,
  regions = NULL,
  dates = NULL
) {
  keep_inds <- get_subset_indices.data_class(data_cls,
    regions = regions,
    dates = dates
  )
  data <- data.table::copy(data_cls$data[keep_inds, ])


  # Extract posterior values and scaling factors
  values <- inla_model$summary.fitted.values[["0.5quant"]]
  scales <- get_scale_factors(data_cls, inla_model)

  scale <- if (use_count_scale) scales$count_scale else scales$prop_scale
  values <- values[keep_inds]
  scale <- scale[keep_inds]
  suffix <- if (use_count_scale) "_median_counts" else "_median_props"
  col_name <- if (use_suffix) paste0("0.5quant", suffix) else "0.5quant"

  data[[col_name]] <- values * scale

  # return the primary key and values
  data <- data[, .SD, .SDcols = c(
    data_cls$region_column, data_cls$date_column, col_name
  )]
  data <- remove_invalid_estimates(data,
    value_columns = c(col_name),
    inla_model = inla_model,
    use_count_scale = use_count_scale,
    data_class = data_cls
  )
  data
}

#' Extract Posterior Mean Estimates from an INLA Model
#'
#' This function extracts posterior means from a fitted INLA model,
#' rescaling as needed based on the model family.
#'
#' @param inla_model A fitted INLA model object returned by [`INLA::inla()`].
#' @param data_cls A `data_class` object containing the original data used
#'   to train the model. It must include an `expected_column` (for scaling).
#' @param use_suffix Logical. If `TRUE` (default), the output column name will
#'   include the `posterior` as a suffix. If `FALSE`, the column name
#'   will be "predicted_mean".
#' @param use_count_scale Logical. If `TRUE`, results will be scaled as counts;
#'   if `FALSE`, results will be scaled as proportions.
#' @param regions Array. Array of regions where results should be calculated.
#'   If `NULL`, all regions are used. Default is `NULL`.
#' @param dates Array. Array of dates where results should be calculated.
#'   If `NULL`, all dates are used. Default is `NULL`.
#'
#' @return A `data.table` with the region and date column from `data_cls$data`
#'   and the posterior median.
#'
#' @export
get_posterior_means <- function(
  inla_model,
  data_cls,
  use_suffix = TRUE,
  use_count_scale = TRUE,
  regions = NULL,
  dates = NULL
) {
  keep_inds <- get_subset_indices.data_class(data_cls,
    regions = regions,
    dates = dates
  )
  data <- data.table::copy(data_cls$data[keep_inds, ])
  mean_vals <- inla_model$summary.fitted.values[["mean"]]

  scales <- get_scale_factors(data_cls, inla_model)
  scale <- if (use_count_scale) scales$count_scale else scales$prop_scale
  mean_vals <- mean_vals[keep_inds]
  scale <- scale[keep_inds]
  suffix <- if (use_count_scale) "_mean_counts" else "_mean_props"
  col_name <- if (use_suffix) {
    paste0("predicted_mean", suffix)
  } else {
    "predicted_mean"
  }

  data[[col_name]] <- mean_vals * scale

  # return the primary key and values
  data <- data[, .SD, .SDcols = c(
    data_cls$region_column, data_cls$date_column, col_name
  )]
  data <- remove_invalid_estimates(data,
    value_columns = c(col_name),
    inla_model = inla_model,
    use_count_scale = use_count_scale,
    data_class = data_cls
  )

  data
}
