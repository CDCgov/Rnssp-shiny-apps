# © 2025 The Johns Hopkins University Applied Physics Laboratory LLC
# Development of this software was sponsored by the U.S. Government under
# contract no. 75D30124C19958
# As of September 30, 2025 this code is pending review by OTT and should be
# considered JHU Propriety and only for internal JHU/APL use.

#' Compute Posterior Quantiles from INLA Fitted Values
#'
#' Extracts posterior quantiles from an INLA model’s marginal fitted values and
#' optionally rescales them to the count or proportion scale, returning a
#' wide-format data table that includes region and date columns.
#'
#' @param inla_model An `inla` model object, typically the result of a call to
#'   `INLA::inla()`, which must contain `marginals.fitted.values`.
#' @param data_cls An epistemic data_class object that includes:
#'   - `data`: A `data.table` containing the original data,
#'   - `region_col`: The name of the region column,
#'   - `date_col`: The name of the date column.
#' @param probs A numeric vector of probabilities for which to compute
#'   quantiles. Must be between 0 and 1. Defaults to: `c(0.01, 0.025, seq(0.05,
#'   0.95, 0.05), 0.975, 0.99)`.
#' @param use_suffix Logical. If `TRUE`, the resulting quantile columns will be
#'   named with a suffix indicating the scale and probability level. Default is
#'   `TRUE`.
#' @param use_count_scale Logical. If `TRUE`, the quantiles are returned on the
#'   count scale using; otherwise, the proportion scaleis used. Default is
#'   `TRUE`.
#' @param regions Array. Array of regions where results should be calculated.
#'   If `NULL`, all regions are used. Default is `NULL`.
#' @param dates Array. Array of dates where results should be calculated.
#'   If `NULL`, all dates are used. Default is `NULL`.
#' @param len Integer. Number of interpolation points passed to
#'   `INLA::inla.qmarginal()`. Default is 2048.
#'
#' @return A `data.table` in wide format. The first two columns are the region
#'   and date (copied from `data_cls$data`), followed by quantile columns named
#'   with the format `counts_<prob>` or `props_<prob>`, depending on
#'   `use_count_scale`.
#'
#' @details This function applies `INLA::inla.qmarginal()` to all marginal
#'   fitted values in the model to compute posterior quantiles, optionally
#'   rescales them based on precomputed scale factors (see
#'   `get_scale_factors()`), and joins them to the relevant metadata (region and
#'   date).
#'
#' @examples
#' \dontrun{
#' # Assuming `inla_model` is a fitted INLA model and `data_cls` is a
#' # compatible data structure:
#' quantiles <- get_posterior_quantiles(inla_model, data_cls)
#' }
#' @export

get_posterior_quantiles <- function(
  inla_model,
  data_cls,
  probs = c(0.01, 0.025, seq(0.05, 0.95, .05), .975, .99),
  use_suffix = TRUE,
  use_count_scale = TRUE,
  regions = NULL,
  dates = NULL,
  len = 2048L
) {
  pred <- q <- NULL
  keep_inds <- get_subset_indices.data_class(data_cls,
    regions = regions,
    dates = dates
  )
  # 1. check that all probs are between 0,1
  if (!all(data.table::between(probs, 0, 1))) {
    cli::cli_abort("all probabilities must be between 0 and 1")
  }

  # 2. get scale factors, and scale/suffix
  scales <- get_scale_factors(data_cls, inla_model)
  if (use_count_scale) {
    scale <- scales$count_scale
    suffix <- suffix <- paste0("counts_", probs)
  } else {
    scale <- scales$prop_scale
    suffix <- paste0("props_", probs)
  }
  scale <- scale[keep_inds]
  # 3. Get the marg, and run inla.qmarginal overall (order-safe)
  lst <- inla_model$marginals.fitted.values[keep_inds]
  names(lst) <- NULL # <- ensure idcol uses 1..K, not character names

  marg <- data.table::rbindlist(
    lapply(lst, data.table::as.data.table),
    idcol = "pred" # pred is now integer 1..K
  )

  result <- marg[
    ,
    list(
      prob = probs,
      q = INLA::inla.qmarginal(probs, as.matrix(.SD), len = len)
    ),
    by = pred
  ]


  # 4. scale aligned by pred and keep order
  result[, q := q * scale[pred]]
  result <- data.table::dcast(result, pred ~ prob, value.var = "q")
  data.table::setorder(result, pred) # rows now match keep_inds

  # 5. c-bind with the data class region and date cols
  result <- cbind(
    data_cls$data[keep_inds,
      .SD,
      .SDcols = c(data_cls$region_col, data_cls$date_col)
    ],
    result[, -1]
  )

  # 6. apply names if requested
  if (use_suffix) {
    data.table::setnames(result, new = c(names(result)[1:2], suffix))
  }
  # 7. replace invalid values with NA (these may arise if estimates are)
  # generated for certain scale/family combinations
  result <- remove_invalid_estimates(
    data = result,
    value_columns = names(result)[3:ncol(result)],
    inla_model = inla_model,
    use_count_scale = use_count_scale,
    data_class = data_cls
  )

  result
}

#' Posterior quantiles for aggregated totals (and proportions) from an INLA
#' model
#'
#' Computes posterior quantiles for aggregates defined by `group_cols`, using
#' joint posterior samples so spatial/temporal correlation is preserved.
#'
#' The function assumes `get_posterior_samples()` returns a `data.table` with
#' the region/date columns from `data_cls` and sample columns named
#' `"sample_1"`, `"sample_2"`, ..., `"sample_S"`, where `S = n_samples`.
#'
#' For `use_count_scale = TRUE`, the function aggregates posterior draws of
#' counts (numerators) by summing within each group and then computes quantiles.
#'
#' For `use_count_scale = FALSE`, the function still draws numerators on the
#' count scale, aggregates them by summing within each group, aggregates the
#' denominators deterministically from the data, and then converts each draw to
#' a group-level proportion as `sum(counts) / sum(denominator)` before
#' computing quantiles. This yields correct group proportions (a ratio of sums),
#' not a sum of individual proportions.
#'
#' NA handling for posterior samples (numerators) is controlled by `na.rm`:
#' * `na.rm = TRUE`: treats NA numerators as 0 in the group sum
#' * `na.rm = FALSE`: propagates NA (any NA in a group/draw makes that sum NA)
#'
#' Denominators are taken from `data_cls$denominator_column` and are not
#' stochastic. If any selected denominators are NA, the function errors. If any
#' group has an aggregated denominator of 0, the function errors.
#'
#' @param inla_model A fitted INLA model object.
#' @param data_cls A data class object containing `data` and metadata such as
#'   `region_column`, `date_column`, and optionally `denominator_column`.
#' @param probs Numeric vector of probabilities in [0, 1] for quantiles.
#' @param use_suffix Logical; if `TRUE`, suffix quantile columns as
#'   "counts_p" or "props_p:.
#' @param use_count_scale Logical; if `TRUE`, return aggregate counts. If
#'   `FALSE`, return aggregate proportions using the denominator column.
#' @param regions Optional region filter passed to `get_posterior_samples()` and
#'   `get_subset_indices.data_class()`. `NULL` means no region filtering.
#' @param dates Optional date filter passed to `get_posterior_samples()` and
#'   `get_subset_indices.data_class()`. `NULL` means no date filtering.
#' @param group_cols Character vector of column names in `data_cls$data` that
#'   define the aggregation groups (e.g., c("state", "date")).
#' @param n_samples Integer number of joint posterior samples to draw.
#' @param na.rm Logical controlling NA handling in posterior sample aggregation.
#'
#' @return A `data.table` with one row per group and quantile columns.
get_posterior_quantiles_group <- function(
  inla_model,
  data_cls,
  probs = c(0.01, 0.025, seq(0.05, 0.95, .05), .975, .99),
  use_suffix = TRUE,
  use_count_scale = TRUE,
  regions = NULL,
  dates = NULL,
  group_cols,
  n_samples = 1000L,
  na.rm = FALSE
) {
  if (missing(group_cols) || length(group_cols) < 1L) {
    cli::cli_abort("`group_cols` must be a non-empty character vector.")
  }
  if (!is.character(group_cols)) {
    cli::cli_abort("`group_cols` must be a character vector of column names.")
  }
  if (!all(data.table::between(probs, 0, 1))) {
    cli::cli_abort("all probabilities must be between 0 and 1")
  }
  if (!is.numeric(n_samples) || length(n_samples) != 1L || n_samples < 1L) {
    cli::cli_abort("`n_samples` must be a positive integer.")
  }
  n_samples <- as.integer(n_samples)

  if (is.null(data_cls$region_column) || is.null(data_cls$date_column)) {
    cli::cli_abort(
      "`data_cls$region_column` and `data_cls$date_column` needed."
    )
  }

  region_col <- data_cls$region_column
  date_col <- data_cls$date_column

  missing_cols <- setdiff(group_cols, names(data_cls$data))
  if (length(missing_cols) > 0L) {
    cli::cli_abort(c(
      "The following `group_cols` are not in `data_cls$data`:",
      paste0(" - ", missing_cols)
    ))
  }

  keep_inds <- get_subset_indices.data_class(
    data_cls,
    regions = regions,
    dates = dates
  )
  if (length(keep_inds) == 0L) {
    cli::cli_abort("No observations match the requested regions/dates.")
  }

  # Always draw on count scale so aggregation is coherent.
  samps_dt <- get_posterior_samples(
    inla_model = inla_model,
    data_cls = data_cls,
    n_samples = n_samples,
    use_count_scale = TRUE,
    regions = regions,
    dates = dates
  )
  samps_dt <- data.table::as.data.table(samps_dt)

  if (!(region_col %in% names(samps_dt))) {
    cli::cli_abort("Region column not found in posterior samples output.")
  }
  if (!(date_col %in% names(samps_dt))) {
    cli::cli_abort("Date column not found in posterior samples output.")
  }

  sample_cols <- grep(
    "^sample_[0-9]+$",
    names(samps_dt),
    value = TRUE
  )
  if (length(sample_cols) != n_samples) {
    cli::cli_abort("Unexpected number of sample columns returned.")
  }

  # Ensure stable sample column order: sample_1, sample_2, ...
  sample_nums <- suppressWarnings(
    as.integer(sub("^sample_", "", sample_cols))
  )
  o <- order(sample_nums)
  sample_cols <- sample_cols[o]

  # Build (S x K) matrix of count draws.
  x <- as.matrix(samps_dt[, sample_cols, with = FALSE]) # K x S
  samp_counts <- t(x) # S x K

  # Map group columns onto sampled rows using (region, date) join.
  keys_dt <- data.table::as.data.table(
    samps_dt[, c(region_col, date_col), with = FALSE]
  )
  data.table::setnames(
    keys_dt,
    old = c(region_col, date_col),
    new = c("region_key", "date_key")
  )

  map_dt <- data_cls$data[, .SD, .SDcols = c(region_col, date_col, group_cols)]
  data.table::setnames(map_dt, new = c("region_key", "date_key", group_cols))

  data.table::setkeyv(map_dt, c("region_key", "date_key"))
  data.table::setkeyv(keys_dt, c("region_key", "date_key"))

  groups_dt <- map_dt[keys_dt]

  if (nrow(groups_dt) != nrow(keys_dt)) {
    cli::cli_abort("Failed to map groups onto all sampled rows.")
  }
  if (anyNA(groups_dt[, group_cols, with = FALSE])) {
    cli::cli_abort(
      "Some sampled rows have missing group mappings."
    )
  }


  groups_dt[
    ,
    gid := .GRP,
    by = group_cols
  ]

  idx_by_gid <- split(seq_len(ncol(samp_counts)), groups_dt$gid)
  G <- length(idx_by_gid)

  # Aggregate counts per draw within each group -> (S x G)
  agg_counts <- matrix(NA_real_, nrow = nrow(samp_counts), ncol = G)

  if (na.rm) {
    tmp <- samp_counts
    tmp[is.na(tmp)] <- 0
    j <- 1L
    for (cols in idx_by_gid) {
      agg_counts[, j] <- rowSums(tmp[, cols, drop = FALSE])
      j <- j + 1L
    }
  } else {
    j <- 1L
    for (cols in idx_by_gid) {
      agg_counts[, j] <- rowSums(samp_counts[, cols, drop = FALSE])
      j <- j + 1L
    }
  }

  # Convert to proportions if requested.
  if (!use_count_scale) {
    denom_col <- data_cls$denominator_column
    if (is.null(denom_col) || !nzchar(denom_col)) {
      cli::cli_abort(paste0(
        "`data_cls$denominator_column` must be set when ",
        "`use_count_scale = FALSE`."
      ))
    }
    if (!(denom_col %in% names(data_cls$data))) {
      cli::cli_abort("Denominator column not found in `data_cls$data`.")
    }

    den_map <- data.table::as.data.table(
      data_cls$data[, c(region_col, date_col, denom_col), with = FALSE]
    )

    data.table::setnames(
      den_map,
      old = c(region_col, date_col, denom_col),
      new = c("region_key", "date_key", "denom")
    )

    data.table::setkeyv(
      den_map,
      c("region_key", "date_key")
    )

    den_dt <- den_map[keys_dt]
    if (nrow(den_dt) != nrow(keys_dt)) {
      cli::cli_abort("Failed to map denominators onto all sampled rows.")
    }
    if (anyNA(den_dt$denom)) {
      cli::cli_abort("Denominator contains NA for selected rows.")
    }

    denom_by_gid <- tapply(den_dt$denom, groups_dt$gid, sum)
    denom_by_gid <- as.numeric(denom_by_gid)

    if (any(denom_by_gid == 0)) {
      cli::cli_abort(paste0(
        "One or more groups has aggregated denominator 0; ",
        "proportions are undefined."
      ))
    }

    agg_vals <- sweep(agg_counts, 2, denom_by_gid, "/")
  } else {
    agg_vals <- agg_counts
  }

  # Quantiles across draws per group.
  g <- ncol(agg_vals)
  p <- length(probs)

  qtmp <- apply(
    agg_vals,
    2,
    stats::quantile,
    probs = probs,
    na.rm = FALSE,
    names = FALSE,
    type = 7
  )

  # `apply()` may drop dimensions if G == 1 and/or P == 1.
  if (is.null(dim(qtmp))) {
    if (g == 1L) {
      # One group: vector length P
      qtmp <- matrix(qtmp, nrow = p, ncol = 1L)
    } else if (p == 1L) {
      # One prob: vector length G
      qtmp <- matrix(qtmp, nrow = 1L, ncol = g)
    } else {
      cli::cli_abort("Unexpected shape from quantile computation.")
    }
  }

  # Want: rows = groups, cols = probs
  qmat <- t(qtmp)
  colnames(qmat) <- as.character(probs)

  # One row per group key.
  keys_out <- unique(groups_dt[, c(group_cols, "gid"), with = FALSE])
  data.table::setorder(keys_out, gid)

  out <- cbind(
    keys_out[, group_cols, with = FALSE],
    data.table::as.data.table(qmat)
  )

  if (use_suffix) {
    if (use_count_scale) {
      suffix <- paste0("counts_", probs)
    } else {
      suffix <- paste0("props_", probs)
    }
    data.table::setnames(out, old = as.character(probs), new = suffix)
  }

  data.table::setorderv(out, group_cols)
  out
}
