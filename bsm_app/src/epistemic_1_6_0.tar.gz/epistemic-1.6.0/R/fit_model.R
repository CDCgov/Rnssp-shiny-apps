# © 2025 The Johns Hopkins University Applied Physics Laboratory LLC
# Development of this software was sponsored by the U.S. Government under
# contract no. 75D30124C19958
# As of September 30, 2025 this code is pending review by OTT and should be
# considered JHU Propriety and only for internal JHU/APL use.

#' Fit a statistical model to a data_class object
#'
#' This function fits a generalized linear model using the INLA framework to a
#' data_class object. It supports binomial, Poisson, negative binomial, and
#' betabinomial families.
#'
#' @param data_cls A `data_class` object containing the data required for model
#'   fitting.
#' @param formula A model formula specifying the response and predictors (e.g.,
#'   `y ~ x + z`).
#' @param family A character string specifying the model family. Must be one of
#'   `"binomial"`, `"poisson"`, `"nbinomial"` or `"betabinomial"`.
#' @param init_strategy (default `"eb"`) A character string specifying the
#'   integration strategy for the INLA approximation. Must be one of
#'   `"auto"`, `"ccd"`, `"grid"`, `"eb"`, `"user"`, or `"user.std"`.
#' @param posterior_marginal_strategy (default `"laplace"`) A character string
#'   specifying the approximation strategy for posterior marginals. Must be one
#'   of `"auto"`, `"laplace"`, `"gaussian"`, `"simplified.laplace"`, or
#'   `"adaptive"`.
#' @param joint_precision_diagonal_offset (default 0.0) A float specifying the
#'    value
#'    added on the diagonal of the joint precision matrix.
#' @param diagonal_hessian (default FALSE) A boolean specifying if
#'    the Hessian matrix is forced to be diagonal
#' @param reformulate (bool, default=\code{FALSE}); set to TRUE to use an
#'   abstract formula for actual region and date identifiers (and possibly any
#'   graph parameter in the model). Note that the abstract placeholders for
#'   region and date identifiers must be "r_id" and "d_id" respectively within
#'   the formula. For example: \code{y~1+r_id+d_id+r_id} will be converted to
#'   \code{y~1+region_id_1+date_id_1+region_id_2}.
#' @param adjacency_matrix (default NULL); if `reformulate` is set to TRUE, and
#'   the formula contains the term "graph", then the caller must pass a valid
#'   adjacency matrix in this parameter. Note that any object here will be
#'   tested for validity via \code{epistemic::validate_adjacency_matrix()}. Any
#'   name given to the graph parameter in the formula will be replaced with
#'   "adjacency_matrix"
#' @param allow_sampling (default FALSE); turn on (TRUE) to allow for subsequent
#'   call to \code{get_posterior_samples()}
#' @param env environment to associate with any updated formula, for example, if
#'   \code{reformulate} is set to \code{TRUE}
#'
#' @return A list of three objects, including anobject of class `inla`
#'   containing the fitted model, the data_class object providing the data, and
#'   an \code{inla.graph} object if `adjacency_matrix` is not NULL.
#'
#' @examples
#' \dontrun{
#' fit <- fit_model(data_cls, formula = num ~ 1, family = "binomial")
#' summary(fit)
#' }
#'
#' @export
fit_model <- function(
  data_cls,
  formula,
  family,
  init_strategy = c("eb", "auto", "ccd", "grid", "user", "user.std"),
  posterior_marginal_strategy = c(
    "laplace",
    "auto",
    "gaussian",
    "simplified.laplace",
    "adaptive"
  ),
  joint_precision_diagonal_offset = 0.0,
  diagonal_hessian = FALSE,
  reformulate = FALSE,
  adjacency_matrix = NULL,
  allow_sampling = FALSE,
  env = parent.frame()
) {
  if (reformulate) {
    objs <- prepare_model_objects(
      data_cls,
      formula = formula,
      adjacency_matrix = adjacency_matrix,
      env = env
    )
    data_cls <- objs[["data"]]
    formula <- objs[["formula"]]
    adjacency_matrix <- objs[["adjacency_matrix"]]
  }

  # Verify that formula is valid
  validation_res <- validate_inla_formula(formula, data_cls)
  if (!validation_res$ok) {
    cli::cli_abort(
      paste0(
        "Invalid formula. Validation checks failed with errors: ",
        validation_res$errors
      ),
      class = "invalid_formula"
    )
  }

  den_col <- data_cls[["denominator_column"]]
  exp_col <- data_cls[["expected_column"]]

  if (is.null(exp_col)) {
    cli::cli_abort("Cannot fit model without expected column")
  }

  init_strategy <- match.arg(init_strategy)
  posterior_marginal_strategy <- match.arg(posterior_marginal_strategy)

  control_inla <- list(
    int.strategy = init_strategy,
    strategy = posterior_marginal_strategy,
    diagonal = joint_precision_diagonal_offset,
    force.diagonal = diagonal_hessian
  )

  log_offset <- dc <- ec <- x <- NULL

  # make copy of data, and add necessary columns
  data <- data.table::copy(data_cls$data)
  data[, dc := x, env = list(x = den_col)]
  data[, ec := x, env = list(x = exp_col)]

  if (family == "poisson") {
    data[, log_offset := log(ec)]
    inla_model <- tryCatch(INLA::inla(
      formula,
      family = "poisson",
      data = data,
      offset = log_offset,
      control.compute = list(
        waic = TRUE,
        dic = TRUE,
        return.marginals.predictor = TRUE,
        config = allow_sampling
      ),
      control.predictor = list(compute = TRUE, link = 1),
      control.inla = control_inla
    ), error = function(e) {
      cli::cli_alert_danger(e$message)
      e$message
    })
  } else if (family == "binomial") {
    inla_model <- tryCatch(INLA::inla(
      formula,
      family = "binomial",
      data = data,
      Ntrials = dc,
      E = ec,
      control.predictor = list(compute = TRUE, link = 1),
      control.compute = list(
        waic = TRUE,
        dic = TRUE,
        return.marginals.predictor = TRUE,
        config = allow_sampling
      ),
      control.inla = control_inla
    ), error = function(e) {
      cli::cli_alert_danger(e$message)
      e$message
    })
  } else if (family == "nbinomial") {
    data[, log_offset := log(ec)]
    inla_model <- tryCatch(INLA::inla(
      formula,
      family = "nbinomial",
      data = data,
      offset = log_offset,
      control.predictor = list(compute = TRUE, link = 1),
      control.compute = list(
        waic = TRUE,
        dic = TRUE,
        return.marginals.predictor = TRUE,
        config = allow_sampling
      ),
      control.inla = control_inla
    ), error = function(e) {
      cli::cli_alert_danger(e$message)
      e$message
    })
  } else if (family == "betabinomial") {
    inla_model <- tryCatch(INLA::inla(
      formula,
      family = "betabinomial",
      data = data,
      Ntrials = dc,
      E = ec,
      control.predictor = list(compute = TRUE, link = 1),
      control.compute = list(
        waic = TRUE,
        dic = TRUE,
        return.marginals.predictor = TRUE,
        config = allow_sampling
      ),
      control.inla = control_inla
    ), error = function(e) {
      cli::cli_alert_danger(e$message)
      e$message
    })
  } else {
    cli::cli_abort("Family not implemented!", class = "invalid_family")
  }

  result <- list(
    inla_model = inla_model,
    data = data_cls,
    formula = formula,
    control_inla = control_inla
  )
  # if adjacency matrix was passed, we should add it to the list
  if (!is.null(adjacency_matrix)) {
    result[["adjacency_matrix"]] <- adjacency_matrix
  } else {
    # We check for graph in the formula, and if there, we return the adjacency
    # matrix in the formula's environment

    # get the name of the object associated with graph param in formula
    am_name <- get_graph_value(deparse1(formula))
    # assign that value to adjacency matrix
    if (!is.na(am_name)) {
      result[["adjacency_matrix"]] <- get(am_name, envir = environment(formula))
    }
  }

  (result)
}


#' Prepare Model Objects for INLA
#'
#' Wrapper that takes a data_class object, a formula, and an optional adjacency
#' matrix, and produces all components needed for an INLA model: it adds date
#' and region ID columns based on the formula, constructs an INLA neighbor graph
#' if requested, and rewrites the formula to reference the new ID columns.
#'
#' @param data_cls A `data_class` object. Must pass `validate_data_class()`.
#' @param formula A formula containing tokens for region and date IDs (e.g. `~
#'   r_id + d_id`).
#' @param adjacency_matrix Optional adjacency input. If not NULL, it will be
#'   passed to `neighbor_graph()` together with the updated data_class object,
#'   and then converted to an `inla.graph` via `INLA::inla.read.graph()`.
#' @param r_id A length-1 string giving the token name for region IDs in
#'   `formula`. Defaults to `"r_id"`.
#' @param d_id A length-1 string giving the token name for date IDs in
#'   `formula`. Defaults to `"d_id"`.
#' @param env environment to associate with any updated formula
#' @return A list with three components:
#'   - `data`: the updated `data_class` object with date and region ID
#'   columns added.
#'   - `formula`: the formula rewritten to use the new ID column names.
#'   - `adjacency_matrix`: the processed adjacency graph of class `inla.graph`,
#'   a adjacency matrix of class `matrix` or `NULL` if no adjacency was
#'   supplied.
#'
#' @details 1. Calls `gen_ids_from_formula(data_cls, formula)` to add the
#'   required ID columns based on how many times the tokens appear in `formula`.
#'   2. If `adjacency_matrix` is provided, calls `neighbor_graph(dcl_updated,
#'   adjacency_matrix)` and then `INLA::inla.read.graph()` to produce an
#'   `inla.graph` object. 3. Calls `update_formula_with_ids(formula,
#'   dcl_updated, adjacency_matrix)` to produce a formula that references the
#'   new ID column names. 4. Returns a list containing the updated data_class,
#'   the updated formula, and the processed adjacency graph.
#'
#' @examples
#' \dontrun{
#' data("demo_data")
#' dc <- demo_data
#' # simple model without adjacency
#' objs1 <- prepare_model_objects(dc, ~ r_id + d_id)
#'
#' # with adjacency matrix supplied
#' mat <- matrix(c(0, 1, 1, 0), 2, 2,
#'   dimnames = list(c("A", "B"), c("A", "B"))
#' )
#' objs2 <- prepare_model_objects(dc, ~ r_id + d_id, adjacency_matrix = mat)
#' }
#'
#' @export
#'
prepare_model_objects <- function(data_cls, formula, adjacency_matrix = NULL,
                                  r_id = "r_id", d_id = "d_id",
                                  env = parent.frame()) {
  dcl_updated <- gen_ids_from_formula(data_cls, formula)
  if (!is.null(adjacency_matrix)) {
    adjacency_matrix <- neighbor_graph(
      dcl_updated, adjacency_matrix
    ) |> INLA::inla.read.graph()
  }
  formula_updated <- update_formula_with_ids(
    formula = formula,
    dcl = dcl_updated,
    adjacency_matrix = adjacency_matrix,
    r_id = r_id,
    d_id = d_id,
    env = env
  )

  list(
    "data" = dcl_updated,
    "formula" = formula_updated,
    "adjacency_matrix" = adjacency_matrix
  )
}

#' Update a Formula by Replacing Tokens with ID Columns
#'
#' Replaces bare tokens in a formula (e.g. `~ r_id + d_id`) with the actual date
#' and region identifier column names stored in a `data_class` object.
#' Optionally validates an INLA graph adjacency matrix.
#'
#' @param formula A one-sided formula containing the tokens to replace,
#'   typically `r_id` and `d_id`.
#' @param dcl A `data_class` object. Must pass `validate_data_class()`. The
#'   object must have non-null `region_identifiers` and `date_identifiers`.
#' @param r_id A length-1 string giving the token name for region IDs in
#'   `formula`. Defaults to `"r_id"`.
#' @param d_id A length-1 string giving the token name for date IDs in
#'   `formula`. Defaults to `"d_id"`.
#' @param adjacency_matrix An optional object of class `inla.graph`. If
#'   provided, its class is validated but it is not otherwise used. However, if
#'   the formula includes "adjacency_matrix" (for example \code{graph =
#'   adjacency_matrix}, then this cannot be NULL)
#' @param env environment to associate with any updated formula
#'
#' @return A one-sided `formula` in which each occurrence of the bare token
#'   `r_id` has been replaced, in sequence, by the entries of
#'   `dcl$region_identifiers`, and each occurrence of `d_id` has been replaced
#'   by the entries of `dcl$date_identifiers`. If `adjacency_matrix` is supplied
#'   but not of class `inla.graph`, the function aborts.
#'
#' @details 1. Validates that `dcl` inherits from class `"data_class"`. 2. If
#' `adjacency_matrix` is not NULL, checks it has class `"inla.graph"`. 3.
#' Deparses `formula` to a single string. 4. Sequentially replaces each
#' whole-word occurrence of `r_id` with the corresponding entry in
#' `dcl$region_identifiers`. 5. Sequentially replaces each whole-word occurrence
#' of `d_id` with the corresponding entry in `dcl$date_identifiers`. 6. Converts
#' the modified string back to a formula via `stats::as.formula()`.
#'
#' @examples
#' \dontrun{
#' data("demo_data")
#' dcl <- demo_data
#' # assume region_id_1 and date_id_1 have been added
#' f0 <- ~ r_id + d_id
#' f1 <- update_formula_with_ids(f0, dcl)
#' # f1 might be ~ region_id_1 + date_id_1
#'
#' # with multiple identifiers:
#' dcl2 <- add_date_and_region_ids(dcl, num_duplicates = 2)
#' f2 <- ~ r_id + r_id + d_id
#' update_formula_with_ids(f2, dcl2)
#' # yields ~ region_id_1 + region_id_2 + date_id_1
#' }
#'
#' @export
update_formula_with_ids <- function(
  formula, dcl, r_id = "r_id", d_id = "d_id",
  adjacency_matrix = NULL,
  env = parent.frame()
) {
  validate_data_class(dcl)

  if (!is.null(adjacency_matrix)) {
    if (!inherits(adjacency_matrix, "inla.graph")) {
      cli::cli_abort("adjacency matrix must be of class inla.graph")
    }
  }

  if (is.character(formula)) {
    formula <- stats::as.formula(formula)
  } else if (inherits(formula, "formula")) {
    formula <- formula
  } else {
    cli::cli_abort("{.arg formula} must be a formula or a character string.")
  }
  f_str <- deparse1(formula)
  if (grepl("graph ?=", f_str, perl = TRUE) && is.null(adjacency_matrix)) {
    cli::cli_abort(
      "The formula contains graph but parameter adjacency matrix is NULL",
      class = "update_formula_failed"
    )
  }

  r_ids <- dcl$region_identifiers
  d_ids <- dcl$date_identifiers

  # sequentially replace each bare "r_id" int the formula
  # with one of region identifiers
  for (i in seq_along(r_ids)) {
    f_str <- sub(paste0("\\b", r_id, "\\b"), r_ids[i], f_str)
  }
  # similarly with d_id / date ids
  for (i in seq_along(d_ids)) {
    f_str <- sub(paste0("\\b", d_id, "\\b"), d_ids[i], f_str)
  }
  # update the left hand side with the numerator columns
  f_str <- sub(".*(?= ~)", dcl$numerator_column, f_str, perl = TRUE)
  am_name <- get_graph_value(f_str)
  if (!is.na(am_name)) {
    f_str <- sub(pattern = am_name, replacement = "adjacency_matrix", x = f_str)
  }
  # return formula
  stats::as.formula(f_str, env = {
    if (is.na(am_name)) env else parent.frame()
  })
}


#' Generate Date and Region ID Columns Based on a Formula
#'
#' Parses a formula to count how many times the tokens for region and date IDs
#' appear, and then calls \code{add_date_and_region_ids()} to add that many sets
#' of ID columns.
#'
#' @param dcl A \code{data_class} object. Must pass
#'   \code{validate_data_class()}.
#' @param formula A formula (e.g. \code{y ~ r_id + d_id}) whose deparsed string
#'   is searched for whole‐word occurrences of \code{r_id} and \code{d_id}.
#' @param r_id A length‐1 \code{character} giving the token name to count for
#'   region IDs. Defaults to \code{"r_id"}.
#' @param d_id A length‐1 \code{character} giving the token name to count for
#'   date IDs. Defaults to \code{"d_id"}.
#'
#' @return A \code{data_class} object, as returned by
#'   \code{add_date_and_region_ids()}, with \code{n} new date and region ID
#'   columns, where \code{n} is the larger of the two token counts. successful.
#'   If neither token appears at least once, aborts with
#'   \code{cli::cli_abort("No instance of r_ids/d_ids to replace")}.
#'
#' @details 1. Validates that \code{dcl} inherits from class
#' \code{"data_class"}. 2. Converts \code{formula} to a single string via
#' \code{deparse1()}. 3. Counts whole‐word matches of \code{r_id} and
#' \code{d_id}. 4. If both counts are zero, aborts. 5. Calls
#' \code{add_date_and_region_ids(dcl, num_duplicates = n)} and returns the
#' result.
#'
#' @export
gen_ids_from_formula <- function(
  dcl,
  formula,
  r_id = "r_id",
  d_id = "d_id"
) {
  validate_data_class(dcl)

  # collapse the formula into a single string
  f_str <- deparse1(formula)

  # get count of r_ids and d_ids
  r_ids_n <- gregexpr(paste0("\\b", r_id, "\\b"), f_str)[[1]]
  d_ids_n <- gregexpr(paste0("\\b", d_id, "\\b"), f_str)[[1]]

  if (length(r_ids_n) == 1 && r_ids_n == -1) {
    r_ids_n <- 0
  } else {
    r_ids_n <- length(r_ids_n)
  }

  if (length(d_ids_n) == 1 && d_ids_n == -1) {
    d_ids_n <- 0
  } else {
    d_ids_n <- length(d_ids_n)
  }

  n <- max(c(r_ids_n, d_ids_n, 0))

  if (n == 0) {
    cli::cli_alert("No instance of r_ids/d_ids to replace")
  }

  # get the date and region ids necessary for this formula
  add_date_and_region_ids(dcl, num_duplicates = n)
}

# helper/non-exported function to get graph value or
# return NA if none
get_graph_value <- function(str) {
  m <- regexec("graph\\s*=\\s*([^,\\s\\)]+)", str, perl = TRUE)
  parts <- regmatches(str, m)[[1]]
  if (length(parts) >= 2) parts[2] else NA_character_
}
