## -------------------------------------------
## Helper functions for validating INLA formulas
## -------------------------------------------

PREDEFINED_VARS <- c(
  "r_id",
  "d_id",
  "adjacency_matrix"
)

## Allowed latent model types in f()

VALID_LATENT_MODELS <- names(INLA::inla.models()$latent)

## Functions that should NOT be allowed in formulas
DISALLOWED_FUNS <- c(
  ## --- Shell / system commands ---
  "system",
  "system2",
  "shell",
  "pipe",

  ## --- Filesystem / I/O (write or destructive ops) ---
  "file.remove",
  "unlink",
  "file.rename",
  "file.copy",
  "file.create",
  "dir.create",
  "download.file",
  "write.table",
  "write.csv",
  "writeLines",
  "sink",
  "save",
  "saveRDS",
  "save.image",
  "load",
  "source",

  ## --- Connections / network-ish ---
  "file",
  "gzfile",
  "bzfile",
  "xzfile",
  "unz",
  "url",
  "socketConnection",

  ## --- Session / environment manipulation ---
  "assign",
  "rm",
  "options",
  "setwd",
  "attach",
  "detach",
  "q",
  "quit",

  ## --- Package loading / namespaces ---
  "library",
  "require",
  "requireNamespace",
  "loadNamespace",

  ## --- Code execution / introspection ---
  "eval",
  "evalq",
  "eval.parent",
  "parse",
  "do.call",
  "get",
  "mget",
  "getFromNamespace"
)


## -----------------------------
## Variables vs data columns
## -----------------------------

#' Extract variables from a formula while ignoring `graph =` arguments
#'
#' This function parses a model formula and returns all variable names
#' referenced in the expression, except for symbols supplied as the value
#' of a named `graph` argument inside function calls (e.g.
#' `f(..., graph = am)`).
#'
#' It is intended for validating that model variables appear in the data
#' attribute of a data class (i.e. a data table) while allowing graph objects
#' or adjacency matrices that are provided separately from the data.
#'
#' @param formula_obj A model formula object.
#'
#' @return A character vector of unique variable names referenced in the
#'   formula, excluding variables passed via `graph =`.
#'
#' @details
#' The function walks the formula's abstract syntax tree recursively.
#' Symbols are collected unless they appear as the value of a named
#' `graph` argument in a function call.
#'
#' @examples
#' fml <- target ~ 1 + f(
#'   region_id,
#'   graph = am,
#'   group = date_id
#' )
#'
#' epistemic:::get_formula_vars_ignore_graph(fml)
#' # Returns: c("target", "region_id", "date_id")
#'
#' @keywords internal
get_formula_vars_ignore_graph <- function(formula_obj) {
  vars <- character()

  walk <- function(expr) {
    if (is.symbol(expr)) {
      vars <<- c(vars, as.character(expr))
    } else if (is.call(expr)) {
      arg_names <- names(expr)

      for (i in seq_along(expr)[-1]) {
        # Skip the value of graph =
        if (!is.null(arg_names) && arg_names[i] == "graph") {
          next
        }
        # Skip the value of hyper =
        if (!is.null(arg_names) && arg_names[i] == "hyper") {
          next
        }

        walk(expr[[i]])
      }
    }
  }

  walk(formula_obj)
  unique(vars)
}


#' Validate that formula variables are present in the data
#'
#' Checks whether all variables referenced in a model formula are present
#' in the supplied data set, excluding predefined variables, hyperparameters,
#' and variables passed as `graph =` arguments.
#'
#' This function is typically used during model setup to provide early,
#' informative errors when a formula references unknown variables.
#'
#' @param formula_obj A model formula object.
#' @param data_class An object containing a data table in the `data` field.
#'
#' @return Invisibly returns \code{TRUE} if all variables are found.
#'
#' @details
#' Throws an error if one or more variables referenced in the formula are not
#' found in the data or in \code{PREDEFINED_VARS}.
#'
#' Variables supplied via `graph =` arguments inside model components
#' (e.g. spatial or network structures) are ignored, allowing them to be
#' defined outside the data table.
#'
#' @examples
#' data_class <- list(
#'   data = data.frame(
#'     target = rnorm(10),
#'     region_id = 1:10,
#'     date_id = rep(1:5, each = 2)
#'   )
#' )
#'
#' fml <- target ~ 1 + f(
#'   region_id,
#'   graph = am,
#'   group = date_id
#' )
#'
#' epistemic:::check_vars_in_data(fml, data_class)
#'
#' @keywords internal
check_vars_in_data <- function(formula_obj, data_class) {
  data <- data_class$data

  vars <- get_formula_vars_ignore_graph(formula_obj)

  missing <- setdiff(vars, c(colnames(data), PREDEFINED_VARS))

  if (length(missing) > 0) {
    cli::cli_abort(
      paste(
        "Variables not found in data:",
        paste(missing, collapse = ", ")
      ),
      call. = FALSE
    )
  }

  invisible(TRUE)
}


## ---------------------------------------------
## Check that non-predefined vars appear once
## ---------------------------------------------
##
## Rule:
##   - If a variable is in PREDEFINED_VARS, it can appear
##     multiple times.
##   - If it is not in PREDEFINED_VARS, it must appear
##     at most once in the formula (LHS + RHS combined).


## -----------------------------------------
## Find and check f() latent model terms
## -----------------------------------------

#' Recursively find all \code{f()} calls in an expression
#'
#' Traverses an R expression and returns all function calls whose head
#' is \code{f}. This is useful for inspecting or validating model formulas
#' that include structured components such as spatial, temporal, or
#' random-effect terms defined via \code{f()}.
#'
#' @param expr An R language object, typically a formula or a subexpression
#'   extracted from a formula.
#'
#' @return A list of language objects, each representing a call to
#'   \code{f(...)} found within the expression. Returns an empty list if
#'   no such calls are present.
#'
#' @details
#' The function walks the abstract syntax tree of \code{expr} recursively.
#' Whenever a call with head \code{f} is encountered, it is collected and
#' recursion continues through all arguments of the call to ensure nested
#' \code{f()} calls are also detected.
#'
#' This function performs no validation of the contents of the \code{f()}
#' calls; it only identifies and returns them.
#'
#' @examples
#' fml <- target ~ 1 +
#'   f(region_id, model = "iid") +
#'   f(time_id, model = "rw1", group = year)
#'
#' epistemic:::find_f_calls(fml)
#' # Returns a list of two f() call expressions
#'
#' @keywords internal
find_f_calls <- function(expr) {
  calls <- list()
  if (is.call(expr)) {
    if (identical(expr[[1]], as.name("f"))) {
      calls <- c(calls, list(expr))
    }
    # Recurse on arguments
    for (i in seq_along(expr)[-1]) {
      calls <- c(calls, find_f_calls(expr[[i]]))
    }
  }
  calls
}


#' Validate \code{f()} terms in a model formula
#'
#' Checks that all \code{f()} terms appearing in a model formula are
#' well-formed and reference valid data variables and latent model
#' specifications.
#'
#' Specifically, this function:
#' \itemize{
#'   \item Ensures each \code{f()} call has an index variable.
#'   \item Verifies that the index variable exists in the data or in
#'     \code{PREDEFINED_VARS}.
#'   \item Validates the \code{model} argument (if supplied) against a
#'     predefined set of allowed latent models.
#' }
#'
#' @param formula_obj A model formula object.
#' @param data_class An object containing a data table in the \code{data} field.
#'
#' @return Invisibly returns \code{TRUE} if all \code{f()} terms are valid.
#'
#' @details
#' An error is thrown if any \code{f()} term is malformed, references an unknown
#' index variable, or specifies an invalid latent model.
#'
#' The function uses \code{\link{find_f_calls}} to locate all \code{f()}
#' calls in the formula and validates each one independently. If no
#' \code{f()} terms are present, the function returns successfully
#' without performing any checks.
#'
#' Only simple model specifications are allowed, such as
#' \code{model = "rw1"} or \code{model = rw1}. Complex expressions
#' (e.g. function calls or lists) are not permitted for the \code{model}
#' argument.
#'
#' @examples
#' data_class <- list(
#'   data = data.frame(
#'     target = rnorm(10),
#'     region_id = 1:10,
#'     time_id = 1:10
#'   )
#' )
#'
#' fml <- target ~ 1 +
#'   f(region_id, model = "iid") +
#'   f(time_id, model = rw1)
#'
#' epistemic:::check_f_terms(fml, data_class)
#'
#' @keywords internal
check_f_terms <- function(formula_obj, data_class) {
  data <- data_class$data
  f_calls <- find_f_calls(formula_obj)
  if (length(f_calls) == 0L) {
    return(invisible(TRUE))
  }

  for (call in f_calls) {
    if (length(call) < 2) {
      cli::cli_abort(
        "Each f() call must have at least an index argument.",
        call. = FALSE
      )
    }

    index_var <- as.character(call[[2]])
    if (!(index_var %in% c(colnames(data), PREDEFINED_VARS))) {
      msg <- sprintf(
        "Index variable '%s' in f() not found in data.",
        index_var
      )
      cli::cli_abort(msg, call. = FALSE)
    }

    # Check model argument, if present
    call_list <- as.list(call)
    arg_names <- names(call_list)
    model_pos <- which(arg_names == "model")

    if (length(model_pos) > 0) {
      model_arg <- call_list[[model_pos]]

      # Only allow simple character arguments, e.g. model = "rw1"
      if (is.symbol(model_arg)) {
        model_val <- as.character(model_arg)
      } else if (is.character(model_arg)) {
        model_val <- model_arg
      } else {
        cli::cli_abort(
          paste(
            "The 'model' argument in f() must be a simple",
            "name or character string."
          ),
          call. = FALSE
        )
      }

      if (!model_val %in% VALID_LATENT_MODELS) {
        msg <- sprintf(
          paste(
            "Latent model '%s' in f(%s, ...) is not allowed.",
            "Choose one of: %s"
          ),
          model_val,
          index_var,
          paste(VALID_LATENT_MODELS, collapse = ", ")
        )
        cli::cli_abort(msg, call. = FALSE)
      }
    }
  }

  invisible(TRUE)
}

## ---------------------------------------------
## Response variable found, numeric, matches numerator
## ---------------------------------------------

#' Validate the response variable in a model formula
#'
#' Checks that the response variable specified on the left-hand side of a
#' model formula exists in the data, matches the expected target column,
#' and is numeric.
#'
#' This function is intended to enforce consistency between the formula
#' specification and the data configuration used for model fitting.
#'
#' @param formula_obj A model formula object.
#' @param data_class An object containing the model data and metadata,
#'   including a data table in the \code{data} field and the expected
#'   response column name in \code{numerator_column}.
#'
#' @return Invisibly returns \code{TRUE} if the response variable is valid.
#'
#' @details
#' An error is thrown if the response variable is not found in the data, does
#' not match the expected target column, or is not numeric.
#'
#' The response variable is extracted from the left-hand side of the
#' formula using \code{all.vars()} after stripping the right-hand side
#' via \code{stats::update(formula_obj, . ~ 1)}. Only the first variable found
#' is treated as the response.
#'
#' The response variable must:
#' \itemize{
#'   \item Exist as a column in the data frame
#'   \item Match \code{data_class$numerator_column}
#'   \item Be numeric
#' }
#'
#' @examples
#' data_class <- list(
#'   data = data.frame(
#'     y = rnorm(10),
#'     x = rnorm(10)
#'   ),
#'   numerator_column = "y"
#' )
#'
#' fml <- y ~ x
#'
#' epistemic:::check_response(fml, data_class)
#'
#' @keywords internal
check_response <- function(formula_obj, data_class) {
  data <- data_class$data
  num_col <- data_class$numerator_column
  # Response variable = left-hand side of formula
  response_var <- all.vars(stats::update(formula_obj, . ~ 1))[1]

  if (!(response_var %in% colnames(data))) {
    msg <- sprintf(
      "Response variable '%s' not found in data.",
      response_var
    )
    cli::cli_abort(msg, call. = FALSE)
  }
  if (!(response_var == num_col)) {
    msg <- sprintf(
      "Response variable '%s' should match target column %s.",
      response_var,
      num_col
    )
    cli::cli_abort(msg, call. = FALSE)
  }

  y <- data[[response_var]]


  if (!is.numeric(y)) {
    cli::cli_abort(
      paste(
        "The response should be",
        "numeric."
      ),
      call. = FALSE
    )
  }
  invisible(TRUE)
}

## ------------------------------------------------
## Check for obviously dangerous function names
## ------------------------------------------------

#' Check for disallowed functions in a model formula
#'
#' Scans a model formula for function calls that are explicitly disallowed
#' and raises an error if any are detected.
#'
#' This function is intended to prevent the use of unsupported or unsafe
#' transformations within model formulas by enforcing a predefined
#' blacklist of function names.
#'
#' @param formula_obj A model formula object.
#'
#' @return Invisibly returns \code{TRUE} if no disallowed functions are found.
#'
#' @details
#' Throws an error if one or more disallowed functions appear in the formula.
#'
#' The function extracts all function names used in the formula via
#' \code{all.names(formula_obj, functions = TRUE)} and checks them against
#' the set defined in \code{DISALLOWED_FUNS}.
#'
#' Only the presence of the function name is checked; the function does not
#' attempt to validate arguments or evaluate the formula.
#'
#' @examples
#' fml <- y ~ log(x) + scale(z)
#'
#' epistemic:::check_disallowed_functions(fml)
#'
#' @keywords internal
check_disallowed_functions <- function(formula_obj) {
  calls <- all.names(formula_obj, functions = TRUE)
  bad <- intersect(calls, DISALLOWED_FUNS)
  if (length(bad) > 0) {
    msg <- paste(
      "Disallowed functions found in formula:",
      paste(bad, collapse = ", ")
    )
    cli::cli_abort(msg, call. = FALSE)
  }
  invisible(TRUE)
}

## ----------------------------------------------------
## Check that response variable(s) are not on the RHS
## ----------------------------------------------------


#' Ensure the response variable does not appear on the right-hand side
#'
#' Checks that variables used in the response (left-hand side) of a model
#' formula do not also appear on the right-hand side of the same formula.
#'
#' This validation helps prevent self-referential model specifications,
#' which are typically invalid or unsupported in regression-style models.
#'
#' @param formula_obj A model formula object.
#'
#' @return Invisibly returns \code{TRUE} if no response variables appear on
#'   the right-hand side of the formula.
#'
#' @details
#' Throws an error if one or more response variables are also found on the
#' right-hand side of the formula.
#'
#' The function extracts variables from the left-hand side (LHS) and
#' right-hand side (RHS) of the formula separately using \code{all.vars()}.
#' Any overlap between these sets is treated as an error.
#'
#' This check is purely syntactic and does not evaluate the formula.
#'
#' @examples
#' fml <- y ~ x + z
#' epistemic:::check_response_not_in_rhs(fml)
#'
#' fml_bad <- y ~ x + y
#' # check_response_not_in_rhs(fml_bad)  # errors
#'
#' @keywords internal
check_response_not_in_rhs <- function(formula_obj) {
  ## LHS expression and variables
  lhs_expr <- formula_obj[[2L]]
  lhs_vars <- all.vars(lhs_expr)

  ## RHS expression and variables
  rhs_expr <- formula_obj[[3L]]
  rhs_vars <- all.vars(rhs_expr)

  ## Any overlap means the response appears on RHS
  overlap <- intersect(lhs_vars, rhs_vars)

  if (length(overlap) > 0L) {
    msg <- paste(
      "The response variable also appear on the RHS:",
      paste(overlap, collapse = ", ")
    )
    cli::cli_abort(msg, call. = FALSE)
  }

  invisible(TRUE)
}


## ---------------------------------------
## Main validator (collects all errors)
## ---------------------------------------
#' Validate an INLA-style model formula
#'
#' Performs a sequence of syntactic and semantic checks on an INLA-style
#' model formula and reports all detected issues without stopping at the
#' first error.
#'
#' This function is intended as a user-facing validation entry point. It
#' parses the formula text, applies a series of validation checks, and
#' returns a structured summary indicating whether the formula is valid
#' and, if not, which errors were found.
#'
#' @param formula_txt A character string representing a model formula.
#' @param data_class An object containing the model data and associated
#'   metadata required for validation (e.g. a data table in \code{data}).
#'
#' @return
#' A list with the following elements:
#' \describe{
#'   \item{ok}{Logical scalar indicating whether the formula passed all checks.}
#'   \item{errors}{Character vector of error messages (empty if
#'   \code{ok = TRUE}).}
#' }
#'
#' @details
#' Validation proceeds in the following stages:
#' \enumerate{
#'   \item Parse the formula text using \code{\link[stats]{as.formula}}.
#'   \item Check for disallowed function calls.
#'   \item Validate the response variable.
#'   \item Ensure the response does not appear on the right-hand side.
#'   \item Verify that all variables referenced in the formula are present
#'         in the data.
#'   \item Validate all \code{f()} terms and their arguments.
#' }
#'
#' All checks are executed even if earlier checks fail, allowing multiple
#' errors to be reported in a single call. Errors are collected rather than
#' thrown, making this function suitable for interactive validation and
#' user-facing diagnostics.
#'
#' @examples
#' data_class <- list(
#'   data = data.frame(
#'     y = rnorm(10),
#'     x = rnorm(10),
#'     region_id = 1:10
#'   ),
#'   numerator_column = "y"
#' )
#'
#' fml_txt <- "y ~ x + f(region_id, model = 'iid')"
#'
#' epistemic:::validate_inla_formula(fml_txt, data_class)
#'
#' @keywords internal
validate_inla_formula <- function(formula_txt, data_class) {
  errors <- character(0L)
  ## 1. Parse formula (syntax check)
  formula_obj <- tryCatch(
    stats::as.formula(formula_txt),
    error = function(e) {
      msg <- paste("Formula syntax error:", e$message)
      errors <<- c(errors, msg)
      NULL
    }
  )

  ## If parsing failed, no point continuing
  if (is.null(formula_obj)) {
    return(
      list(
        ok = FALSE,
        errors = errors
      )
    )
  }

  ## Helper to run checks and collect error messages
  add_err <- function(expr) {
    tryCatch(
      {
        expr
        NULL
      },
      error = function(e) {
        e$message
      }
    )
  }

  ## 2. Run all checks
  errors <- c(
    errors,
    add_err(check_disallowed_functions(formula_obj)),
    add_err(check_response(formula_obj, data_class)),
    add_err(check_response_not_in_rhs(formula_obj)),
    add_err(check_vars_in_data(formula_obj, data_class)),
    add_err(check_f_terms(formula_obj, data_class))
  )

  ## Remove NULL entries (successful checks)
  errors <- Filter(Negate(is.null), errors)

  list(
    ok = length(errors) == 0L,
    errors = errors
  )
}
