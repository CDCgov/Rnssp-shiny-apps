# © 2025 The Johns Hopkins University Applied Physics Laboratory LLC
# Development of this software was sponsored by the U.S. Government under
# contract no. 75D30124C19958
# As of September 30, 2025 this code is pending review by OTT and should be
# considered JHU Propriety and only for internal JHU/APL use.

#' Demo Data
#'
#' Simple example of \code{data_class} object
#'
#' @format
#' A data frame with 104 rows and 6 columns:
#' \describe{
#'   \item{region}{character representation of location}
#'   \item{date}{date of event}
#'   \item{target}{number of target events in this location on this date}
#'   \item{overall}{number of all events in this location on this date}
#'   \item{expected}{expected number on this date/region, given marginals}
#'   \item{region_id_1}{integer identifier for region}
#'   \item{date_id_1}{integer identifier for date}
#' }
"demo_data"


#' Demo Adjacency Matrix
#'
#' Simple example of an adjacency matrix
#'
#' @format
#' A matrix with 24 rows and 24 columns.
"demo_adj_matrix"


#' Demo Model Result
#'
#' Simple example of a model result object
#'
#' @format
#' An INLA model object
"demo_model_result"

#' Demo Covariates
#'
#' Simple example of a data frame with static covariates that could be merged to
#' an object of class `data_class` using the \code{add_covariates()} function
#'
#' @format A data frame with 24 rows and 13 columns:
#' \describe{
#'   \item{location}{character representation of location}
#'   \item{pct_urban}{percent of population in urban areas}
#'   \item{college_pct}{percent of adult population with 4 year colleage degree}
#'   \item{median_hh_income}{median household income in dollars}
#'   \item{pct_non_insured_lt65}{percent less than 65 that are uninsured}
#'   \item{obesity}{age_adjusted percent obesity}
#'   \item{diabetes}{age_adjusted type II diabetes}
#'   \item{chd}{age_adjusted coronary heart disease percentage}
#'   \item{asthma}{age_adjusted asthma percentage}
#'   \item{hypertension}{age_adjusted hypertension percentage}
#'   \item{smoking}{age_adjusted smoking percentage}
#'   \item{cancer}{age_adjusted cancer percentage}
#'   \item{copd}{age_adjusted COPD percentage}
#' }
"demo_covariates"
