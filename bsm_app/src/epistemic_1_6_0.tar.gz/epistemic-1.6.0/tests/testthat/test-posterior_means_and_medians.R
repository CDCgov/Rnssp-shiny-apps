# © 2025 The Johns Hopkins University Applied Physics Laboratory LLC
# Development of this software was sponsored by the U.S. Government under
# contract no. 75D30124C19958
# As of September 30, 2025 this code is pending review by OTT and should be
# considered JHU Propriety and only for internal JHU/APL use.

data("demo_model_result")
data("demo_data")

inla_model <- demo_model_result$inla_model
data_cls <- demo_data
family <- inla_model$.args$family
scales <- get_scale_factors(data_cls, inla_model)

test_that("get_posterior_medians: function runs without error", {
  expect_silent({
    result <- get_posterior_medians(
      inla_model = inla_model,
      data_cls = demo_data
    )
  })
})

test_that("get_posterior_medians: output matches scaled median (counts)", {
  result <- get_posterior_medians(
    inla_model = inla_model,
    data_cls = demo_data,
    use_suffix = FALSE,
    use_count_scale = TRUE
  )

  expected_medians <- inla_model$summary.fitted.values[["0.5quant"]] *
    scales$count_scale
  expect_equal(result[["0.5quant"]], expected_medians, tolerance = 1e-3)
})

test_that("get_posterior_medians: output matches scaled median (props)", {
  result <- get_posterior_medians(
    inla_model = inla_model,
    data_cls = demo_data,
    use_suffix = FALSE,
    use_count_scale = FALSE
  )

  expected_medians <- inla_model$summary.fitted.values[["0.5quant"]] *
    scales$prop_scale
  expect_equal(
    result[["0.5quant"]],
    expected_medians,
    tolerance = 1e-3
  )
})

test_that("get_posterior_medians: returns expected columns with suffix", {
  result <- get_posterior_medians(
    inla_model = inla_model,
    data_cls = demo_data,
    use_suffix = TRUE,
    use_count_scale = TRUE
  )

  expect_s3_class(result, "data.frame")
  expect_equal(nrow(result), nrow(demo_data$data))
  expect_true("0.5quant_median_counts" %in% names(result))
})

test_that("get_posterior_means: output matches scaled means (counts)", {
  result <- get_posterior_means(
    inla_model = inla_model,
    data_cls = demo_data,
    use_suffix = TRUE,
    use_count_scale = TRUE
  )

  expected_means <- inla_model$summary.fitted.values[["mean"]] *
    scales$count_scale
  expect_equal(
    result[["predicted_mean_mean_counts"]],
    expected_means,
    tolerance = 1e-3
  )
})

test_that("get_posterior_means: output matches scaled means (props)", {
  result <- get_posterior_means(
    inla_model = inla_model,
    data_cls = demo_data,
    use_suffix = TRUE,
    use_count_scale = FALSE
  )

  expected_means <- inla_model$summary.fitted.values[["mean"]] *
    scales$prop_scale
  expect_equal(
    result[["predicted_mean_mean_props"]],
    expected_means,
    tolerance = 1e-3
  )
})

test_that("get_posterior_means: filters correctly", {
  dates <- as.Date(c("2024-01-01", "2024-01-08"))
  regions <- c("X0001", "X0003")
  result <- get_posterior_means(
    inla_model = inla_model,
    data_cls = data_cls,
    dates = dates,
    regions = regions
  )
  res_regions <- result[[data_cls$region_column]]
  res_dates <- result[[data_cls$date_column]]

  expect_true(all(res_regions %in% regions))
  expect_true(all(res_dates %in% dates))
  expect_true(all(regions %in% res_regions))
  expect_true(all(dates %in% res_dates))
})

test_that("get_posterior_medians: filters correctly", {
  dates <- as.Date(c("2024-01-01", "2024-01-08"))
  regions <- c("X0001", "X0003")
  result <- get_posterior_medians(
    inla_model = inla_model,
    data_cls = data_cls,
    dates = dates,
    regions = regions
  )
  res_regions <- result[[data_cls$region_column]]
  res_dates <- result[[data_cls$date_column]]

  expect_true(all(res_regions %in% regions))
  expect_true(all(res_dates %in% dates))
  expect_true(all(regions %in% res_regions))
  expect_true(all(dates %in% res_dates))
})
