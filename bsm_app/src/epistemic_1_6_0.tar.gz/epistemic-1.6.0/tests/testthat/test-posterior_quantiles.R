# © 2025 The Johns Hopkins University Applied Physics Laboratory LLC
# Development of this software was sponsored by the U.S. Government under
# contract no. 75D30124C19958
# As of September 30, 2025 this code is pending review by OTT and should be
# considered JHU Propriety and only for internal JHU/APL use.

# Load demo data and model result
data("demo_data")
data("demo_model_result")

inla_model <- demo_model_result$inla_model
data_cls <- demo_data
test_that("get_posterior_quantiles: runs without error", {
  expect_silent({
    result <- get_posterior_quantiles(
      inla_model = inla_model,
      data_cls = data_cls
    )
  })
})

test_that("get_posterior_quantiles: filters correctly", {
  probs <- c(0.1, 0.5, 0.9)
  dates <- as.Date(c("2024-01-01", "2024-01-08"))
  regions <- c("X0001", "X0003")
  result <- get_posterior_quantiles(
    inla_model = inla_model,
    data_cls = data_cls,
    dates = dates,
    regions = regions,
    probs = probs
  )
  res_regions <- result[[data_cls$region_column]]
  res_dates <- result[[data_cls$date_column]]

  expect_true(all(res_regions %in% regions))
  expect_true(all(res_dates %in% dates))
  expect_true(all(regions %in% res_regions))
  expect_true(all(dates %in% res_dates))
})

test_that("get_posterior_quantiles: returns expected structure", {
  probs <- c(0.1, 0.5, 0.9)
  result <- get_posterior_quantiles(
    inla_model = inla_model,
    data_cls = data_cls,
    probs = probs
  )

  expect_s3_class(result, "data.table")
  expect_equal(nrow(result), nrow(data_cls$data))
  expect_equal(names(result)[1:2], c(data_cls$region_col, data_cls$date_col))

  # Column names should include suffixes based on the probs
  expect_true(all(paste0("counts_", probs) %in% names(result)))
})

test_that("get_posterior_quantiles: works with proportion scale", {
  probs <- c(0.25, 0.5, 0.75)
  result <- get_posterior_quantiles(
    inla_model = inla_model,
    data_cls = data_cls,
    probs = probs,
    use_count_scale = FALSE
  )

  expect_true(all(paste0("props_", probs) %in% names(result)))
})

test_that("get_posterior_quantiles: use_suffix = FALSE returns generic names", {
  probs <- c(0.05, 0.95)
  result <- get_posterior_quantiles(
    inla_model = inla_model,
    data_cls = data_cls,
    probs = probs,
    use_suffix = FALSE
  )

  # Expect only numeric column names
  expect_true(all(as.character(probs) %in% names(result)))
})

test_that("get_posterior_quantiles: invalid probs triggers error", {
  expect_error(
    get_posterior_quantiles(
      inla_model = inla_model,
      data_cls = data_cls,
      probs = c(-0.1, 0.5, 1.1)
    ),
    "all probabilities must be between 0 and 1"
  )
})

test_that("get_posterior_quantiles: custom len works without error", {
  result <- get_posterior_quantiles(
    inla_model = inla_model,
    data_cls = data_cls,
    len = 1024
  )
  expect_s3_class(result, "data.table")
  expect_equal(nrow(result), nrow(data_cls$data))
})

test_that("get_posterior_quantiles: quantile 0.5 matches medians", {
  for (use_count_scale in c(TRUE, FALSE)) {
    quantiles <- get_posterior_quantiles(
      inla_model = inla_model,
      data_cls = data_cls,
      probs = c(0.5),
      use_suffix = FALSE,
      use_count_scale = use_count_scale
    )
    medians <- get_posterior_medians(
      inla_model = inla_model,
      data_cls = data_cls,
      use_suffix = FALSE,
      use_count_scale = use_count_scale
    )
    arr1 <- quantiles[["0.5"]]
    arr2 <- medians[["0.5quant"]]
    expect_equal(
      object = abs(1 - arr1 / arr2),
      expected = rep(0, length(arr1)),
      tolerance = .001
    )
  }
})

test_that(
  "get_posterior_quantiles: invalid rows get removed without any
  problems - binomial",
  {
    # add some future dates:
    dc <- add_missing_and_future_dates(4, demo_data, den_fill_val = 1)
    # run a basic model: binomial
    m <- fit_model(
      dc,
      target ~ 1 + f(date_id_1, model = "rw1"),
      family = "binomial"
    )
    # set some probs
    probs <- c(0.25, 0.5, 0.75)
    # get posterior quantiles
    q <- get_posterior_quantiles(
      m$inla_model, dc,
      probs = probs, use_count_scale = TRUE
    )
    # index of rows that should be converted to NA, because count is TRUE
    indx <- which(dc$data$denominator_source > 0)
    na_row <- q[indx]
    for (col in names(q)[3:ncol(q)]) {
      expect_true(all(is.na(na_row[[col]])))
    }

    # get posterior quantiles, with scale =F (no rows should be NA)
    q <- get_posterior_quantiles(
      m$inla_model, dc,
      probs = probs, use_count_scale = FALSE
    )
    # index of rows that should be converted to NA, because count is TRUE
    indx <- which(dc$data$denominator_source > 0)
    na_row <- q[indx]
    for (col in names(q)[3:ncol(q)]) {
      expect_false(any(is.na(na_row[[col]])))
    }
  }
)

test_that(
  "get_posterior_quantiles: invalid rows get removed without any
  problem - poisson",
  {
    # add some future dates:
    dc <- add_missing_and_future_dates(4, demo_data, den_fill_val = 1)
    # run a basic model: binomial
    m <- fit_model(
      dc,
      target ~ 1 + f(date_id_1, model = "rw1"),
      family = "poisson"
    )
    # set some probs
    probs <- c(0.25, 0.5, 0.75)


    # get posterior quantiles, with scale =T (no rows should be NA)
    q <- get_posterior_quantiles(
      m$inla_model, dc,
      probs = probs, use_count_scale = TRUE
    )
    # index of rows that should be converted to NA, because count is TRUE
    indx <- which(dc$data$denominator_source > 0)
    na_row <- q[indx]
    for (col in names(q)[3:ncol(q)]) {
      expect_false(any(is.na(na_row[[col]])))
    }

    # get posterior quantiles, with scale =T (no rows should be F)
    q <- get_posterior_quantiles(
      m$inla_model, dc,
      probs = probs, use_count_scale = FALSE
    )
    # index of rows that should be converted to NA, because count is TRUE
    indx <- which(dc$data$denominator_source > 0)
    na_row <- q[indx]
    for (col in names(q)[3:ncol(q)]) {
      expect_true(all(is.na(na_row[[col]])))
    }
  }
)

data_cls$data[
  ,
  region_group := data.table::fcase(
    region %in% c("X0001", "X0002"), "RG1",
    region %in% c("X0003", "X0004"), "RG2",
    default = "RG3"
  )
]


test_that(
  "get_posterior_quantiles_group: median approx equals naive sum",
  {
    probs <- c(0.5)
    date1 <- as.Date("2024-01-01")
    regions <- paste0("X000", 1:4)

    # Pointwise quantiles: region + date + counts_0.5
    q_ind <- get_posterior_quantiles(
      inla_model = inla_model,
      data_cls = data_cls,
      probs = probs,
      use_suffix = TRUE,
      use_count_scale = TRUE,
      regions = regions,
      dates = date1
    )
    q_ind_dt <- data.table::as.data.table(q_ind)

    # Bring in region_group from data_cls$data via region+date join
    key_dt <- data.table::as.data.table(
      data_cls$data[
        ,
        .(
          region = get(data_cls$region_column),
          date = get(data_cls$date_column),
          region_group
        )
      ]
    )

    data.table::setkey(key_dt, region, date)

    q_ind_dt[
      ,
      `:=`(
        region = get(data_cls$region_column),
        date = get(data_cls$date_column)
      )
    ]
    q_ind_dt <- key_dt[q_ind_dt]

    # Naive group total: sum of marginal medians
    naive_med <- q_ind_dt[
      ,
      .(naive_median = sum(counts_0.5, na.rm = FALSE)),
      by = .(region_group, date)
    ]

    # Correct group median from aggregate function
    agg <- get_posterior_quantiles_group(
      inla_model = inla_model,
      data_cls = data_cls,
      probs = probs,
      use_suffix = TRUE,
      use_count_scale = TRUE,
      regions = regions,
      dates = date1,
      group_cols = c("region_group", data_cls$date_column),
      n_samples = 8000L,
      na.rm = FALSE
    )
    agg_dt <- data.table::as.data.table(agg)
    # Ensure same date column name used for merge
    agg_dt[
      ,
      date := get(data_cls$date_column)
    ]

    data.table::setnames(
      agg_dt,
      "counts_0.5",
      "correct_median"
    )

    m <- merge(
      naive_med,
      agg_dt[, .(region_group, date, correct_median)],
      by = c("region_group", "date")
    )

    rel_err <- abs(m$naive_median - m$correct_median) /
      pmax(1, abs(m$correct_median))

    expect_true(all(rel_err < 0.05))
  }
)


test_that(
  "get_posterior_quantiles_group: median approx equals naive sum (props)",
  {
    probs <- c(0.5)
    date1 <- as.Date("2024-01-01")
    regions <- paste0("X000", 1:4)

    # Pointwise quantiles
    q_ind <- get_posterior_quantiles(
      inla_model = inla_model,
      data_cls = data_cls,
      probs = probs,
      use_suffix = TRUE,
      use_count_scale = FALSE,
      regions = regions,
      dates = date1
    )
    q_ind_dt <- data.table::as.data.table(q_ind)
    # Bring in region_group from data_cls$data via region+date join
    key_dt <- data.table::as.data.table(
      data_cls$data[
        ,
        .(
          region = get(data_cls$region_column),
          date = get(data_cls$date_column),
          region_group
        )
      ]
    )

    data.table::setkey(key_dt, region, date)

    q_ind_dt[
      ,
      `:=`(
        region = get(data_cls$region_column),
        date = get(data_cls$date_column)
      )
    ]
    q_ind_dt <- key_dt[q_ind_dt]

    # Naive group total: sum of marginal medians
    naive_med <- q_ind_dt[
      ,
      .(naive_median = sum(props_0.5, na.rm = FALSE)),
      by = .(region_group, date)
    ]

    # Correct group median from aggregate function
    agg <- get_posterior_quantiles_group(
      inla_model = inla_model,
      data_cls = data_cls,
      probs = probs,
      use_suffix = TRUE,
      use_count_scale = FALSE,
      regions = regions,
      dates = date1,
      group_cols = c("region_group", data_cls$date_column),
      n_samples = 8000L,
      na.rm = FALSE
    )
    agg_dt <- data.table::as.data.table(agg)
    # Ensure same date column name used for merge
    agg_dt[
      ,
      date := get(data_cls$date_column)
    ]

    data.table::setnames(
      agg_dt,
      "props_0.5",
      "correct_median"
    )

    m <- merge(
      naive_med,
      agg_dt[, .(region_group, date, correct_median)],
      by = c("region_group", "date")
    )

    rel_err <- abs(m$naive_median - m$correct_median) /
      pmax(1, abs(m$correct_median))

    expect_true(all(rel_err < 0.05))
  }
)


test_that(
  "get_posterior_quantiles_group: naive CI wider than aggregate CI",
  {
    probs <- c(0.025, 0.975)
    date1 <- as.Date("2024-01-01")
    regions <- paste0("X000", 1:4)

    q_ind <- get_posterior_quantiles(
      inla_model = inla_model,
      data_cls = data_cls,
      probs = probs,
      use_suffix = TRUE,
      use_count_scale = TRUE,
      regions = regions,
      dates = date1
    )
    q_ind_dt <- data.table::as.data.table(q_ind)
    # Add region_group by joining from data_cls$data
    key_dt <- data.table::as.data.table(
      data_cls$data[
        ,
        .(
          region = get(data_cls$region_column),
          date = get(data_cls$date_column),
          region_group
        )
      ]
    )
    data.table::setkey(key_dt, region, date)

    q_ind_dt[
      ,
      `:=`(
        region = get(data_cls$region_column),
        date = get(data_cls$date_column)
      )
    ]
    q_ind_dt <- key_dt[q_ind_dt]

    # Naive: sum marginal tails; CI width
    naive_ci <- q_ind_dt[
      ,
      .(
        naive_lo = sum(counts_0.025, na.rm = FALSE),
        naive_hi = sum(counts_0.975, na.rm = FALSE)
      ),
      by = .(region_group, date)
    ]
    naive_ci[, naive_width := naive_hi - naive_lo]

    # Correct aggregate CI width
    agg <- get_posterior_quantiles_group(
      inla_model = inla_model,
      data_cls = data_cls,
      probs = probs,
      use_suffix = TRUE,
      use_count_scale = TRUE,
      regions = regions,
      dates = date1,
      group_cols = c("region_group", data_cls$date_column),
      n_samples = 8000L,
      na.rm = FALSE
    )
    agg_dt <- data.table::as.data.table(agg)

    agg_dt[
      ,
      date := get(data_cls$date_column)
    ]
    agg_dt[
      ,
      correct_width := counts_0.975 - counts_0.025
    ]

    m <- merge(
      naive_ci,
      agg_dt[, .(region_group, date, correct_width)],
      by = c("region_group", "date")
    )
    tol <- 1e-6
    expect_true(all(m$naive_width >= m$correct_width - tol))
  }
)
