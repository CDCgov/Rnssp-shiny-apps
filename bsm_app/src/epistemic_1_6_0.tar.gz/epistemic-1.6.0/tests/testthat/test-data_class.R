# © 2025 The Johns Hopkins University Applied Physics Laboratory LLC
# Development of this software was sponsored by the U.S. Government under
# contract no. 75D30124C19958
# As of September 30, 2025 this code is pending review by OTT and should be
# considered JHU Propriety and only for internal JHU/APL use.

library(testthat)

# Sample data for tests
test_df <- data.frame(
  id = 1:5,
  region = letters[1:5],
  date = as.Date("2025-01-01") + 0:4,
  num = rnorm(5),
  den = rnorm(5),
  exp = rnorm(5),
  feature1 = rnorm(5)
)

test_that("data_class constructs valid object", {
  obj <- data_class(
    data = test_df,
    region_column = "region",
    date_column = "date",
    numerator_column = "num",
    denominator_column = "den",
    expected_column = "exp",
    feature_columns = c("feature1")
  )

  expect_s3_class(obj, "data_class")
  expect_equal(obj$region_column, "region")
  expect_equal(obj$date_column, "date")
  expect_equal(obj$numerator_column, "num")
  expect_equal(obj$denominator_column, "den")
  expect_equal(obj$expected_column, "exp")
  expect_equal(obj$feature_columns, "feature1")
  expect_equal(nrow(obj$data), 5)
})

test_that("data_class generates expected on demand", {
  test_df <- data.frame(
    region = c("A", "A", "B", "B"),
    date   = as.Date(c("2024-01-01", "2024-01-08")),
    num    = c(10, 20, 30, 40),
    den    = c(100, 200, 300, 400),
    exp    = 0
  )

  obj <- data_class(
    data = test_df,
    region_column = "region",
    date_column = "date",
    numerator_column = "num",
    denominator_column = "den",
    generate_expected = TRUE
  )
  expect_equal(obj$expected_column, "expected")
  expect_equal(obj$data$expected, c(12, 18, 28, 42))

  obj <- data_class(
    data = test_df,
    region_column = "region",
    date_column = "date",
    numerator_column = "num",
    denominator_column = "den",
    expected_column = "exp",
    generate_expected = TRUE
  )
  expect_equal(obj$expected_column, "exp")
  expect_equal(obj$data$exp, c(12, 18, 28, 42))
})
test_that("data_class throws error on invalid inputs", {
  expect_error(
    data_class(1:10, "region", "date", "num", "den", c()),
    "`data` must be a data.frame"
  )

  expect_error(
    data_class(test_df, "not_a_col", "date", "num", "den", c()),
    class = "name_not_found"
  )

  expect_error(
    data_class(test_df, "region", "not_a_date", "num", "den", c()),
    class = "name_not_found"
  )

  bad_df <- test_df
  bad_df$date <- as.character(bad_df$date)
  expect_error(
    data_class(bad_df, "region", "date", "num", "den", c()),
    "`date_column` must be of class Date or POSIXt"
  )

  expect_error(
    data_class(test_df, "region", "date", "not_a_col", "den", c()),
    class = "name_not_found"
  )

  expect_error(
    data_class(test_df, "region", "date", "num", "not_a_col", c()),
    class = "name_not_found"
  )

  bad_df2 <- test_df
  bad_df2$num <- as.character(bad_df2$num)
  expect_error(
    data_class(bad_df2, "region", "date", "num", "den", c()),
    "Column 'num' must be numeric"
  )
})

test_that("add_column.data_class adds column and updates features optionally", {
  obj <- data_class(
    test_df,
    region_column = "region",
    date_column = "date",
    numerator_column = "num",
    denominator_column = "den",
    feature_columns = c("feature1")
  )

  new_values <- obj$data$num / obj$data$den
  obj <- add_column.data_class(obj, "rate", new_values, add_to_features = TRUE)

  expect_true("rate" %in% names(obj$data))
  expect_equal(obj$data$rate, new_values)
  expect_true("rate" %in% obj$feature_columns)

  # Without adding to features
  obj2 <- add_column.data_class(obj, "rate_sq", (obj$data$rate)**2)
  expect_true("rate_sq" %in% names(obj2$data))
  expect_true("rate_sq" %in% obj2$feature_columns)
})

test_that("add_column.data_class input validation works", {
  obj <- data_class(
    test_df,
    region_column = "region",
    date_column = "date",
    numerator_column = "num",
    denominator_column = "den",
    feature_columns = c("feature1")
  )

  expect_error(
    add_column.data_class("not_obj", "col", 1:5),
    "Object must be of class 'data_class'"
  )

  expect_error(
    add_column.data_class(obj, c("a", "b"), 1:5),
    "`column_name` must be a single string"
  )

  expect_error(
    add_column.data_class(obj, "wrong_length", 1:10),
    "Length of `values` must match number of rows in `data`"
  )
})

test_that("print.data_class outputs expected content", {
  obj <- data_class(
    test_df,
    region_column = "region",
    date_column = "date",
    numerator_column = "num",
    denominator_column = "den",
    feature_columns = c("feature1")
  )

  expect_output(print(obj), "An object of class 'data_class'")
  expect_output(print(obj), "Region column: region")
  expect_output(print(obj), "Data \\(first 5 of 5 rows\\):")
})


# tests for add expected
test_df <- data.table(
  region = c("A", "A", "B", "B"),
  date   = as.Date(c("2024-01-01", "2024-01-08")),
  num    = c(10, 20, 30, 40),
  den    = c(100, 200, 300, 400)
)


test_that("errors if obj is not a data_class", {
  expect_error(
    add_expected(list(), "exp"),
    "Object must be of class 'data_class'"
  )
})


obj <- data_class(
  test_df,
  region_column = "region",
  date_column = "date",
  numerator_column = "num",
  denominator_column = "den",
)

test_that("errors if varname exists and replace = FALSE", {
  # first run to create 'expected'
  dc <- add_expected(obj, varname = "expected")
  expect_error(
    add_expected(dc, varname = "expected", replace = FALSE),
    "there is already a column named `expected`"
  )
})

test_that("overwrites existing column when replace = TRUE", {
  dc <- add_expected(obj, varname = "foo")
  # modify to check overwrite
  dc$data[, foo := -1]
  dc2 <- add_expected(dc, varname = "foo", replace = TRUE)
  vals <- dc2$data[["foo"]]
  expect_false(all(vals == -1))
  # check that foo now matches expected formula for first row
  # region A date 1 => 300*40/1000 = 12
  expect_equal(vals[dc2$data$region == "A" & dc2$data$date == "2024-01-01"], 12)
})

test_that("computes correct expected values with default varname", {
  dc <- add_expected(obj, replace = TRUE)
  # manual expected for A/date=1 is 300*40/1000 = 12
  dt <- dc$data
  got <- dt[region == "A" & date == "2024-01-01", expected]
  expect_equal(got, 12)
  # check another cell: B/date=2 => 700*60/1000 = 42
  expect_equal(
    dt[region == "B" & date == "2024-01-08", expected],
    42
  )
})

test_that("allows custom varname", {
  out <- add_expected(obj, varname = "exp_count")
  expect_true("exp_count" %in% names(out$data))
  expect_equal(out$expected_column, "exp_count")
})

test_that("validate_data_class errors if date column is not Date", {
  dc <- data_class(
    data = test_df,
    region_column = "region",
    date_column = "date",
    numerator_column = "num",
    denominator_column = "den"
  )
  # convert date column to character
  dc$data[[dc$date_column]] <- as.character(dc$data[[dc$date_column]])
  expect_error(
    validate_data_class(dc),
    "Column 'date' must be of class Date"
  )
})

# tests for add_missing_and_future_dates
data("demo_data")
dc <- demo_data

test_that("add_missing_and_future_dates adds correct number of rows (weekly)", {
  # Determine number of regions and original rows
  n_regions <- length(unique(dc$data$region))
  original_n <- nrow(dc$data)

  # Add 3 future steps with freq = "weekly"
  dc_future <- add_missing_and_future_dates(
    num_future_steps = 3,
    dc = dc,
    freq = "weekly"
  )

  # The new total rows should be original + (n_regions * 3)
  expect_equal(nrow(dc_future$data), original_n + n_regions * 3)

  # Check that the max date has been extended by 3*7 days
  max_original <- max(dc$data$date)
  max_new <- max(dc_future$data$date)
  expect_equal(max_new, max_original + 3 * 7)

  # Ensure existing rows were unchanged (numerator and denominator)
  sample_idx <- 5
  expect_equal(
    dc_future$data[
      region == dc$data$region[sample_idx] & date == dc$data$date[sample_idx],
      target
    ],
    dc$data$target[sample_idx]
  )
})

test_that("add_missing_and_future_dates respects forward_fill argument", {
  # Add 3 future steps without forward fill
  dc_no_fill <- add_missing_and_future_dates(
    num_future_steps = 3,
    dc = dc,
    freq = "weekly",
    forward_fill = FALSE
  )

  # Add 3 future steps with forward fill
  dc_fill <- add_missing_and_future_dates(
    num_future_steps = 3,
    dc = dc,
    freq = "weekly",
    forward_fill = TRUE
  )

  # Identify the max date in the original data
  max_date <- max(dc$data$date)

  # Get future dates
  future_dates <- sort(unique(dc_fill$data$date[dc_fill$data$date > max_date]))

  # Check that expected is NA when forward_fill=FALSE
  na_counts <- dc_no_fill$data[date %in% future_dates,
    .(na_count = sum(is.na(expected))),
    by = region
  ]
  expect_true(all(na_counts$na_count == length(future_dates)))

  # Check that forward-filled expected column has no NAs for those future rows
  has_na_fill <- dc_fill$data[date %in% future_dates, any(is.na(expected))]
  expect_false(has_na_fill)
})


test_that("add_missing_and_future_dates fills num/den correctly", {
  n_regions <- length(unique(dc$data$region))

  # Use freq = "weekly" explicitly
  dc_filled <- add_missing_and_future_dates(
    num_future_steps = 2,
    dc = dc,
    freq = "weekly",
    num_fill_val = 0,
    den_fill_val = 1
  )

  # Identify new dates
  max_original <- max(dc$data$date)
  step <- 7
  new_dates <- c(max_original + step, max_original + 2 * step)

  # For each new date and each region, check that target == 0 and overall == 1
  for (d in new_dates) {
    for (r in unique(dc$data$region)) {
      row <- dc_filled$data[region == r & date == d]
      expect_true(nrow(row) == 1)
      expect_equal(row$target, 0)
      expect_equal(row$overall, 1)
    }
  }
})

test_that("num_fill_val sets numerator_source == 2 for new rows", {
  dc <- demo_data
  original_max_date <- max(dc$data[[dc$date_column]])

  dc_extended <- add_missing_and_future_dates(
    num_future_steps = 2,
    dc = dc,
    freq = "daily",
    num_fill_val = 0
  )

  new_rows <- dc_extended$data[
    get(dc_extended$date_column) > original_max_date
  ]

  expect_true("numerator_source" %in% names(dc_extended$data))
  expect_true(all(new_rows$numerator_source == 2))
})

test_that("den_fill_val sets denominator_source == 2 for new rows", {
  dc <- demo_data
  original_max_date <- max(dc$data[[dc$date_column]])

  dc_extended <- add_missing_and_future_dates(
    num_future_steps = 2,
    dc = dc,
    freq = "daily",
    den_fill_val = 1
  )

  new_rows <- dc_extended$data[
    get(dc_extended$date_column) > original_max_date
  ]

  expect_true("denominator_source" %in% names(dc_extended$data))
  expect_true(all(new_rows$denominator_source == 2))
})


test_that("freq = 'infer' matches explicit weekly when data is weekly", {
  # demo_data is weekly; so infer should match 7-day increment
  n_regions <- length(unique(dc$data$region))
  original_n <- nrow(dc$data)

  dc_inferred <- add_missing_and_future_dates(
    num_future_steps = 2,
    dc = dc,
    freq = "infer"
  )
  dc_weekly <- add_missing_and_future_dates(
    num_future_steps = 2,
    dc = dc,
    freq = "weekly"
  )

  expect_equal(nrow(dc_inferred$data), nrow(dc_weekly$data))
  expect_equal(max(dc_inferred$data$date), max(dc_weekly$data$date))
})

test_that("add_missing_and_future_dates errors when infer on irregular dates", {
  # Create a small irregular data_class
  df_irregular <- data.table(
    region = c("A", "A", "B", "B"),
    date = as.Date(c("2025-01-01", "2025-01-03", "2025-01-02", "2025-01-05")),
    target = c(1, 2, 3, 4),
    overall = c(5, 6, 7, 8)
  )
  dc_irreg <- data_class(
    data = df_irregular,
    region_column = "region",
    date_column = "date",
    numerator_column = "target",
    denominator_column = "overall"
  )
  expect_error(
    add_missing_and_future_dates(
      num_future_steps = 1,
      dc = dc_irreg,
      freq = "infer"
    ),
    "Cannot infer frequency"
  )
})

test_that("daily frequency works and fills correct dates", {
  n_regions <- length(unique(dc$data$region))
  original_n <- nrow(dc$data)

  # make a copy of the date, and convert the weekly dates
  # to daily
  dc_copy <- copy_data_class(dc)
  dates <- dc$data[[dc[["date_column"]]]] |> unique()
  date_lookup <- data.frame(
    date = dates,
    daily = seq.Date(dates[1], by = 1, length.out = length(dates))
  )
  dc_copy$data <- dc_copy$data[date_lookup, on = "date"]
  dc_copy$data[, date := daily]
  dc_copy$data[, daily := NULL]

  # Add 5 daily steps
  dc_daily <- add_missing_and_future_dates(
    num_future_steps = 5, dc = dc_copy, freq = "daily"
  )
  # Should add 5 * n_regions rows
  expect_equal(nrow(dc_daily$data), original_n + 5 * n_regions)

  # Check that new dates start one day after max(original)
  max_original <- max(dc_copy$data$date)
  expected_new_dates <- max_original + seq(1, 5)
  actual_new_dates <- sort(unique(dc_daily$data$date))
  expect_true(all(expected_new_dates %in% actual_new_dates))
})

test_that("original data_class object is not modified", {
  # Copy original to compare
  dc_copy <- copy_data_class(dc)

  x <- add_missing_and_future_dates(
    num_future_steps = 1,
    dc = dc_copy,
    freq = "weekly"
  )
  # Ensure dc$data and dc_copy$data remain identical
  expect_equal(dc$data, dc_copy$data)
})


# Helper: create a minimal data_class without any IDs
mk_minimal_dc <- function() {
  df <- data.table(
    region = c("A", "B"),
    date = as.Date(c("2025-01-01", "2025-01-08")),
    target = c(5, 10),
    overall = c(50, 100)
  )
  dc <- data_class(
    data = df,
    region_column = "region",
    date_column = "date",
    numerator_column = "target",
    denominator_column = "overall"
  )
  dc
}

test_that("returns unchanged when has_region_ids is NULL or FALSE", {
  dc0 <- mk_minimal_dc()
  out0 <- update_date_region_ids(dc0)
  expect_identical(out0, dc0)

  data.table::setattr(dc0, "has_region_ids", FALSE)
  out1 <- update_date_region_ids(dc0)
  expect_identical(out1, dc0)
})

test_that("errors if has_region_ids = TRUE but no region_identifiers", {
  dc1 <- mk_minimal_dc()
  data.table::setattr(dc1, "has_region_ids", TRUE)
  # explicitly clear region_identifiers
  dc1$region_identifiers <- character(0)
  expect_error(
    update_date_region_ids(dc1),
    "but no region_ids"
  )
})

test_that("regenerates ID columns when has_region_ids = TRUE", {
  # Start with a data_class and add one set of IDs
  dc2 <- mk_minimal_dc()
  # Add date/region IDs once (default suffix "_id_")
  dc2 <- add_date_and_region_ids(dc2, num_duplicates = 1)
  data.table::setattr(dc2, "has_region_ids", TRUE)

  # Remove the existing ID columns to simulate regeneration
  dc2$data[, c("date_id_1", "region_id_1") := NULL]
  dc2$region_identifiers <- c("region_id_1")
  dc2$date_identifiers <- c("date_id_1")

  # Now update_date_region_ids() should re-add those two columns
  dc3 <- update_date_region_ids(dc2)
  expect_true(all(c("date_id_1", "region_id_1") %in% names(dc3$data)))
  expect_equal(length(dc3$region_identifiers), 1)
  expect_equal(dc3$region_identifiers, "region_id_1")
})

test_that(
  "regenerates multiple ID columns if length(obj$region_identifiers)>1",
  {
    dc4 <- mk_minimal_dc()
    # Add two sets of IDs with custom suffix "_X_"
    dc4 <- add_date_and_region_ids(dc4, num_duplicates = 4, suffix = "_X_")
    data.table::setattr(dc4, "has_region_ids", TRUE)

    # Remove new ID columns
    id_cols <- dc4$region_identifiers
    dc4$data[, (c(dc4$date_identifiers, dc4$region_identifiers)) := NULL]
    # Keep identifiers list intact
    dc4
    # Now update_date_region_ids() should re-add both sets
    dc5 <- update_date_region_ids(dc4)
    expect_true(all(dc5$region_identifiers %in% names(dc5$data)))
    expect_true(all(dc5$date_identifiers %in% names(dc5$data)))
    expect_equal(length(dc5$region_identifiers), 4)
  }
)

test_that("data_class subsetting works properly", {
  test_df <- data.frame(
    region = c("A", "A", "B", "B"),
    date   = as.Date(c("2024-01-01", "2024-01-08")),
    num    = c(10, 20, 30, 40),
    den    = c(100, 200, 300, 400),
    exp    = 0
  )
  obj <- data_class(
    data = test_df,
    region_column = "region",
    date_column = "date",
    numerator_column = "num",
    denominator_column = "den",
  )

  regions <- c("B")
  dates <- c(as.Date("2024-01-01"))
  inds1 <- get_subset_indices.data_class(obj, regions = NULL, dates = NULL)
  inds2 <- get_subset_indices.data_class(obj, regions = regions, dates = NULL)
  inds3 <- get_subset_indices.data_class(obj, regions = NULL, dates = dates)
  inds4 <- get_subset_indices.data_class(obj, regions = regions, dates = dates)
  expect_equal(inds1, seq_len(nrow(test_df)))
  expect_equal(inds2, c(3, 4))
  expect_equal(inds3, c(1, 3))
  expect_equal(inds4, c(3))
})

# Utility: repeat/extend a short date pattern to the length of the
# current obj$data
.repeat_dates_to_n <- function(dates, n) rep_len(as.Date(dates), n)
data("demo_data")
obj <- demo_data

test_that("add_mmwr_week handles cross-year Week 1 and preserves dimensions", {
  old_data <- data.table::copy(obj$data) # deep copy
  on.exit(
    {
      obj$data <- old_data
    },
    add = TRUE
  )

  dc <- obj$date_column
  n <- nrow(obj$data)

  # Pattern spanning the MMWR 2024→2025 boundary:
  # Sat 2024-12-28 (2024 W52), Sun 2024-12-29 (2025 W1),
  # Wed 2025-01-01 (2025 W1), Sun 2025-01-05 (2025 W2)
  pattern_dates <- as.Date(c(
    "2024-12-28", "2024-12-29",
    "2025-01-01", "2025-01-05"
  ))
  pattern_week <- c(52L, 1L, 1L, 2L)
  pattern_year <- c(2024L, 2025L, 2025L, 2025L)

  obj$data[[dc]] <- .repeat_dates_to_n(pattern_dates, n)

  obj2 <- add_mmwr_week(obj,
    column_name = "week_id",
    add_year = TRUE,
    year_col = "mmwr_year"
  )

  expect_equal(nrow(obj2$data), n)
  expect_true(all(c("week_id", "mmwr_year") %in% names(obj2$data)))
  expect_type(obj2$data$week_id, "integer")
  expect_type(obj2$data$mmwr_year, "integer")

  # The pattern should repeat across all rows
  expect_equal(
    obj2$data$week_id,
    rep_len(pattern_week, n)
  )
  expect_equal(
    obj2$data$mmwr_year,
    rep_len(pattern_year, n)
  )
})

test_that("add_mmwr_week coalesce_53_to_52 clamps week 53", {
  old_data <- data.table::copy(obj$data) # deep copy
  on.exit(
    {
      obj$data <- old_data
    },
    add = TRUE
  )

  dc <- obj$date_column
  n <- nrow(obj$data)

  # Span late Dec → early Jan around years that often have week 53.
  # Even if this specific pattern does not hit 53 in some calendars,
  # the assertions remain correct and future-proof.
  pattern_dates <- seq(as.Date("2015-12-20"), as.Date("2016-01-10"), by = "day")
  obj$data[[dc]] <- .repeat_dates_to_n(pattern_dates, n)

  obj_no_clamp <- add_mmwr_week(obj,
    column_name = "w_no_clamp",
    coalesce_53_to_52 = FALSE
  )
  obj_clamped <- add_mmwr_week(obj,
    column_name = "w_clamp",
    coalesce_53_to_52 = TRUE
  )

  expect_equal(nrow(obj_clamped$data), n)
  expect_true(
    all(
      obj_clamped$data$w_clamp >= 1L & obj_clamped$data$w_clamp <= 52L
    )
  )

  # If any 53s existed originally, they become 52 after clamping.
  idx53 <- which(obj_no_clamp$data$w_no_clamp == 53L)
  if (length(idx53) > 0) {
    expect_true(all(obj_clamped$data$w_clamp[idx53] == 52L))
  }
})

test_that("add_day_of_week (Sunday-start) uses epi convention", {
  old_data <- data.table::copy(obj$data) # deep copy
  on.exit(
    {
      obj$data <- old_data
    },
    add = TRUE
  )

  dc <- obj$date_column
  n <- nrow(obj$data)

  # Sat, Sun, Mon pattern → epi DOW should be 7, 1, 2 (repeating)
  pattern_dates <- as.Date(c("2025-01-04", "2025-01-05", "2025-01-06"))
  pattern_dow <- c(7L, 1L, 2L)
  obj$data[[dc]] <- .repeat_dates_to_n(pattern_dates, n)

  obj2 <- add_day_of_week(obj, column_name = "dow_epi", sunday_start = TRUE)

  expect_equal(nrow(obj2$data), n)
  expect_true("dow_epi" %in% names(obj2$data))
  expect_type(obj2$data$dow_epi, "integer")
  expect_equal(obj2$data$dow_epi, rep_len(pattern_dow, n))
})

test_that("add_day_of_week (ISO Monday-start) uses ISO convention", {
  old_data <- data.table::copy(obj$data) # deep copy
  on.exit(
    {
      obj$data <- old_data
    },
    add = TRUE
  )

  dc <- obj$date_column
  n <- nrow(obj$data)

  # Sat, Sun, Mon pattern → ISO DOW should be 6, 7, 1 (repeating)
  pattern_dates <- as.Date(c("2025-01-04", "2025-01-05", "2025-01-06"))
  pattern_dow <- c(6L, 7L, 1L)
  obj$data[[dc]] <- .repeat_dates_to_n(pattern_dates, n)

  obj2 <- add_day_of_week(obj, column_name = "dow_iso", sunday_start = FALSE)

  expect_equal(nrow(obj2$data), n)
  expect_true("dow_iso" %in% names(obj2$data))
  expect_type(obj2$data$dow_iso, "integer")
  expect_equal(obj2$data$dow_iso, rep_len(pattern_dow, n))
})

test_that("add_day_of_year returns %j-style values, handles leap years", {
  old_data <- data.table::copy(obj$data) # deep copy
  on.exit(
    {
      obj$data <- old_data
    },
    add = TRUE
  )

  dc <- obj$date_column
  n <- nrow(obj$data)

  # Mix of leap-year anchors: 2024-01-01 (1), 2024-02-29 (60),
  # 2024-12-31 (366), 2023-12-31 (365)
  pattern_dates <- as.Date(c(
    "2024-01-01", "2024-02-29",
    "2024-12-31", "2023-12-31"
  ))
  expected_doy <- as.integer(strftime(pattern_dates, "%j"))

  obj$data[[dc]] <- .repeat_dates_to_n(pattern_dates, n)

  obj2 <- add_day_of_year(obj, column_name = "doy")

  expect_equal(nrow(obj2$data), n)
  expect_true("doy" %in% names(obj2$data))
  expect_type(obj2$data$doy, "integer")
  expect_equal(obj2$data$doy, rep_len(expected_doy, n))
})

test_that("sequential temporal helper calls accumulate other_ids", {
  test_df <- data.frame(
    region = c("A", "A", "B", "B"),
    date = as.Date(c("2025-01-01", "2025-01-02", "2025-01-01", "2025-01-02")),
    num = c(1, 2, 3, 4),
    den = c(10, 10, 20, 20)
  )

  dc <- data_class(
    data = test_df,
    region_column = "region",
    date_column = "date",
    numerator_column = "num",
    denominator_column = "den"
  )

  dc <- add_day_of_week(dc, column_name = "dow_id")
  dc <- add_mmwr_week(dc,
    column_name = "week_id",
    add_year = TRUE,
    year_col = "mmwr_year"
  )
  dc <- add_day_of_year(dc, column_name = "doy_id")

  expect_true(all(
    c("dow_id", "week_id", "mmwr_year", "doy_id") %in% dc$other_ids
  ))
  expect_true(isTRUE(attr(dc, "has_dow_ids")))
  expect_true(isTRUE(attr(dc, "has_week_ids")))
  expect_true(isTRUE(attr(dc, "has_year_ids")))
  expect_true(isTRUE(attr(dc, "has_doy_ids")))
})

test_that("prepare_raw_data can preserve prior other_ids metadata", {
  test_df <- data.frame(
    region = c("A", "A", "B", "B"),
    date = as.Date(c("2025-01-01", "2025-01-02", "2025-01-01", "2025-01-02")),
    numerator = c(1, 2, 3, 4),
    denominator = c(10, 10, 20, 20)
  )

  dc <- prepare_raw_data(test_df)
  expect_equal(dc$other_ids, character(0))

  dc <- add_day_of_week(dc, column_name = "dow_id")
  expect_true("dow_id" %in% dc$other_ids)

  rebuilt_default <- prepare_raw_data(test_df)
  expect_equal(rebuilt_default$other_ids, character(0))

  rebuilt_preserved <- prepare_raw_data(
    test_df,
    existing_other_ids = dc$other_ids
  )
  expect_true("dow_id" %in% rebuilt_preserved$other_ids)
})

test_that("helper calls mutate input object in place by default", {
  test_df <- data.frame(
    region = c("A", "B"),
    date = as.Date(c("2025-01-01", "2025-01-02")),
    num = c(1, 2),
    den = c(10, 20)
  )

  dc <- data_class(
    data = test_df,
    region_column = "region",
    date_column = "date",
    numerator_column = "num",
    denominator_column = "den"
  )

  out <- add_day_of_week(dc, column_name = "dow_id")

  # Returned object contains the new column + metadata
  expect_true("dow_id" %in% names(out$data))
  expect_true("dow_id" %in% out$other_ids)

  # Original object is also updated in place by default.
  expect_true("dow_id" %in% names(dc$data))
  expect_true("dow_id" %in% dc$other_ids)
})

test_that("in_place = FALSE avoids mutating the input object", {
  test_df <- data.frame(
    region = c("A", "B"),
    date = as.Date(c("2025-01-01", "2025-01-02")),
    num = c(1, 2),
    den = c(10, 20)
  )

  dc <- data_class(
    data = test_df,
    region_column = "region",
    date_column = "date",
    numerator_column = "num",
    denominator_column = "den"
  )

  out <- add_day_of_week(dc, column_name = "dow_id", in_place = FALSE)

  expect_true("dow_id" %in% names(out$data))
  expect_true("dow_id" %in% out$other_ids)
  expect_false("dow_id" %in% names(dc$data))
  expect_equal(dc$other_ids, character(0))
})

# Add near existing helper tests in tests/testthat/test-data_class.R

test_that("in-place default updates object for all add helpers", {
  df <- data.frame(
    region = c("A", "B", "A", "B"),
    date = as.Date(c("2025-01-01", "2025-01-01", "2025-01-02", "2025-01-02")),
    num = c(1, 2, 3, 4),
    den = c(10, 20, 10, 20)
  )

  dc <- data_class(
    data = df,
    region_column = "region",
    date_column = "date",
    numerator_column = "num",
    denominator_column = "den"
  )

  add_day_of_year(dc, column_name = "doy_id")
  expect_true("doy_id" %in% names(dc$data))
  expect_true("doy_id" %in% dc$other_ids)

  add_mmwr_week(dc,
    column_name = "week_id",
    add_year = TRUE,
    year_col = "mmwr_year"
  )
  expect_true(all(c("week_id", "mmwr_year") %in% names(dc$data)))
  expect_true(all(c("week_id", "mmwr_year") %in% dc$other_ids))

  add_date_and_region_ids(dc, num_duplicates = 2)
  expect_true(
    all(
      c("date_id_1", "region_id_1", "date_id_2", "region_id_2") %in%
        names(dc$data)
    )
  )
  expect_equal(length(dc$date_identifiers), 2)
  expect_equal(length(dc$region_identifiers), 2)
})

test_that("in_place = FALSE leaves original unchanged for all add helpers", {
  df <- data.frame(
    region = c("A", "B"),
    date = as.Date(c("2025-01-01", "2025-01-02")),
    num = c(1, 2),
    den = c(10, 20)
  )

  dc <- data_class(
    data = df,
    region_column = "region",
    date_column = "date",
    numerator_column = "num",
    denominator_column = "den"
  )

  out1 <- add_day_of_year(dc, column_name = "doy_id", in_place = FALSE)
  expect_true("doy_id" %in% names(out1$data))
  expect_false("doy_id" %in% names(dc$data))
  expect_false("doy_id" %in% dc$other_ids)

  out2 <- add_mmwr_week(dc, column_name = "week_id", in_place = FALSE)
  expect_true("week_id" %in% names(out2$data))
  expect_false("week_id" %in% names(dc$data))
  expect_false("week_id" %in% dc$other_ids)

  out3 <- add_date_and_region_ids(dc, num_duplicates = 2, in_place = FALSE)
  expect_true(all(c("date_id_2", "region_id_2") %in% names(out3$data)))
  expect_false(any(c("date_id_2", "region_id_2") %in% names(dc$data)))
})

test_that("duplicate helper column call errors, does not duplicate other_ids", {
  df <- data.frame(
    region = c("A", "B"),
    date = as.Date(c("2025-01-01", "2025-01-02")),
    num = c(1, 2),
    den = c(10, 20)
  )

  dc <- data_class(
    data = df,
    region_column = "region",
    date_column = "date",
    numerator_column = "num",
    denominator_column = "den"
  )

  add_day_of_week(dc, column_name = "dow_id")
  before <- dc$other_ids
  expect_error(add_day_of_week(dc, column_name = "dow_id"))
  expect_equal(dc$other_ids, before)
  expect_equal(sum(dc$other_ids == "dow_id"), 1)
})

test_that("add_mmwr_week(add_year=TRUE) adds both ids to other_ids in place", {
  df <- data.frame(
    region = c("A", "A", "B", "B"),
    date = as.Date(c("2024-12-29", "2025-01-05", "2024-12-29", "2025-01-05")),
    num = c(1, 2, 3, 4),
    den = c(10, 10, 20, 20)
  )

  dc <- data_class(
    data = df,
    region_column = "region",
    date_column = "date",
    numerator_column = "num",
    denominator_column = "den"
  )

  add_mmwr_week(dc, add_year = TRUE, year_col = "mmwr_year")
  expect_true(all(c("week_id", "mmwr_year") %in% dc$other_ids))
  expect_true(isTRUE(attr(dc, "has_week_ids")))
  expect_true(isTRUE(attr(dc, "has_year_ids")))
})

test_that("non-symbol call does not in-place assign to caller object", {
  df <- data.frame(
    region = c("A", "B"),
    date = as.Date(c("2025-01-01", "2025-01-02")),
    num = c(1, 2),
    den = c(10, 20)
  )

  dc <- data_class(
    data = df,
    region_column = "region",
    date_column = "date",
    numerator_column = "num",
    denominator_column = "den"
  )

  out <- add_day_of_week(copy_data_class(dc), column_name = "dow_id")
  expect_true("dow_id" %in% names(out$data))
  expect_false("dow_id" %in% names(dc$data))
})

test_that("print.data_class reports other identifiers when present", {
  df <- data.frame(
    region = c("A", "B"),
    date = as.Date(c("2025-01-01", "2025-01-02")),
    num = c(1, 2),
    den = c(10, 20)
  )

  dc <- data_class(
    data = df,
    region_column = "region",
    date_column = "date",
    numerator_column = "num",
    denominator_column = "den"
  )
  add_day_of_week(dc, column_name = "dow_id")

  expect_output(print(dc), "Other Identifiers:")
  expect_output(print(dc), "dow_id")
})
