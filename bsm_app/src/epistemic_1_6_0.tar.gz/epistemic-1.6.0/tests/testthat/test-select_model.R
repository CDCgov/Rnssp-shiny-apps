# © 2025 The Johns Hopkins University Applied Physics Laboratory LLC
# Development of this software was sponsored by the U.S. Government under
# contract no. 75D30124C19958
# As of September 30, 2025 this code is pending review by OTT and should be
# considered JHU Propriety and only for internal JHU/APL use.

# make data for evaluation
n <- 3
dt <- make_dummy_seasonal_data(
  n_regions = n,
  n_days = 7 * 3,
  lambda_den = 40,
  seed = 42
)
adj <- matrix(0, n, n) # start with zeros
adj[row(adj) == col(adj) + 1] <- 1 # below diagonal
adj[row(adj) == col(adj) - 1] <- 1 # above diagonal
dt[, day_of_week := as.numeric(date - min(date)) + 1]
dt[, mask1 := ifelse((region == "R01") & (date >= as.Date("2024-01-21")), 1, 0)]
dt[, mask2 := ifelse((region == "R02") & (date >= as.Date("2024-01-21")), 1, 0)]

rownames(adj) <- unique(dt$region)
colnames(adj) <- unique(dt$region)

data_cls <- data_class(
  data = dt,
  region_column = "region",
  date_column = "date",
  numerator_column = "num",
  denominator_column = "den",
  generate_expected = TRUE
)
family <- "binomial"
data_cls <- add_missing_and_future_dates(1, data_cls, den_fill_val = 1)


terms_spec <- list(
  'f(r_id,model="iid")',
  c('f(r_id,model="besagproper",graph=adjacency_matrix)', "")
)
desc <- ("select_model_criterion runs and returns valid scores;
         forward & backward agree")
test_that(desc, {
  expect_no_error({
    res_fwd <- select_model_criterion(
      data_cls,
      family = family,
      terms_spec = terms_spec,
      direction = "forward",
      criterion = "waic",
      reformulate = TRUE,
      adjacency_matrix = adj,
      passes = 2,
      verbose = FALSE
    )
  })

  tbl <- res_fwd$results_table
  expect_true(is.data.frame(tbl))
  expect_gt(nrow(tbl), 0)
  expect_true(all(!is.na(tbl$waic)))
  expect_true(all(!is.na(tbl$dic)))


  expect_no_error({
    res_bwd <- select_model_criterion(
      data_cls,
      family = family,
      terms_spec = terms_spec,
      direction = "backward",
      criterion = "dic",
      reformulate = TRUE,
      adjacency_matrix = adj,
      passes = 2,
      verbose = FALSE
    )
  })

  tbl <- res_bwd$results_table
  expect_true(is.data.frame(tbl))
  expect_gt(nrow(tbl), 0)
  expect_true(all(!is.na(tbl$waic)))
  expect_true(all(!is.na(tbl$dic)))

  expect_identical(res_fwd$best_formula, "num ~ 1 + f(r_id,model=\"iid\")")
})


terms_spec <- list(
  'f(r_id,model="iid")',
  'f(d_id,model="iid")'
)

desc2 <- ("select_model_estimation runs and returns valid scores;
          forward & backward agree")
test_that(desc2, {
  expect_no_error({
    res_fwd <- select_model_estimation(
      data_cls,
      family = family,
      terms_spec = terms_spec,
      mask_columns = c("mask1", "mask2"),
      direction = "forward",
      metric = "mae",
      reformulate = TRUE,
      adjacency_matrix = adj,
      use_count_scale = FALSE,
      passes = 1,
      verbose = FALSE
    )
  })

  tbl <- res_fwd$results_table
  expect_true(is.data.frame(tbl))
  expect_gt(nrow(tbl), 0)
  expect_true(all(!is.na(tbl$waic)))
  expect_true(all(!is.na(tbl$dic)))

  expect_identical(res_fwd$best_formula, "num ~ 1 + f(r_id,model=\"iid\")")
})
