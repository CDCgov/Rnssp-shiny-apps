# © 2025 The Johns Hopkins University Applied Physics Laboratory LLC
# Development of this software was sponsored by the U.S. Government under
# contract no. 75D30124C19958
# As of September 30, 2025 this code is pending review by OTT and should be
# considered JHU Propriety and only for internal JHU/APL use.

test_that("no error when all required cols are present", {
  df <- data.frame(a = 1:3, b = letters[1:3])
  # should run silently and return NULL invisibly
  expect_silent({
    out <- check_names(df, c("a", "b"))
    expect_true(out)
  })
})

test_that("errors when a required name is missing", {
  df <- data.frame(a = 1:3, b = letters[1:3])
  # missing "c" should trigger abort with correct message
  expect_error(
    check_names(df, c("a", "c")),
    class = "name_not_found"
  )
})

test_that("errors on first missing when multiple are absent", {
  df <- data.frame(x = 1:5)
  # should complain about "a" first, even though "b" is also missing
  expect_error(
    check_names(df, c("a", "b")),
    class = "name_not_found"
  )
})

test_that("true if names is empty", {
  df <- data.frame(a = 1:3)
  expect_true(check_names(df, character(0)))
})

test_that("get_scale_factors throws an error for invalid family", {
  data("demo_model_result")
  data("demo_data")

  # Modify the model to have an unsupported family
  bad_model <- demo_model_result
  bad_model$.args$family <- "unsupported_family"

  expect_error(
    get_scale_factors(demo_data, bad_model),
    class = "invalid_argument"
  )
})

# tests for infer_freq
test_that("uniform daily sequence returns 1 day", {
  dates <- as.Date("2025-01-01") + 0:4
  freq <- infer_freq(dates)
  expect_equal(as.numeric(freq), 1) # one day
})

test_that("uniform weekly sequence returns 7 days", {
  dates <- as.Date("2025-01-01") + seq(0, 28, by = 7)
  freq <- infer_freq(dates)
  expect_equal(as.numeric(freq), 7)
})

test_that("unordered input still infers correctly", {
  dates_unsorted <- as.Date(c("2025-01-08", "2025-01-01", "2025-01-15"))
  freq <- infer_freq(dates_unsorted)
  expect_equal(as.numeric(freq), 7)
})

test_that("single date returns zero-length diff (error)", {
  single_date <- as.Date("2025-01-01")
  expect_error(
    infer_freq(single_date),
    "multiple date gaps detected"
  )
})

test_that("multiple distinct gaps triggers error", {
  mixed_dates <- as.Date(c("2025-01-01", "2025-01-02", "2025-01-05"))
  expect_error(
    infer_freq(mixed_dates),
    "Cannot infer frequency, multiple date gaps detected"
  )
})

test_that("dates given as character are coerced and handled", {
  dates_char <- c("2025-02-01", "2025-02-08", "2025-02-15")
  expect_error(
    infer_freq(dates_char),
    "x must be vector class 'Date'"
  )
})

test_that(
  ("remove_invalid_estimates handles all scale-family combinations correctly"
  ),
  {
    # Base data
    base_data <- data.table::data.table(
      region = c("A", "A", "B"),
      mean = c(1.1, 2.2, 3.3),
      sd = c(0.1, 0.2, 0.3)
    )

    base_data_class <- list(
      data = data.table::data.table(
        region = c("A", "A", "B"),
        denominator_source = c(0, 1, 1)
      )
    )

    # Helper: run and return modified copy
    run_case <- function(family, use_count_scale) {
      dt <- data.table::copy(base_data)
      model <- list(.args = list(family = family))

      remove_invalid_estimates(
        data = dt,
        value_columns = c("mean", "sd"),
        inla_model = model,
        use_count_scale = use_count_scale,
        data_class = base_data_class
      )
      (dt[])
    }

    # Case: use_count_scale = TRUE, family = "poisson" → valid, no NA
    dt1 <- run_case("poisson", TRUE)
    expect_false(any(is.na(dt1$mean)))
    expect_false(any(is.na(dt1$sd)))

    # Case: use_count_scale = TRUE, family = "binomial" → invalid, NA on rows
    # 2,3
    dt2 <- run_case("binomial", TRUE)
    expect_true(all(is.na(dt2$mean[2:3])))
    expect_equal(dt2$mean[1], 1.1)

    # Case: use_count_scale = FALSE, family = "binomial" → valid, no NA
    dt3 <- run_case("binomial", FALSE)
    expect_false(any(is.na(dt3$mean)))
    expect_false(any(is.na(dt3$sd)))

    # Case: use_count_scale = FALSE, family = "poisson" → invalid, NA on rows
    # 2,3
    dt4 <- run_case("poisson", FALSE)
    expect_true(all(is.na(dt4$sd[2:3])))
    expect_equal(dt4$sd[1], 0.1)
  }
)


test_that(
  ("remove_invalid_estimates handles filtered data"
  ),
  {
    data("demo_model_result")
    dc <- demo_model_result$data
    dc$data[, denominator_source := ifelse(region == "X0002", 1, 0)]
    dc$data[, dummy := target / overall]
    inla_model <- demo_model_result$inla_model
    regions <- c("X0001", "X0002")
    dates <- as.Date(c("2024-01-01", "2024-01-08", "2024-01-15", "2024-01-22"))
    inds <- get_subset_indices.data_class(demo_data,
      regions = regions,
      dates = dates
    )
    dt <- dc$data[inds, ]
    # Helper: run and return modified copy
    run_case <- function(family, use_count_scale) {
      model <- list(.args = list(family = family))

      remove_invalid_estimates(
        data = dt,
        value_columns = c("dummy"),
        inla_model = model,
        use_count_scale = use_count_scale,
        data_class = dc
      )
      (dt[])
    }

    # Case: use_count_scale = TRUE, family = "poisson" → valid, no NA
    dt1 <- run_case("poisson", TRUE)
    expect_false(all(is.na(dt1$dummy)))
    dt4 <- run_case("poisson", FALSE)
    expect_true(all(is.na(dt1$dummy[dt1$denominator_source > 0])))
    expect_equal(nrow(dt1), nrow(dt))
  }
)

test_that("get_mmwr_week_year handles cross-year Week 1 per CDC MMWR", {
  dates <- as.Date(c(
    "2024-12-28", # Sat before MMWR Week 1 (still 2024 MMWR year)
    "2024-12-29", # Sun -> first day of MMWR Week 1 (2025)
    "2024-12-31", # Tue -> still MMWR Week 1 (2025)
    "2025-01-01", # Wed -> still MMWR Week 1 (2025)
    "2025-01-04", # Sat -> last day of MMWR Week 1 (2025)
    "2025-01-05" # Sun -> MMWR Week 2 (2025)
  ))

  out <- get_mmwr_week_year(dates)

  # Check known anchors around the boundary
  # 2024-12-29 .. 2025-01-04 are MMWR year 2025
  expect_equal(out$mmwr_year[2:5], rep(2025L, 4))
  expect_equal(out$mmwr_week[2:5], rep(1L, 4)) # ... all in MMWR Week 1
  expect_equal(out$mmwr_year[6], 2025L) # 2025-01-05 in MMWR year 2025
  expect_equal(out$mmwr_week[6], 2L) # ... Week 2

  # Sanity check: the day before 2024-12-29 is still 2024's MMWR year
  expect_equal(out$mmwr_year[1], 2024L)
  expect_true(out$mmwr_week[1] >= 1L && out$mmwr_week[1] <= 53L)
})

test_that("get_mmwr_week_year is vectorized, returns integers", {
  dates <- as.Date(c(
    "2025-01-03", # Fri (MMWR W1)
    "2025-01-04", # Sat (MMWR W1)
    "2025-01-05", # Sun (MMWR W2)
    "2025-01-06" # Mon (MMWR W2)
  ))

  out <- get_mmwr_week_year(dates)

  # Vectorization and lengths
  expect_equal(nrow(out), length(dates))

  # Types and ranges
  expect_type(out$mmwr_year, "integer")
  expect_type(out$mmwr_week, "integer")
  expect_true(all(out$mmwr_week >= 1L & out$mmwr_week <= 53L))

  # Same week Fri->Sat, increment on Sunday
  expect_equal(out$mmwr_year[1], 2025L)
  expect_equal(out$mmwr_year[2], 2025L)
  expect_equal(out$mmwr_week[1], out$mmwr_week[2]) # Fri and Sat in same week
  expect_equal(out$mmwr_week[3], out$mmwr_week[2] + 1L) # Sunday starts week
  expect_equal(out$mmwr_week[3], out$mmwr_week[4]) # Sun and Mon in same week
})
