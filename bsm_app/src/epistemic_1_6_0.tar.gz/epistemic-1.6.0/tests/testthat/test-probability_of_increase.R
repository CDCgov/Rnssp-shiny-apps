# © 2025 The Johns Hopkins University Applied Physics Laboratory LLC
# Development of this software was sponsored by the U.S. Government under
# contract no. 75D30124C19958
# As of September 30, 2025 this code is pending review by OTT and should be
# considered JHU Propriety and only for internal JHU/APL use.

test_that(
  "get_probability_of_increase returns expected columns and values",
  {
    data("demo_model_result")
    data("demo_data")

    inla_model <- demo_model_result$inla_model
    data_cls <- demo_data

    result <- get_probability_of_increase(
      inla_model = inla_model,
      data_cls = data_cls,
      threshold = 0.002,
      dt = 7,
      npts = 1000,
      scale_mode = "absolute_prop",
      use_suffix = FALSE,
      use_normal_approx = FALSE
    )

    expect_true(data_cls$region_column %in% names(result))
    expect_true(data_cls$date_column %in% names(result))
    expect_true("change_prob" %in% names(result))

    # check row count
    expect_equal(nrow(result), nrow(data_cls$data))

    # check last values
    last_vals <- result[result$date == max(result$date), change_prob]

    expected_last_vals <- c(
      0.244362, 0.137056, 0.297067, 0.326095,
      0.539393, 0.352700, 0.245412, 0.685522
    )
    expect_equal(last_vals, expected_last_vals, tolerance = 1e-5)
  }
)

test_that(
  "get_probability_of_increase matches normal approximation within tolerance",
  {
    data("demo_model_result")
    data("demo_data")

    inla_model <- demo_model_result$inla_model
    data_cls <- demo_data

    result_num <- get_probability_of_increase(
      inla_model = inla_model,
      data_cls = data_cls,
      threshold = 0.002,
      dt = 7,
      npts = 1000,
      use_normal_approx = FALSE
    )
    result_norm <- get_probability_of_increase(
      inla_model = inla_model,
      data_cls = data_cls,
      threshold = 0.002,
      dt = 7,
      npts = 1000,
      use_normal_approx = TRUE
    )
    merged <- merge(
      result_num,
      result_norm,
      by = c(data_cls$region_column, data_cls$date_column),
      suffixes = c("_num", "_norm")
    )

    expect_true(
      all(
        abs(merged$change_prob_num - merged$change_prob_norm) < 0.01,
        na.rm = TRUE
      )
    )
  }
)

test_that(
  "get_probability_of_increase has NA values for earliest dates when dt = 7",
  {
    data("demo_model_result")
    data("demo_data")

    inla_model <- demo_model_result$inla_model
    data_cls <- demo_data

    result <- get_probability_of_increase(
      inla_model = inla_model,
      data_cls = data_cls,
      threshold = 0.002,
      dt = 7,
      npts = 1000,
      use_normal_approx = FALSE
    )

    date_col <- data_cls$date_column
    min_date <- min(data_cls$data[[date_col]])

    # We expect any rows where target_date == min_date to have NA change_prob
    expect_true(any(result[[date_col]] == min_date & is.na(result$change_prob)))
  }
)

test_that("different scale modes produce different change probabilities", {
  data("demo_model_result")
  data("demo_data")

  inla_model <- demo_model_result$inla_model
  data_cls <- demo_data

  res_prop <- get_probability_of_increase(
    inla_model, data_cls,
    threshold = 0.002,
    dt = 7,
    scale_mode = "absolute_prop",
    use_normal_approx = FALSE
  )

  res_count <- get_probability_of_increase(
    inla_model, data_cls,
    threshold = 0.002,
    dt = 7,
    scale_mode = "absolute_count",
    use_normal_approx = FALSE
  )

  expect_false(isTRUE(all.equal(res_prop$change_prob, res_count$change_prob)))
})

test_that("relative mode matches normal approximation within tolerance", {
  data("demo_model_result")
  data("demo_data")

  inla_model <- demo_model_result$inla_model
  data_cls <- demo_data

  result_num <- get_probability_of_increase(
    inla_model = inla_model,
    data_cls = data_cls,
    threshold = 0.1,
    dt = 7,
    scale_mode = "relative",
    npts = 1000,
    use_normal_approx = FALSE
  )

  result_norm <- get_probability_of_increase(
    inla_model = inla_model,
    data_cls = data_cls,
    threshold = 0.1,
    dt = 7,
    scale_mode = "relative",
    use_normal_approx = TRUE
  )

  merged <- merge(
    result_num, result_norm,
    by = c(data_cls$region_column, data_cls$date_column),
    suffixes = c("_num", "_norm")
  )

  expect_true(all(
    abs(merged$change_prob_num - merged$change_prob_norm) < 0.01,
    na.rm = TRUE
  ))
})

test_that("absolute_count and absolute_prop give consistent results", {
  # create dummy data with fixed denominator
  regions <- c("region_1", "region_2")
  dates <- seq.Date(from = as.Date("2025-01-01"), by = "day", length.out = 30)

  # Create the base data.table with all region-date combinations
  dt <- data.table::CJ(region = regions, date = dates)

  # Add columns
  set.seed(2)
  dt[, denominator := 20]
  dt[
    region == "region_1",
    numerator := rbinom(.N, size = denominator, prob = 0.25)
  ]

  dt[
    region == "region_2",
    numerator := rbinom(.N, size = denominator, prob = 0.5)
  ]

  dc <- epistemic::data_class(
    data = dt,
    region_column = "region",
    date_column = "date",
    numerator_column = "numerator",
    denominator_column = "denominator",
    generate_expected = TRUE
  )

  formula <- target ~ 1 +
    f(r_id,
      model = "iid"
    ) +
    f(d_id,
      model = "rw1"
    )
  for (family in c("poisson", "binomial")) {
    result <- epistemic::fit_model(dc,
      formula,
      family = family,
      reformulate = TRUE
    )
    inla_model_fitted <- result$inla_model
    data_class_fitted <- result$data
    adjacency_matrix_fitted <- result$adj_matrix

    pinc_count <- epistemic::get_probability_of_increase(
      inla_model_fitted,
      data_class_fitted,
      threshold = 1,
      dt = 1,
      use_suffix = FALSE,
      scale_mode = "absolute_count"
    )
    pinc_prop <- epistemic::get_probability_of_increase(
      inla_model_fitted,
      data_class_fitted,
      threshold = .05,
      dt = 1,
      use_suffix = FALSE,
      scale_mode = "absolute_prop"
    )
    expect_true(all(
      abs(pinc_count$change_prob - pinc_prop$change_prob) < 0.0001,
      na.rm = TRUE
    ))
  }
})

test_that("get_probability_of_increase: filters correctly", {
  dates <- as.Date(c("2024-01-01", "2024-01-08"))
  regions <- c("X0001", "X0003")
  data("demo_model_result")
  data("demo_data")

  inla_model <- demo_model_result$inla_model
  data_cls <- demo_data
  result <- get_posterior_medians(
    inla_model = inla_model,
    data_cls = data_cls,
    dates = dates,
    regions = regions
  )
  res_regions <- result[[data_cls$region_column]]
  res_dates <- result[[data_cls$date_column]]

  expect_true(all(res_regions %in% regions))
  expect_true(all(res_dates %in% dates))
  expect_true(all(regions %in% res_regions))
  expect_true(all(dates %in% res_dates))
})
