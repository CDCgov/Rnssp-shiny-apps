# © 2025 The Johns Hopkins University Applied Physics Laboratory LLC
# Development of this software was sponsored by the U.S. Government under
# contract no. 75D30124C19958
# As of September 30, 2025 this code is pending review by OTT and should be
# considered JHU Propriety and only for internal JHU/APL use.

data("demo_model_result")
data("demo_data")

data_cls <- demo_data
formula <- target ~ 1 + f(d_id, model = "rw1") + f(r_id, model = "iid")
inla_model_binomial <- demo_model_result$inla_model
inla_model_poisson <- fit_model(demo_data,
  reformulate = TRUE,
  formula = formula,
  family = "poisson"
)$inla_model

threshold <- 0.01
result <- get_exceedance_probs(inla_model_binomial,
  data_cls,
  threshold,
  use_suffix = FALSE,
  use_count_scale = FALSE
)
test_that(
  "get_exceedance_probs returns a data.table with expected structure.",
  {
    expect_s3_class(result, "data.table")
    expect_true(nrow(result) == nrow(data_cls$data))
    expect_true("exceedance_prob" %in% names(result))
    expect_true(data_cls$region_column %in% names(result))
    expect_true(data_cls$date_column %in% names(result))
  }
)

test_that("exceedance probabilities are between 0 and 1", {
  expect_true(all(result$exceedance_probs >= 0))
  expect_true(all(result$exceedance_probs <= 1))
})
test_that("exceedance probabilities are have not changed significantly", {
  last_vals <- result[1:10, exceedance_prob]

  expected_last_vals <- c(
    0.33377, 0.07403, 0.83002, 0.66388, 1.00000, 0.91213,
    0.79900, 1.00000, 0.68035, 0.36582
  )
  expect_equal(last_vals, expected_last_vals, tolerance = 1e-5)
})

test_that(
  "get_exceedance_probs runs without error for different INLA families",
  {
    families <- c("poisson", "nbinomial", "binomial", "betabinomial")

    for (fam in families) {
      modified_model <- inla_model_binomial
      modified_model$.args$family <- fam

      expect_silent({
        result <- get_exceedance_probs(modified_model, demo_data, 0.05)
      })
    }
  }
)

test_that(
  (
    "binomial threshold is converted from count to proportion
    when use_count_scale = TRUE"
  ),
  {
    threshold_count <- 3
    threshold_prop <- 0.3

    # Assumes denominator is 10
    data_cls$data$denominator <- rep(10, nrow(data_cls$data))
    data_cls$denominator_column <- "denominator"

    res_count_scale <- get_exceedance_probs(
      inla_model_binomial, data_cls,
      threshold = threshold_count,
      use_count_scale = TRUE, use_suffix = FALSE
    )
    res_prop_scale <- get_exceedance_probs(
      inla_model_binomial, data_cls,
      threshold = threshold_prop,
      use_count_scale = FALSE, use_suffix = FALSE
    )

    expect_equal(res_count_scale$exceedance_prob,
      res_prop_scale$exceedance_prob,
      tolerance = 1e-6
    )
  }
)

test_that(
  (
    "poisson threshold is converted from proportion to count
    when use_count_scale = FALSE"
  ),
  {
    threshold_prop <- 0.3
    threshold_count <- 3

    data_cls$data$denominator <- rep(10, nrow(data_cls$data))
    data_cls$denominator_column <- "denominator"

    res_count_scale <- get_exceedance_probs(
      inla_model_poisson, data_cls,
      threshold = threshold_count,
      use_count_scale = TRUE, use_suffix = FALSE
    )
    res_prop_scale <- get_exceedance_probs(
      inla_model_poisson, data_cls,
      threshold = threshold_prop,
      use_count_scale = FALSE, use_suffix = FALSE
    )

    expect_equal(res_count_scale$exceedance_prob,
      res_prop_scale$exceedance_prob,
      tolerance = 1e-6
    )
  }
)


test_that("use_suffix = TRUE adds _count or _prop suffix as expected", {
  data_cls$data$denominator <- rep(10, nrow(data_cls$data))
  data_cls$denominator_column <- "denominator"

  result_bin <- get_exceedance_probs(inla_model_binomial, data_cls,
    threshold = 0.2,
    use_count_scale = FALSE, use_suffix = TRUE
  )
  result_pois <- get_exceedance_probs(inla_model_poisson, data_cls,
    threshold = 3,
    use_count_scale = TRUE, use_suffix = TRUE
  )
  expect_true("exceedance_prob_props" %in% names(result_bin))
  expect_true("exceedance_prob_counts" %in% names(result_pois))
})


test_that(
  "use_count_scale =TRUE and FALSE give consistent results",
  {
    # create dummy data with fixed denominator
    regions <- c("region_1", "region_2")
    dates <- seq.Date(from = as.Date("2025-01-01"), by = "day", length.out = 30)

    # Create the base data.table with all region-date combinations
    dt <- data.table::CJ(region = regions, date = dates)

    # Add columns
    set.seed(2)
    dt[, denominator := 20]
    dt[
      region == "region_1",
      numerator := rbinom(.N, size = denominator, prob = 0.25)
    ]

    dt[
      region == "region_2",
      numerator := rbinom(.N, size = denominator, prob = 0.5)
    ]

    dc <- epistemic::data_class(
      data = dt,
      region_column = "region",
      date_column = "date",
      numerator_column = "numerator",
      denominator_column = "denominator",
      generate_expected = TRUE
    )

    formula <- target ~ 1 +
      f(r_id,
        model = "iid"
      ) +
      f(d_id,
        model = "rw1"
      )
    for (family in c("poisson", "binomial")) {
      result <- epistemic::fit_model(dc,
        formula,
        family = family,
        reformulate = TRUE
      )
      inla_model_fitted <- result$inla_model
      data_class_fitted <- result$data
      adjacency_matrix_fitted <- result$adj_matrix

      exceedance_prob_count <- epistemic::get_exceedance_probs(
        inla_model_fitted,
        data_class_fitted,
        threshold = 5,
        use_suffix = FALSE,
        use_count_scale = TRUE
      )
      exceedance_prob_prop <- epistemic::get_exceedance_probs(
        inla_model_fitted,
        data_class_fitted,
        threshold = 0.25,
        use_suffix = FALSE,
        use_count_scale = FALSE
      )
      expect_true(all(
        abs(
          exceedance_prob_count$exceedance_prob -
            exceedance_prob_prop$exceedance_prob
        ) < 0.0001,
        na.rm = TRUE
      ))
    }
  }
)

test_that("get_exceedance_probs: filters correctly", {
  dates <- as.Date(c("2024-01-01", "2024-01-08"))
  regions <- c("X0001", "X0003")
  result <- epistemic::get_exceedance_probs(
    inla_model = inla_model_binomial,
    data_cls = data_cls,
    threshold = 0.25,
    dates = dates,
    regions = regions
  )
  res_regions <- result[[data_cls$region_column]]
  res_dates <- result[[data_cls$date_column]]

  expect_true(all(res_regions %in% regions))
  expect_true(all(res_dates %in% dates))
  expect_true(all(regions %in% res_regions))
  expect_true(all(dates %in% res_dates))
})


test_that(
  "grouped exceedance: use_count_scale TRUE/FALSE are consistent",
  {
    regions <- c("region_1", "region_2")
    dates <- seq.Date(
      from = as.Date("2025-01-01"),
      by = "day",
      length.out = 30
    )

    dt <- data.table::CJ(region = regions, date = dates)

    set.seed(2)
    dt[, denominator := 20]

    dt[
      region == "region_1",
      numerator := rbinom(.N, size = denominator, prob = 0.25)
    ]
    dt[
      region == "region_2",
      numerator := rbinom(.N, size = denominator, prob = 0.5)
    ]

    dt[, region_group := "RG_ALL"]

    dc <- epistemic::data_class(
      data = dt,
      region_column = "region",
      date_column = "date",
      numerator_column = "numerator",
      denominator_column = "denominator",
      generate_expected = TRUE
    )

    formula <- target ~ 1 +
      f(r_id, model = "iid") +
      f(d_id, model = "rw1")

    for (family in c("poisson", "binomial")) {
      result <- epistemic::fit_model(
        dc,
        formula,
        family = family,
        reformulate = TRUE,
        allow_sampling = TRUE
      )

      inla_model_fitted <- result$inla_model
      data_class_fitted <- result$data

      ex_count <- get_exceedance_probs_group(
        inla_model = inla_model_fitted,
        data_cls = data_class_fitted,
        threshold = 15,
        use_suffix = FALSE,
        use_count_scale = TRUE,
        group_cols = c("region_group", "date"),
        n_samples = 10000L
      )

      ex_prop <- get_exceedance_probs_group(
        inla_model = inla_model_fitted,
        data_cls = data_class_fitted,
        threshold = 0.375,
        use_suffix = FALSE,
        use_count_scale = FALSE,
        group_cols = c("region_group", "date"),
        n_samples = 10000L
      )

      ex_count_dt <- data.table::as.data.table(ex_count)
      ex_prop_dt <- data.table::as.data.table(ex_prop)

      data.table::setnames(
        ex_count_dt,
        "exceedance_prob",
        "exceedance_prob_count"
      )
      data.table::setnames(
        ex_prop_dt,
        "exceedance_prob",
        "exceedance_prob_prop"
      )

      m <- merge(
        ex_count_dt,
        ex_prop_dt,
        by = c("region_group", "date")
      )
      expect_true(all(
        abs(
          m$exceedance_prob_count -
            m$exceedance_prob_prop
        ) < 2e-2,
        na.rm = TRUE
      ))
    }
  }
)
