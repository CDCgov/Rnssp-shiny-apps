# © 2025 The Johns Hopkins University Applied Physics Laboratory LLC
# Development of this software was sponsored by the U.S. Government under
# contract no. 75D30124C19958
# As of September 30, 2025 this code is pending review by OTT and should be
# considered JHU Propriety and only for internal JHU/APL use.

library(testthat)
suppressWarnings(library(data.table))

data("demo_data")
data("demo_adj_matrix")
dc <- demo_data
am <- demo_adj_matrix

test_that("errors when adj_matrix is not square or lacks dimnames", {
  data.table::setattr(dc, "has_region_ids", TRUE)
  dc$region_identifiers <- "region_id_1"
  # not square
  m1 <- matrix(1:6, nrow = 2)
  expect_error(
    neighbor_graph(dc, m1),
    class = "adjacency_matrix_invalid"
  )

  # square but no dimnames
  m2 <- matrix(0, 2, 2)
  expect_error(
    neighbor_graph(dc, m2),
    class = "adjacency_matrix_invalid"
  )
})

test_that("errors if dc is not a data_class", {
  m <- matrix(0, 2, 2, dimnames = list(c("A", "B"), c("A", "B")))
  expect_error(
    neighbor_graph(list(), m),
    class = "data_class_invalid"
  )
})

test_that("errors if region‐ids have not been added", {
  data.table::setattr(dc, "has_region_ids", FALSE)
  # no attribute or FALSE
  expect_error(
    neighbor_graph(dc, demo_adj_matrix),
    "Use epistemic::add_date_and_region_ids"
  )
})

test_that("errors if some regions are missing in the adjacency matrix", {
  # set the attribute back to true
  data.table::setattr(dc, "has_region_ids", TRUE)
  # drop a column/row in the matrix
  am_missing <- am[rownames(am) != "X0001", colnames(am) != "X0001"]

  expect_error(
    neighbor_graph(dc, am_missing),
    "do not appear in the adjacency matrix"
  )
})

test_that("returns a matrix object when inputs are valid", {
  # set the attribute back to true
  data.table::setattr(dc, "has_region_ids", TRUE)

  g <- neighbor_graph(dc, am)
  expect_true(is.matrix(g))
})
