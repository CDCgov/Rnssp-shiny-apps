# © 2025 The Johns Hopkins University Applied Physics Laboratory LLC
# Development of this software was sponsored by the U.S. Government under
# contract no. 75D30124C19958
# As of September 30, 2025 this code is pending review by OTT and should be
# considered JHU Propriety and only for internal JHU/APL use.

library(testthat)

test_that("valid binary adjacency matrix passes", {
  m <- matrix(c(0, 1, 1, 0), 2, 2,
    dimnames = list(c("r1", "r2"), c("r1", "r2"))
  )
  expect_true(validate_adjacency_matrix(m))
})

test_that("non-binary allowed when require_binary = FALSE", {
  m <- matrix(1:4, 2, 2,
    dimnames = list(c("x", "y"), c("x", "y"))
  )
  expect_true(validate_adjacency_matrix(m, require_binary = FALSE))
})

test_that("error on non-matrix input", {
  expect_error(validate_adjacency_matrix(list()), "must be a matrix")
})

test_that("error on non-square matrix", {
  m <- matrix(1:6, 2, 3)
  expect_error(validate_adjacency_matrix(m), "must be square")
})

test_that("error on missing dimnames", {
  m <- matrix(0, 2, 2)
  expect_error(validate_adjacency_matrix(m), "must have non-NULL row names")
})

test_that("error on mismatched dimnames", {
  m <- matrix(0, 2, 2, dimnames = list(c("a", "b"), c("x", "y")))
  expect_error(
    validate_adjacency_matrix(m),
    "Row names and column names of the adjacency matrix must be identical"
  )
})

test_that("error on non-binary values when required", {
  m <- matrix(c(0, 2, 1, 0), 2, 2,
    dimnames = list(c("u", "v"), c("u", "v"))
  )
  expect_error(
    validate_adjacency_matrix(m),
    "All adjacency matrix entries must be 0 or 1"
  )
})


# tests for add_covariates()
data("demo_data")
dc <- demo_data

test_that("errors if covariates is not a data.frame", {
  expect_error(
    add_covariates("not_a_df", dc),
    "`covariates` must be a data.frame, data.table, or tibble."
  )
})

test_that("errors if dc is not a data_class", {
  cov <- data.frame(region = "A", date = Sys.Date(), x = 1)
  expect_error(
    add_covariates(cov, list()),
    "Object must inherit from class 'data_class'"
  )
})

test_that("errors if specified region column missing", {
  cov <- data.frame(
    foo = dc$data$region,
    date = dc$data$date,
    x = seq_len(nrow(dc$data))
  )
  expect_error(
    add_covariates(cov, dc, region = "foo_not_exist"),
    class = "name_not_found"
  )
})

test_that("errors if specified date column missing", {
  cov <- data.frame(
    region = dc$data$region,
    bar = dc$data$date,
    x = seq_len(nrow(dc$data))
  )
  expect_error(
    add_covariates(cov, dc, date = "bar_not_exist"),
    class = "name_not_found"
  )
})

test_that("errors if neither date or region is provided", {
  cov <- data.frame(region = dc$data$region, date = dc$data$date, a = 1, b = 2)
  expect_error(
    add_covariates(cov, dc, features = c("a", "b")),
    "At least one of region and date must be provided"
  )
})


test_that("errors if features vector has missing columns", {
  cov <- data.frame(region = dc$data$region, date = dc$data$date, a = 1, b = 2)
  expect_error(
    add_covariates(
      cov,
      dc,
      region = "region",
      date = "date",
      features = c("a", "missing")
    ),
    class = "name_not_found"
  )
})

test_that("errors if attempting to add duplicate columns", {
  # demo_data already has 'expected' and date_id_1, region_id_1
  cov <- data.frame(
    region = dc$data$region,
    date = dc$data$date,
    expected = runif(nrow(dc$data)),
    extra = runif(nrow(dc$data))
  )
  expect_error(
    add_covariates(cov, dc, region = "region", date = "date"),
    "Cannot add columns (expected) that already exist in data_class",
    fixed = TRUE
  )
})

test_that("adds all covariates by default", {
  cov <- data.frame(
    region = dc$data$region,
    date   = dc$data$date,
    pop    = seq_len(nrow(dc$data)),
    temp   = rev(seq_len(nrow(dc$data)))
  )
  dc2 <- add_covariates(cov, dc, region = "region", date = "date")
  # new columns present
  expect_true(all(c("pop", "temp") %in% names(dc2$data)))
  # feature_columns updated
  expect_true(all(c("pop", "temp") %in% dc2$feature_columns))
  # values merged correctly for a sample row
  idx <- 5
  expect_equal(dc2$data$pop[idx], dc$data$target[idx] * 0 + cov$pop[idx])
  expect_equal(dc2$data$temp[idx], cov$temp[idx])
})

test_that("adds only specified features", {
  cov <- data.frame(
    region = dc$data$region,
    date = dc$data$date,
    a = seq_len(nrow(dc$data)),
    b = 101:(100 + nrow(dc$data))
  )
  dc3 <- add_covariates(
    cov,
    dc,
    region = "region",
    date = "date",
    features = "b"
  )
  expect_true("b" %in% names(dc3$data))
  expect_false("a" %in% names(dc3$data))
  expect_true("b" %in% dc3$feature_columns)
  expect_false("a" %in% dc3$feature_columns)
})

test_that("works with custom region and date column names", {
  # rename covariate columns
  cov2 <- data.frame(
    state = dc$data$region,
    day   = dc$data$date,
    z     = runif(nrow(dc$data))
  )
  dc4 <- add_covariates(
    cov2,
    dc,
    region = "state",
    date = "day",
    features = "z"
  )
  expect_true("z" %in% names(dc4$data))
  expect_equal(dc4$feature_columns[length(dc4$feature_columns)], "z")
})

test_that("errors if region column in covariates is not character", {
  cov_bad_region <- data.frame(
    region = factor(dc$data$region),
    date   = dc$data$date,
    x      = seq_len(nrow(dc$data))
  )
  expect_error(
    add_covariates(cov_bad_region, dc, region = "region", date = "date"),
    "region column in covariates must be of class character"
  )
})

test_that("errors if date column in covariates is not Date", {
  cov_bad_date <- data.frame(
    region = dc$data$region,
    date   = as.character(dc$data$date),
    x      = seq_len(nrow(dc$data))
  )
  expect_error(
    add_covariates(cov_bad_date, dc, region = "region", date = "date"),
    "Date column in covariates must be of class Date"
  )
})

test_that("errors if (region, date) does not form a primary key", {
  # duplicate rows for the same (region, date)
  cov_dup <- data.frame(
    region = c(dc$data$region[1], dc$data$region[1]),
    date   = c(dc$data$date[1], dc$data$date[1]),
    x      = c(10, 20)
  )
  expect_error(
    add_covariates(cov_dup, dc, region = "region", date = "date"),
    "Region and/or Date column do not form a primary key on covariates"
  )
})

test_that("errors if region alone does not form a primary key", {
  # use a region-only covariate with duplicates
  cov_dup_region <- data.frame(
    region = c("A", "A", "B"),
    x      = c(10, 20, 30)
  )
  expect_error(
    add_covariates(cov_dup_region, dc, region = "region"),
    "Region and/or Date column do not form a primary key on covariates"
  )
})
