# © 2025 The Johns Hopkins University Applied Physics Laboratory LLC
# Development of this software was sponsored by the U.S. Government under
# contract no. 75D30124C19958
# As of September 30, 2025 this code is pending review by OTT and should be
# considered JHU Propriety and only for internal JHU/APL use.

library(testthat)


# Generate sample data for tests
set.seed(123) # for reproducibility
# Define regions and dates
regions <- c("A", "B", "C", "D")
dates <- seq(as.Date("2024-01-01"), by = "week", length.out = 5)

# Create all combinations of region and date
dt <- data.table::CJ(region = regions, date = dates, unique = TRUE)

# Generate random denominators and binomial numerators
dt[, den := sample(50:100, .N, replace = TRUE)]
dt[, num := rbinom(.N, size = den, prob = 0.25)]
# Add expected value
dt[, total_num_by_date := sum(num), by = date]
dt[, total_den_by_region := sum(den), by = region]
dt[, share := total_den_by_region / sum(den)]
dt[, expected := share * total_num_by_date]
dt[, c("total_num_by_date", "total_den_by_region", "share") := NULL]
dt[, region_id := as.integer(factor(region))]
dt[, date_id := as.integer(factor(date))]

# Create data class
k <- data_class(
  data = dt,
  region_column = "region",
  date_column = "date",
  numerator_column = "num",
  denominator_column = "den",
  expected_column = "expected",
  feature_columns = c()
)

formulas <- c(
  num ~ 1 + f(date_id, model = "rw1"),
  num ~ 1 + f(region_id, model = "iid")
)
bad_formula <- num ~ 1 + f(missing_id, model = "iid")

families <- c("poisson", "binomial", "nbinomial", "betabinomial")


for (fam in families) {
  for (f in formulas) {
    test_that(paste(
      "fit_model works for family",
      fam,
      "and formula",
      deparse(f)
    ), {
      expect_silent({
        result <- fit_model(k, formula = f, family = fam)
      })
    })
  }
}


test_that("fit_model throws an error for invalid family", {
  expect_error(
    fit_model(k,
      formula = formulas[[1]],
      family = "invalid_family"
    ),
    class = "invalid_family",
  )
})


test_that("fit_model throws an error for invalid formula.", {
  expect_error(
    fit_model(k,
      formula = bad_formula,
      family = "binomial"
    ),
    class = "invalid_formula"
  )
})

required_attrs <- c(
  "summary.fixed",
  "summary.linear.predictor",
  "summary.fitted.values"
)

test_that("fit_model returns object with required attributes", {
  fit <- fit_model(
    k,
    formula = formulas[[1]],
    family = "binomial"
  )[["inla_model"]]

  actual_attrs <- attributes(fit)$names

  for (attr_name in required_attrs) {
    expect_true(attr_name %in% actual_attrs,
      info = paste("Missing attribute:", attr_name)
    )
  }
})

test_that("fit_model returns object with required non-null attributes", {
  fit <- fit_model(
    k,
    formula = formulas[[1]],
    family = "binomial"
  )[["inla_model"]]

  for (attr_name in required_attrs) {
    # Check attribute exists
    expect_true(!is.null(fit[[attr_name]]),
      info = paste("Missing or NULL attribute:", attr_name)
    )
  }
})

test_that("fit_model stores control.inla defaults", {
  res <- fit_model(k, formula = formulas[[1]], family = "binomial")

  expect_equal(res$control_inla$int.strategy, "eb")
  expect_equal(res$control_inla$strategy, "laplace")
  expect_equal(res$control_inla$diagonal, 0.0)
  expect_equal(res$control_inla$force.diagonal, FALSE)
})

test_that("fit_model accepts all allowed init_strategy values", {
  strategies <- c("auto", "ccd", "grid", "eb", "user", "user.std")

  for (s in strategies) {
    res <- expect_error(
      fit_model(
        k,
        formula = formulas[[1]], family = "binomial", init_strategy = s
      ),
      NA
    )
    expect_equal(res$control_inla$int.strategy, s)
  }
})

test_that("fit_model accepts all allowed posterior_marginal_strategy values", {
  strategies <- c(
    "auto", "laplace", "gaussian", "simplified.laplace", "adaptive"
  )

  for (s in strategies) {
    res <- expect_error(
      fit_model(k,
        formula = formulas[[1]], family = "binomial",
        posterior_marginal_strategy = s
      ),
      NA
    )
    expect_equal(res$control_inla$strategy, s)
  }
})


## tests for adjacency matrix in formula
test_that("adjacency matrix is stored in fit_model when included in formula", {
  am <- neighbor_graph(demo_data, demo_adj_matrix)
  am <- INLA::inla.read.graph(am)
  test_formula <- target ~ 1 + f(
    region_id_1,
    graph = am,
    model = "besagproper",
    group = date_id_1,
    control.group = list(model = "ar", order = 1)
  )

  m <- fit_model(demo_data, test_formula,
    family = "binomial"
  )
  expect_identical(am, m[["adjacency_matrix"]])

  amp <- neighbor_graph(demo_data, demo_adj_matrix)

  test_formula <- target ~ 1 + f(
    r_id,
    graph = any_name,
    model = "besagproper",
    group = d_id,
    control.group = list(model = "ar", order = 1)
  )

  m_reform <- fit_model(
    demo_data,
    test_formula,
    family = "binomial",
    reformulate = TRUE,
    adjacency_matrix = amp
  )
  expect_identical(m[["adjacency_matrix"]], m_reform[["adjacency_matrix"]])
})


# Tests for adding date and region from formula
data("demo_data")
# prepare a fresh data_class without any existing ID columns
dcl0 <- demo_data
# remove any pre‐existing ID columns
to_rm <- intersect(
  names(dcl0$data),
  c(dcl0$region_identifiers, dcl0$date_identifiers)
)
if (length(to_rm)) {
  dcl0$data[, (to_rm) := NULL]
}
dcl0$region_identifiers <- NULL
dcl0$date_identifiers <- NULL

test_that("errors if dcl is not a data_class", {
  expect_error(
    gen_ids_from_formula(list(), ~ r_id + d_id),
    class = "data_class_invalid"
  )
})

test_that("errors when no tokens present in formula", {
  expect_message(
    gen_ids_from_formula(dcl0, ~ x + y),
    "No instance of r_ids/d_ids to replace"
  )
})

test_that("adds one set of ID columns when one token present", {
  # only one 'r_id' → num_duplicates = 1
  dcl1 <- gen_ids_from_formula(dcl0, ~ r_id + foo)
  expect_s3_class(dcl1, "data_class")
  expect_true(all(c("date_id_1", "region_id_1") %in% names(dcl1$data)))
})

test_that("adds multiple sets of ID columns based on max count", {
  # two 'r_id' and one 'd_id' → num_duplicates = 2
  dcl2 <- gen_ids_from_formula(dcl0, ~ r_id + r_id + d_id)
  expect_true(
    all(
      c("date_id_1", "date_id_2", "region_id_1", "region_id_2") %in%
        names(dcl2$data)
    )
  )
  # each duplicate column pair should carry identical values
  expect_equal(dcl2$data$date_id_1, dcl2$data$date_id_2)
  expect_equal(dcl2$data$region_id_1, dcl2$data$region_id_2)
})

test_that("custom token names are respected", {
  # use tokens 'foo' and 'bar'
  fmla <- ~ foo + bar + foo + foo
  # foo appears 3×, bar appears 1× → num_duplicates = 3
  dcl3 <- gen_ids_from_formula(
    dcl0, fmla,
    r_id = "foo", d_id = "bar"
  )
  expect_true(
    all(
      paste0(c("date", "region"), "_id_", 1:3) %in%
        names(dcl3$data)
    )
  )
})


## test for updating abstract formula function
data("demo_data")
dcl <- demo_data

test_that("errors if dcl is not a data_class", {
  expect_error(
    update_formula_with_ids(~ r_id + d_id, list()),
    class = "data_class_invalid"
  )
})

test_that("errors when adjacency_matrix provided but not inla.graph", {
  expect_error(
    update_formula_with_ids(~ r_id + d_id, dcl, adjacency_matrix = matrix(1)),
    "adjacency matrix must be of class inla.graph"
  )
})

test_that("errors when formula contains graph but parameter NULL", {
  f <- ~ g(graph = adjacency_matrix) + r_id
  expect_error(
    update_formula_with_ids(f, dcl, r_id = ),
    class = "update_formula_failed"
  )
})

test_that("replaces tokens in formula correctly", {
  f <- ~ r_id + d_id
  res <- update_formula_with_ids(f, dcl)
  expect_s3_class(res, "formula")
  expect_equal(deparse(res), deparse(~ region_id_1 + date_id_1))
})

test_that("replaces multiple tokens in sequence", {
  dcl2 <- add_date_and_region_ids(dcl, num_duplicates = 2)
  f2 <- ~ r_id + r_id + d_id
  res2 <- update_formula_with_ids(f2, dcl2)
  expect_equal(
    deparse(res2),
    deparse(~ region_id_1 + region_id_2 + date_id_1)
  )
})

test_that("custom token names are respected with dummy graph", {
  dcl2 <- add_date_and_region_ids(dcl, num_duplicates = 3)
  f3 <- ~ foo + foo + bar
  dummy <- structure(list(), class = "inla.graph")
  res3 <- update_formula_with_ids(
    f3, dcl2,
    r_id = "foo", d_id = "bar", adjacency_matrix = dummy
  )
  expect_equal(
    deparse(res3),
    deparse(~ region_id_1 + region_id_2 + date_id_1)
  )
})
