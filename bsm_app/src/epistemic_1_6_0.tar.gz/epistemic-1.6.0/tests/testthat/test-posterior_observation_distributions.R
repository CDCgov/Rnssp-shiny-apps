# © 2025 The Johns Hopkins University Applied Physics Laboratory LLC
# Development of this software was sponsored by the U.S. Government under
# contract no. 75D30124C19958
# As of September 30, 2025 this code is pending review by OTT and should be
# considered JHU Propriety and only for internal JHU/APL use.

data <- gen_synthetic_data("poisson", seed = 123)

for (family in c("poisson", "binomial", "nbinomial", "betabinomial")) {
  test_that(paste0("Posterior sampling generates results for ", family), {
    res <- fit_quick(data$dc, data$formula, family = family)
    inla_model <- res$inla_model
    data_cls <- res$data
    region_col <- data_cls$region_column
    date_col <- data_cls$date_column
    # sample column names you expect
    sample_cols <- paste0("sample_", 1:5)
    expected_cols <- c(region_col, date_col, sample_cols)


    # samples
    samp <- get_posterior_samples(
      inla_model, data_cls,
      n_samples = 5, use_count_scale = TRUE
    )
    expect_true(data.table::is.data.table(samp))
    expect_true(all(expected_cols %in% colnames(samp)))

    posteriors <- get_posterior_pmfs(inla_model, data_cls)
    pmf_means <- posterior_means_from_pmfs(posteriors$posterior_pmfs)
    means <- epistemic::get_posterior_means(inla_model,
      data_cls,
      use_count_scale = TRUE
    )
    # verify that pmfs are valid (positive, sum to 1)
    expect_pmfs_valid(posteriors$posterior_pmfs)
    # verify that means match
    direct_means <- means[[ncol(means)]]
    expect_equal(pmf_means, direct_means, tolerance = 1e-2)

    ################################################################
    # NOW repeat, with filters
    # region and date filters
    filter_regions <- c("A", "C")
    filter_dates <- c("2024-01-15", "2024-01-22", "2024-01-29")

    # samples
    samp <- get_posterior_samples(
      inla_model, data_cls,
      n_samples = 5, use_count_scale = TRUE,
      regions = filter_regions,
      dates = filter_dates
    )
    expect_true(data.table::is.data.table(samp))
    expect_true(all(expected_cols %in% colnames(samp)))

    posteriors <- get_posterior_pmfs(
      inla_model,
      data_cls,
      regions = filter_regions,
      dates = filter_dates
    )

    pmf_means <- posterior_means_from_pmfs(posteriors$posterior_pmfs)
    means <- epistemic::get_posterior_means(
      inla_model,
      data_cls,
      use_count_scale = TRUE,
      regions = filter_regions,
      dates = filter_dates
    )
    # verify that pmfs are valid (positive, sum to 1)
    expect_pmfs_valid(posteriors$posterior_pmfs)
    # verify that means match
    direct_means <- means[[ncol(means)]]
    expect_equal(pmf_means, direct_means, tolerance = 1e-2)
  })
}
