# © 2025 The Johns Hopkins University Applied Physics Laboratory LLC
# Development of this software was sponsored by the U.S. Government under
# contract no. 75D30124C19958
# As of September 30, 2025 this code is pending review by OTT and should be
# considered JHU Propriety and only for internal JHU/APL use.

# Reusable helpers for synthetic data and fitting

gen_synthetic_data <- function(
  family = c("poisson", "binomial", "nbinomial", "betabinomial"),
  seed = 123
) {
  num <- den <- share <- expected <- NULL
  total_den_by_region <- total_num_by_date <- NULL
  region_id <- region <- date_id <- NULL
  family <- match.arg(family)
  set.seed(seed)

  regions <- c("A", "B", "C", "D")
  dates <- seq(as.Date("2024-01-01"), by = "week", length.out = 5)
  dt <- data.table::CJ(region = regions, date = dates, unique = TRUE)

  if (family %in% c("poisson", "nbinomial")) {
    # counts with exposure
    dt[, den := sample(50:100, .N, replace = TRUE)]
    dt[, num := rbinom(.N, size = den, prob = 0.25)]
  } else if (family %in% c("binomial", "betabinomial")) {
    dt[, den := sample(50:100, .N, replace = TRUE)]
    dt[, num := rbinom(.N, size = den, prob = 0.25)]
  }

  # expected = share * total counts by date (for posterior predictive checks)
  dt[, total_num_by_date := sum(num), by = date]
  dt[, total_den_by_region := sum(den), by = region]
  dt[, share := total_den_by_region / sum(den)]
  dt[, expected := share * total_num_by_date]
  dt[, c("total_num_by_date", "total_den_by_region", "share") := NULL]

  # integer ids
  dt[, region_id := as.integer(factor(region))]
  dt[, date_id := as.integer(factor(date))]

  # build data class and add future dates (keeps tests uniform)
  dc <- epistemic::data_class(
    data = dt,
    region_column = "region",
    date_column = "date",
    numerator_column = "num",
    denominator_column = "den",
    expected_column = "expected",
    feature_columns = character(0)
  )
  dc <- epistemic::add_missing_and_future_dates(
    num_future_steps = 2, dc = dc, den = 1
  )

  # formula shared across families
  formula <- num ~ 1 + f(date_id, model = "rw1") + f(region_id, model = "iid")

  list(dt = dt, dc = dc, formula = formula)
}

fit_quick <- function(dc, formula, family) {
  epistemic::fit_model(
    dc,
    formula = formula, family = family, allow_sampling = TRUE
  )
}

merge_outputs <- function(dc_data, medians, cis) {
  region_column <- dc_data$region_column
  date_column <- dc_data$date_column
  res_list <- list(dc_data$data, medians, cis)

  merge_fun <- function(x, y) {
    merge(x, y, by = c(region_column, date_column), all = TRUE)
  }
  Reduce(merge_fun, res_list)
}

expect_pmfs_valid <- function(pmfs, tol = 1e-3) {
  stopifnot(is.list(pmfs))

  ok <- vapply(pmfs, function(pmf) {
    # Allow NA/NULL entries
    if (is.null(pmf) || (length(pmf) == 1L && is.na(pmf))) {
      return(TRUE)
    }

    v <- suppressWarnings(as.numeric(pmf))
    v[is.na(v)] <- 0

    all(is.finite(v)) &&
      all(v >= -tol) &&
      abs(sum(v) - 1) < tol
  }, logical(1))

  testthat::expect_true(
    all(ok),
    info = paste(
      "Invalid PMFs at indices:",
      paste(which(!ok), collapse = ", ")
    )
  )

  invisible(TRUE)
}


pmf_expected_value <- function(pmf) {
  # pmf is numeric vector over y = 0,1,2,...,k
  y <- seq_along(pmf) - 1L
  sum(y * pmf)
}

posterior_means_from_pmfs <- function(pmfs) {
  vapply(pmfs, pmf_expected_value, numeric(1))
}

make_dummy_seasonal_data <- function(
  n_regions = 3,
  start_date = as.Date("2024-01-01"),
  n_days = 42,
  lambda_den = 50, # baseline Poisson mean for den
  seed = 123
) {
  set.seed(seed)
  suppressPackageStartupMessages(requireNamespace("data.table"))
  dt <- data.table::data.table(
    date = rep(seq.Date(start_date, by = "day", length.out = n_days),
      each = n_regions
    ),
    region = rep(sprintf("R%02d", 1:n_regions), times = n_days)
  )

  # Features: time trend + weak seasonality + region effects
  t <- as.numeric(dt$date - min(dt$date)) # days since start
  t_scaled <- (t - mean(t)) / sd(t) # center/scale for stability
  season <- sin(2 * pi * t / 7) # weekly seasonality

  # Region random effects (fixed for each region)
  reg_eff <- rnorm(n_regions, mean = 0.0, sd = 0.5)
  reg_map <- setNames(reg_eff, sprintf("R%02d", 1:n_regions))

  # Linear predictor and probability p via logistic link
  beta0 <- -1.2 # intercept
  beta_t <- 0.4 # time trend effect
  beta_season <- 0.6 # seasonality amplitude

  eta <- beta0 +
    beta_t * t_scaled +
    beta_season * season +
    reg_map[dt$region]

  p <- plogis(eta) # map to (0,1)
  p <- pmin(pmax(p, 1e-6), 1 - 1e-6)

  # Denominator: Poisson, can vary mildly by region
  reg_den_mult <- exp(rnorm(n_regions, 0, 0.2))
  reg_den_map <- setNames(reg_den_mult, sprintf("R%02d", 1:n_regions))

  den_mean <- lambda_den * reg_den_map[dt$region]
  den_mean <- den_mean * (0.8 + 0.4 * (1 + season) / 2) # small seasonal swing

  den <- rpois(n = nrow(dt), lambda = den_mean)

  # Numerator is  Binomial(den, p)
  # If any den = 0, rbinom handles that (returns 0).
  num <- stats::rbinom(n = nrow(dt), size = den, prob = p)

  dt[, `:=`(p = p, den = den, num = num)]
  # Order and return
  data.table::setcolorder(dt, c("p", "num", "den", "date", "region"))
  dt[]
}
