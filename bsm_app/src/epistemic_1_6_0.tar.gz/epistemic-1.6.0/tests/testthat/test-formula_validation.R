# © 2025 The Johns Hopkins University Applied Physics Laboratory LLC
# Development of this software was sponsored by the U.S. Government under
# contract no. 75D30124C19958
# As of September 30, 2025 this code is pending review by OTT and should be
# considered JHU Propriety and only for internal JHU/APL use.


# Make dummy dataset

nreg <- 3
nts <- 10
npts <- nreg * nts
nums <- sample(1:100, npts)
dens <- as.integer(nums * runif(npts, min = 1, max = 2))
weekly_dates <- seq.Date(
  from = as.Date("2025-01-01"),
  by = "week",
  length.out = nts
)
region_prefix <- "reg_"
region_ids <- paste0(region_prefix, seq_len(nreg))
grid <- expand.grid(
  date = weekly_dates,
  region = region_ids,
  KEEP.OUT.ATTRS = FALSE,
  stringsAsFactors = FALSE
)
df <- data.table::data.table(
  date = grid$date,
  region = grid$region,
  num = nums,
  den = dens,
  x1 = rnorm(npts),
  x2 = rnorm(npts),
  x3 = rnorm(npts)
)
dc <- epistemic::data_class(
  df,
  numerator_column = "num",
  denominator_column = "den",
  date_column = "date",
  region_column = "region",
)


test_that("Valid forumla passes validation", {
  formula <- c(
    'num ~ 1 +
        f(x1,model = "iid") +
        f(x2,model = "rw1") +
        x3 +
        f(r_id,
          model="besagproper",
          graph=adjacency_matrix,
          group=d_id,
          control.group = list(model="ar1")
          )'
  )
  validation_res <- validate_inla_formula(formula, dc)

  expect_true(validation_res$ok)
})

test_that("Parameters in hyper parameters are permitted", {
  param <- 0.2
  alpha <- 0.01

  formula <- c(
    'num ~ 1 +
        f(x1,
          model = "iid",
          hyper=list(prec = list(prior = "pc.prec", param = c(param, alpha)))
          ) +
        f(x2,
          model = "rw1",
          hyper=list(prec = list(prior = "pc.prec", param = c(param, alpha)))
          ) +
        x3 +
        f(r_id,
          model="besagproper",
          graph=adjacency_matrix,
          group=d_id,
          control.group = list(model="ar1"),
          hyper=list(prec = list(prior = "pc.prec", param = c(param,alpha)))
          )'
  )
  validation_res <- validate_inla_formula(formula, dc)
  expect_true(validation_res$ok)
})

test_that("Missing response fails validation", {
  formula <- c(
    'y ~ 1 +
        f(x1,model = "iid") +
        f(x2,model = "rw1") +
        x3 +
        f(r_id,
          model="besagproper",
          graph=adjacency_matrix,
          group=d_id,
          control.group = list(model="ar1")
          )'
  )

  validation_res <- validate_inla_formula(formula, dc)

  expect_false(validation_res$ok)
})

test_that("Response on rhs fails validation", {
  formula <- c(
    'num ~ 1 +
      f(x1,model = "iid") +
      f(num,model = "rw1") +
      x2 +
      f(r_id,
        model="besagproper",
        graph=adjacency_matrix,
        group=d_id,
        control.group = list(model="ar1")
      )'
  )

  validation_res <- validate_inla_formula(formula, dc)

  expect_false(validation_res$ok)
})

test_that("Missing features fail validation", {
  formula <- c(
    'num ~ 1 +
      f(x1,model = "iid") +
      f(x2,model = "rw1") +
      w +
      f(r_id,
        model="besagproper",
        graph=adjacency_matrix,
        group=d_id,
        control.group = list(model="ar1")
      )'
  )

  validation_res <- validate_inla_formula(formula, dc)

  expect_false(validation_res$ok)
})

test_that("Syntax error fails validation", {
  formula <- c(
    'num ~ 1 +
      f(x1,model = "iid") +
      f(x2,model = "rw1") +
      x3 +
      f(r_id,
        model="besagproper",
        graph=adjacency_matrix,
        group=d_id,
        control.group = list(model="ar1")'
  )

  validation_res <- validate_inla_formula(formula, dc)

  expect_false(validation_res$ok)
})

test_that("Invalid model fails validation", {
  formula <- c(
    'file.remove(num ~ 1 +
      f(x1,model = "iid") +
      f(x2,model = "sillywalk") +
      x3 +
      f(r_id,
        model="besagproper",
        graph=adjacency_matrix,
        group=d_id,
        control.group = list(model="ar1")))'
  )

  validation_res <- validate_inla_formula(formula, dc)

  expect_false(validation_res$ok)
})


test_that("Missing index variable fails validation", {
  formula <- c(
    'num ~ 1 +
      f() +
      f(x2,model = "iid") +
      x1 +
      f(r_id,
        model="besagproper",
        graph=adjacency_matrix,
        group=d_id,
        control.group = list(model="ar1"))'
  )

  validation_res <- validate_inla_formula(formula, dc)

  expect_false(validation_res$ok)
})
