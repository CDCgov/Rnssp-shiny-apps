# © 2025 The Johns Hopkins University Applied Physics Laboratory LLC
# Development of this software was sponsored by the U.S. Government under
# contract no. 75D30124C19958
# As of September 30, 2025 this code is pending review by OTT and should be
# considered JHU Propriety and only for internal JHU/APL use.

data("demo_model_result")
data("demo_data")

inla_model <- demo_model_result$inla_model
data_cls <- demo_data

test_that("credible_intervals: function runs without error", {
  expect_silent({
    result <- get_credible_intervals(
      inla_model = inla_model,
      data_cls = demo_data,
      ci_width = 0.95,
      use_count_scale = FALSE
    )
  })
})

test_that("credible_intervals: ci_width is within range", {
  expect_error(
    {
      result <- get_credible_intervals(
        inla_model = inla_model,
        data_cls = demo_data,
        ci_width = 25,
        use_count_scale = FALSE
      )
    },
    "all probabilities must be between 0 and 1"
  )
})

test_that("get_credible_intervals: output matches INLA's summary quantiles", {
  result <- get_credible_intervals(
    inla_model = inla_model,
    data_cls = demo_data,
    ci_width = 0.95,
    use_count_scale = FALSE,
    use_suffix = FALSE
  )

  # Extract quantiles directly from the fitted model
  result2 <- inla_model$summary.fitted.values[, c(
    "0.025quant",
    "0.975quant"
  )]

  # Compare numerically
  expect_equal(result[["0.025"]], result2[, "0.025quant"], tolerance = 1e-3)
  expect_equal(result[["0.975"]], result2[, "0.975quant"], tolerance = 1e-3)
})

test_that("credible_intervals: returns expected columns and dimensions", {
  result <- get_credible_intervals(
    inla_model = inla_model,
    data_cls = demo_data,
    ci_width = 0.9,
    use_count_scale = TRUE,
    use_suffix = TRUE
  )

  expect_s3_class(result, "data.table")
  expect_equal(nrow(result), nrow(demo_data$data))
  expect_equal(
    c(
      demo_data$region_column,
      demo_data$date_column,
      "counts_0.05", "counts_0.95"
    ),
    names(result)
  )
})

test_that("get_credible intervals: filters correctly", {
  dates <- as.Date(c("2024-01-01", "2024-01-08"))
  regions <- c("X0001", "X0003")
  result <- get_credible_intervals(
    inla_model = inla_model,
    data_cls = data_cls,
    ci_width = 0.9,
    dates = dates,
    regions = regions
  )
  res_regions <- result[[data_cls$region_column]]
  res_dates <- result[[data_cls$date_column]]

  expect_true(all(res_regions %in% regions))
  expect_true(all(res_dates %in% dates))
  expect_true(all(regions %in% res_regions))
  expect_true(all(dates %in% res_dates))
})

data_cls <- demo_data
data_cls$data[
  ,
  region_group := data.table::fcase(
    region %in% c("X0001", "X0002"), "RG1",
    region %in% c("X0003", "X0004"), "RG2",
    default = "RG3"
  )
]


test_that(
  "credible_intervals_group: function runs without error",
  {
    expect_silent({
      result <- get_credible_intervals_group(
        inla_model = inla_model,
        data_cls = data_cls,
        ci_width = 0.95,
        use_count_scale = FALSE,
        group_cols = c(
          "region_group",
          data_cls$date_column
        )
      )
    })

    # Basic structural checks
    expect_true(data.table::is.data.table(result))

    # Should contain grouping columns
    expect_true("region_group" %in% names(result))
    expect_true(
      demo_data$date_column %in% names(result)
    )

    # Should return exactly two CI columns
    ci_cols <- setdiff(
      names(result),
      c("region_group", demo_data$date_column)
    )
    expect_equal(length(ci_cols), 2L)
  }
)
